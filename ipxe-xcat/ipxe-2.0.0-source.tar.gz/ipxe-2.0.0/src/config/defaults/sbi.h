#ifndef CONFIG_DEFAULTS_SBI_H
#define CONFIG_DEFAULTS_SBI_H

/** @file
 *
 * Configuration defaults for RISC-V SBI
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#define IOAPI_RISCV
#define UACCESS_OFFSET
#define TIMER_ZICNTR
#define ENTROPY_ZKR

#if __riscv_xlen == 64
#define IOMAP_SVPAGE
#define DMAAPI_RISCV
#else
#define IOMAP_VIRT
#define DMAAPI_FLAT
#endif

#define FDT_SBI
#define REBOOT_SBI
#define UMALLOC_UHEAP
#define MEMMAP_FDT
#define SERIAL_FDT

#define ACPI_NULL
#define MPAPI_NULL
#define NAP_NULL
#define PCIAPI_NULL
#define SANBOOT_NULL
#define SMBIOS_NULL
#define TIME_NULL

#endif /* CONFIG_DEFAULTS_SBI_H */
