#ifndef _BITS_REBOOT_H
#define _BITS_REBOOT_H

/** @file
 *
 * x86-specific reboot API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );
FILE_SECBOOT ( PERMITTED );

#include <ipxe/bios_reboot.h>

#endif /* _BITS_REBOOT_H */
