#ifndef _BITS_IOMAP_H
#define _BITS_IOMAP_H

/** @file
 *
 * x86-specific I/O mapping API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#include <ipxe/iomap_pages.h>

#endif /* _BITS_IOMAP_H */
