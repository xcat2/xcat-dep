#ifndef _FAKEE820_H
#define _FAKEE820_H

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

extern void fake_e820 ( void );
extern void unfake_e820 ( void );

#endif /* _FAKEE820_H */
