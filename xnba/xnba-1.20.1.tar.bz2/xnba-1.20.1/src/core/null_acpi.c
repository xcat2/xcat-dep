#include <ipxe/acpi.h>

PROVIDE_ACPI_INLINE ( null, acpi_find_rsdt );
