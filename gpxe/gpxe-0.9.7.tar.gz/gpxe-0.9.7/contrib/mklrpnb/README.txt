This is a quick and dirty Perl program to make a netbootable
image from a Linux Router floppy. It was tested with a Coyote Linux
(http://www.coyotelinux.com) floppy which is based on LRP.  You need tar,
mtools, mknbi-1.0, and of course, perl, to run this script.
