#ifndef _BITS_PCI_IO_H
#define _BITS_PCI_IO_H

/** @file
 *
 * i386-specific PCI I/O API implementations
 *
 */

#include <gpxe/pcibios.h>
#include <gpxe/pcidirect.h>

#endif /* _BITS_PCI_IO_H */
