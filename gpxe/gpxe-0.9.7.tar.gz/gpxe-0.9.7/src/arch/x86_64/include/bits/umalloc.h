#ifndef _BITS_UMALLOC_H
#define _BITS_UMALLOC_H

/** @file
 *
 * x86_64-specific user memory allocation API implementations
 *
 */

#endif /* _BITS_UMALLOC_H */
