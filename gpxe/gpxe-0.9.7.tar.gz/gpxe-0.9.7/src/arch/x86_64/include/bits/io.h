#ifndef _BITS_IO_H
#define _BITS_IO_H

/** @file
 *
 * x86_64-specific I/O API implementations
 *
 */

#endif /* _BITS_IO_H */
