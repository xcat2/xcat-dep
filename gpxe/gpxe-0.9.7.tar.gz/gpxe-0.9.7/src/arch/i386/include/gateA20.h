#ifndef GATEA20_H
#define GATEA20_H

extern void gateA20_set ( void );
extern void gateA20_unset ( void );

#endif /* GATEA20_H */
