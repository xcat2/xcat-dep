#ifndef _BITS_UACCESS_H
#define _BITS_UACCESS_H

/** @file
 *
 * i386-specific user access API implementations
 *
 */

#include <librm.h>

#endif /* _BITS_UACCESS_H */
