#ifndef _BITS_IO_H
#define _BITS_IO_H

/** @file
 *
 * i386-specific I/O API implementations
 *
 */

#include <gpxe/x86_io.h>

#endif /* _BITS_IO_H */
