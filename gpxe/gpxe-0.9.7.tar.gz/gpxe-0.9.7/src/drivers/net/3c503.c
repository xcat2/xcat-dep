/* 3Com 3c503, a memory-mapped NS8390-based card */
#if 0 /* Currently broken! */
#define INCLUDE_3C503
#include "ns8390.c"
#endif
