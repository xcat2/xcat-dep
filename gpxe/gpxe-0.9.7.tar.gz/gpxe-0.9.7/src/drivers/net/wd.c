/* ISA memory-mapped NS8390-based cards, including WD80x3 */
#if 0 /* Currently broken! */
#define INCLUDE_WD
#define WD_DEFAULT_MEM 0xCC000
#include "ns8390.c"
#endif
