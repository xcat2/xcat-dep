#ifndef CONFIG_NAP_H
#define CONFIG_NAP_H

/** @file
 *
 * CPU sleeping
 *
 */

#include <config/defaults.h>

//#undef		NAP_PCBIOS
//#define		NAP_NULL

#endif /* CONFIG_NAP_H */
