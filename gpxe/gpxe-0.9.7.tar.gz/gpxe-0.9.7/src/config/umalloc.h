#ifndef CONFIG_UMALLOC_H
#define CONFIG_UMALLOC_H

/** @file
 *
 * User memory allocation API configuration
 *
 */

#include <config/defaults.h>

#endif /* CONFIG_UMALLOC_H */
