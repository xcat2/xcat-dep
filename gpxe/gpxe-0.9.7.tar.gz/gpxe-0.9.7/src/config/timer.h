#ifndef CONFIG_TIMER_H
#define CONFIG_TIMER_H

/** @file
 *
 * Timer configuration.
 *
 */

#include <config/defaults.h>

//#undef		TIMER_PCBIOS
//#define		TIMER_RDTSC

#endif /* CONFIG_TIMER_H */
