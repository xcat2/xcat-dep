#!/usr/bin/perl
# $Id: 05-HTTPS.t 1910 2023-03-30 19:16:30Z willem $	-*-perl-*-
#

use strict;
use warnings;
use Test::More tests => 9;

use Net::DNS;

my $name = 'alias.example';
my $type = 'HTTPS';
my $code = 65;
my @attr = qw( svcpriority targetname );
my @data = qw( 0 pool.svc.example );
my @also = qw( );

my $wire = '000004706f6f6c03737663076578616d706c6500';

my $typecode = unpack 'xn', Net::DNS::RR->new( type => $type )->encode;
is( $typecode, $code, "$type RR type code = $code" );

my $hash = {};
@{$hash}{@attr} = @data;


for my $rr ( Net::DNS::RR->new( name => $name, type => $type, %$hash ) ) {
	my $string = $rr->string;
	my $rr2	   = Net::DNS::RR->new($string);
	is( $rr2->string, $string, 'new/string transparent' );

	is( $rr2->encode, $rr->encode, 'new($string) and new(%hash) equivalent' );

	foreach (@attr) {
		is( $rr->$_, $hash->{$_}, "expected result from rr->$_()" );
	}

	foreach (@also) {
		is( $rr2->$_, $rr->$_, "additional attribute rr->$_()" );
	}

	my $encoded = $rr->encode;
	my $decoded = Net::DNS::RR->decode( \$encoded );
	my $hex1    = unpack 'H*', $encoded;
	my $hex2    = unpack 'H*', $decoded->encode;
	my $hex3    = unpack 'H*', $rr->rdata;
	is( $hex2, $hex1, 'encode/decode transparent' );
	is( $hex3, $wire, 'encoded RDATA matches example' );
}


for my $rr ( Net::DNS::RR->new(". $type") ) {
	foreach (@attr) {
		ok( !$rr->$_(), "'$_' attribute of empty RR undefined" );
	}
}


Net::DNS::RR->new( <<'END' )->print;
blog.cloudflare.com.	300	IN	HTTPS	( 1 .
	key1=\005h3-29\005h3-28\005h3-27\002h2
	key4=h\018\026.h\018\027.
	key6=&\006G\000\000\000\000\000\000\000\000\000h\018\026.&\006G\000\000\000\000\000\000\000\000\000h\018\027.
	key65280
	)
END

exit;

