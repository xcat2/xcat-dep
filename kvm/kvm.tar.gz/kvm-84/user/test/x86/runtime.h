#ifndef H_RUNTIME
#define H_RUNTIME

void exit(unsigned code) __attribute__((__noreturn__));

#endif
