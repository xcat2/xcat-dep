/*
 *  $Id: getpassword.h,v 1.4 2014/04/20 06:45:07 bryan Exp $
 *
 *  Copyright conserver.com, 2000
 *
 *  Maintainer/Enhancer: Bryan Stansell (bryan@conserver.com)
 */

extern char *GetPassword(char *);
extern void *ClearPassword(void);
