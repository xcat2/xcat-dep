/*
 *  $Id: getpassword.h,v 1.3 2003/09/11 09:10:58 bryan Exp $
 *
 *  Copyright conserver.com, 2000
 *
 *  Maintainer/Enhancer: Bryan Stansell (bryan@conserver.com)
 */

extern char *GetPassword PARAMS((char *));
extern void *ClearPassword PARAMS((void));
