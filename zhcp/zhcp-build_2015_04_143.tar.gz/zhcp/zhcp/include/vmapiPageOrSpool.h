/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#ifndef VMAPIPAGEORSPOOL_H_
#define VMAPIPAGEORSPOOL_H_
#include "smPublic.h"
#include "smapiTableParser.h"
#include <stddef.h>

#endif  /* VMAPIPAGEORSPOOL_H_ */
