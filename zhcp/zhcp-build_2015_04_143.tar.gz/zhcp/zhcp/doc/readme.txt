For the latest z/VM System Management documentation:

http://www.vm.ibm.com/library/index.html

Click on the z/VM 6.3 PDF Files.

Click on the "Systems Management Application Programming" in the Application Programming section.



For service information and documentation concerning the xCAT delivered with z/VM:

http://www.vm.ibm.com/sysman/xcmntlvl.html