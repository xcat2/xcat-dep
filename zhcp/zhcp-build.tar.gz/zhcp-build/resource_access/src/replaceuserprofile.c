// IBM (C) Copyright 2010 Eclipse Public License
// http://www.eclipse.org/org/documents/epl-v10.html
#include "wrapperutils.h"

/**
 * Replace a specified user profile.
 *
 * @param $1: Name of the user profile which is to be replaced
 * @param $2: Text file containing the user profile
 *
 * @return 0 If user profile entry was successfully replaced
 *         1 If given invalid parameters
 *         2 If user profile replacement failed
 */
int main(int argC, char* argV[]) {

	if (argC != 3) {
		printf("Error: Wrong number of parameters\n");
		return 1;
	}

	// Get user profile name
	char* profileName = argV[1];
	char* file = argV[2];

	// Check if the user profile name is between 1 and 8 characters
	if (isProfileNameInvalid(profileName))
		return 1;

	VmApiInternalContext context;

	// Initialize context
	extern struct _smTrace externSmapiTraceFlags;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	memset(&externSmapiTraceFlags, 0, sizeof(smTrace));
	context.smTraceDetails = (struct _smTrace *) &externSmapiTraceFlags;
	context.memContext = &memContext;

	FILE * userProfile;

	// Open file containing user profile
	userProfile = fopen(file, "r");
	if (userProfile == NULL) {
		printf("Error: Failed to open %s\n", file);

		// Release context
		smMemoryGroupFreeAll(&context);
		smMemoryGroupTerminate(&context);

		return 2;
	} else {
		// Read in user profile
		int recordCount = 0;
		int i = 0;
		char line[100], buffer[30][100];
		char * ptr;
		while (!feof(userProfile)) {
			// Read in 100 characters
			fgets(line, 100, userProfile);

			// Delete new line
			ptr = strstr(line, "\n");
			if (ptr != NULL) {
				strncpy(ptr, "\0", 1);
			}

			// Copy line into buffer
			strcpy(buffer[i], line);
			i++;

			if (!feof(userProfile))
				recordCount++;
		}

		// Close user profile
		fclose(userProfile);

		// Create profile record
		vmApiProfileRecord record[recordCount];

		// Copy buffer contents into profile record
		for (i = 0; i < recordCount; i++) {
			record[i].profileRecordLength = strlen(buffer[i]);
			record[i].recordData = buffer[i];
		}

		printf("Replacing user profile %s... ", profileName);

		// Create user profile
		vmApiProfileReplaceDmOutput* output;
		int rc = smProfile_Replace_DM(&context, "", // Authorizing user
				0, // Password length
				"", // Password
				profileName, // Image name
				recordCount, // Record count
				record, // Record array
				&output);

		if (rc || output->returnCode || output->reasonCode) {
			printf("Failed\n");

			rc ? printf("  Return Code: %d\n", rc) : printf(
					"  Return Code: %d\n"
						"  Reason Code: %d\n", output->returnCode,
					output->reasonCode);

			// Release context
			smMemoryGroupFreeAll(&context);
			smMemoryGroupTerminate(&context);

			return 2;
		} else {
			printf("Done\n");

			// Release context
			smMemoryGroupFreeAll(&context);
			smMemoryGroupTerminate(&context);

			return 0;
		}
	}
}
