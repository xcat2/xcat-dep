/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "wrapperutils.h"

/**
 * Get the IPL statement of a specified virtual server.
 *
 * @param $1: The name of the virtual server
 *
 * @return 0 If the IPL entry was successfully printed
 *         1 If given invalid parameters
 *         2 If the IPL entry could not be retrieved
 */
int main(int argC, char * argV[]) {

	if (argC < 2 || !strcmp(argV[1], "-h") || !strcmp(argV[1], "--help")) {
		printf("Get the IPL statement of a specified virtual server.\n\n"
			"Usage: getipl [@params]\n"
			"@param $1: The name of the virtual server\n");
		return 1;
	} else if (argC != 2) {
		printf("Error: Wrong number of parameters\n");
		return 1;
	}

	char* image = argV[1];

	VmApiInternalContext context;

	// Initialize context
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageIplQueryDmOutput* output;

	int rc = smImage_IPL_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, &output);

	if (rc || (output->common.returnCode && output->common.returnCode != 592)
			|| (output->common.reasonCode && output->common.reasonCode != 0)) {
		printf("Failed\n");

		rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
					"  Reason Code: %d\n", output->common.returnCode, output->common.reasonCode);
	} else {
		printf("IPL target: %s\n"
			"LoadParms: %s\n"
			"Parameters: %s\n", output->savedSystem, output->loadParameter,
				output->parameters);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}
