/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "wrapperutils.h"

/**
 * Get a list of defined disk pools.
 *
 * @param $1: The name of the guest to get a list of disk pools for
 *
 * @return 0 If the disk pools were successfully printed
 *         1 If given invalid parameters
 *         2 If the disk pools could not be retrieved
 */
int main(int argC, char * argV[]) {
	if (argC < 2 || !strcmp(argV[1], "-h") || !strcmp(argV[1], "--help")) {
		printf("Get a list of defined disk pools.\n\n"
			"Usage: getdiskpoolnames [@params]\n"
			"@param $1: The name of the guest to get a list of disk pools for\n");
		return 1;
	} else if (argC != 2) {
		printf("Error: Wrong number of parameters\n");
		return 1;
	}

	char* image = argV[1];

	VmApiInternalContext context;
	vmApiImageRecord * record;
	char * poolName;
	int i;

	// Initialize context
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageVolumeSpaceQueryDmOutput * output;

	int rc = smImage_Volume_Space_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, 1, // Query definition
			3, // Query group
			"*", // All areas
			&output);

	if (rc || (output->common.returnCode && output->common.returnCode != 592)
			|| (output->common.reasonCode && output->common.reasonCode != 0)) {
		printf("Failed\n");

		rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
					"  Reason Code: %d\n", output->common.returnCode, output->common.reasonCode);
	} else {
		record = output->recordList;
		for (i = 0; i < output->recordCount; i++) {
			// Get disk pool name from each record
			const char * delim = " ";
			poolName = strtok_r(record->imageRecord, delim, (char **) &context);
			if (poolName) {
				printf("%s\n", poolName);
			}
			record++;
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}
