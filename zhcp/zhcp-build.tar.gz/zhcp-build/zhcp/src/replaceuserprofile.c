/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "wrapperutils.h"

/**
 * Replace a specified profile directory entry.
 *
 * @param $1: Name of the profile which is to be replaced
 * @param $2: Text file containing the profile directory entry
 *
 * @return 0 If profile was successfully replaced
 *         1 If given invalid parameters
 *         2 If profile replacement failed
 */
int main(int argC, char* argV[]) {

	if (argC < 2 || !strcmp(argV[1], "-h") || !strcmp(argV[1], "--help")) {
		printf("Replace a specified profile directory entry.\n\n"
			"Usage: replaceuserprofile [@params]\n"
			"@param $1: Name of the profile which is to be replaced\n"
			"@param $2: Text file containing the profile directory entry\n");
		return 1;
	} else if (argC != 3) {
		printf("Error: Wrong number of parameters\n");
		return 1;
	}

	// Get user profile name
	char* profileName = argV[1];
	char* file = argV[2];

	// Check if the user profile name is between 1 and 8 characters
	if (isProfileNameInvalid(profileName))
		return 1;

	// Open the user profile file
	FILE * fp = fopen(file, "r");
	if (fp == NULL) {
		printf("Error: Failed to open %s\n", file);
		return 2;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiProfileReplaceDmOutput* output;

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create image record
	vmApiProfileRecord record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].profileRecordLength = strlen(line[i]);
		record[i].recordData = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	int rc = smProfile_Replace_DM(&context, "", 0, "", // Authorizing user, password length, password
				profileName, recordCount,
				(vmApiProfileRecord *) record, // Image record
				&output);

	printf("Replacing user profile %s... ", profileName);

	// Create user profile
	vmApiProfileReplaceDmOutput* output;
	int rc = smProfile_Replace_DM(&context, "", // Authorizing user
			0, // Password length
			"", // Password
			profileName, // Image name
			recordCount, // Record count
			record, // Record array
			&output);

	if (rc || (output->returnCode && output->returnCode != 592)
			|| (output->reasonCode && output->reasonCode != 0)) {
		printf("Failed\n");

		rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
					"  Reason Code: %d\n", output->returnCode, output->reasonCode);
	} else {
		printf("Done\n");
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}
