/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include <stdlib.h>
#include <string.h>
#include "wrapperutils.h"

/**
 * Print return code and reason code
 */
void printRCDescription(char * class, int rc, int rs) {
    // Handle return code (rc) and reason code (rs) as defined
    printf("  Description: ");
    if (rc == 0 && rs == 0) {
        printf("Request successful\n");
    } else if (rc == 0 && rs == 28) {
        printf("Request successful; Image Deactivated Within secs Seconds\n");
    } else if (rc == 0 && rs == 4 && !strcmp(class, "shared_memory")) {
        printf("Segment was created or replaced, but specified userid in memory_access_identifier could not be found to give RSTD access\n");
    } else if (rc == 0 && rs == 8) {
        printf("Request successful; object directory offline\n");
    } else if (rc == 0 && rs == 12 && !strcmp(class, "shared_memory")) {
        printf("Request successful; NAMESAVE statement already exists in directory\n");
    } else if (rc == 0 && rs == 12 && !strcmp(class, "image")) {
        printf("Image not active\n");
    } else if (rc == 0 && rs == 12 && !strcmp(class, "name_list")) {
        printf("Request successful; new list created\n");
    } else if (rc == 0 && rs == 20 && !strcmp(class, "shared_memory")) {
        printf("No output; user(s) not authorized for specified segment\n");
    } else if (rc == 0 && rs == 28 && !strcmp(class, "asynchronous_notification")) {
        printf("No matching entries found\n");
    } else if (rc == 0 && rs == 28 && !strcmp(class, "dirmaint")) {
        printf("No matching entries found. Return buffer is empty.\n");
    } else if (rc == 0 && rs == 28 && !strcmp(class, "dirmaint_local_tag")) {
        printf("No matching entries found. Return buffer is empty.\n");
    } else if (rc == 0 && rs == 28 && !strcmp(class, "image")) {
        printf("No matching entries found. Return buffer is empty.\n");
    } else if (rc == 0 && rs == 28 && !strcmp(class, "image_scsi")) {
        printf("There are no SCSI characteristics for this image.\n");
    } else if (rc == 0 && rs == 28 && !strcmp(class, "shared_memory")) {
        printf("Request successful But Segment Not Found\n");
    } else if (rc == 0 && rs == 36 && !strcmp(class, "name_list")) {
        printf("Name is already in list\n");
    } else if (rc == 0 && rs == 44 && !strcmp(class, "network")) {
        printf("Request successful; virtual switch removed\n");
    } else if (rc == 0 && rs == 66 && !strcmp(class, "network")) {
        printf("Multiple DEFINE or MODIFY statements are erased in system config\n");
    } else if (rc == 0 && rs == 100 && !strcmp(class, "asyn_op")) {
        printf("Asynchronous operation succeeded\n");
    } else if (rc == 0 && rs == 104 && !strcmp(class, "asyn_op")) {
        printf("Asynchronous operation in progress\n");
    } else if (rc == 0 && rs == 108 && !strcmp(class, "asyn_op")) {
        printf("Asynchronous operation failed\n");
    } else if (rc == 4 && rs == 5 && !strcmp(class, "network")) {
        printf("Unrestricted LAN\n");
    } else if (rc == 4 && rs == 6 && !strcmp(class, "network")) {
        printf("No authorized users\n");
    } else if (rc == 8 && rs == 2 && !strcmp(class, "network")) {
        printf("Invalid access user\n");
    } else if (rc == 8 && rs == 3 && !strcmp(class, "network")) {
        printf("Invalid op value\n");
    } else if (rc == 8 && rs == 4 && !strcmp(class, "network")) {
        printf("Invalid promiscuity value\n");
    } else if (rc == 8 && rs == 2783 && !strcmp(class, "network")) {
        printf("Invalid LAN ID\n");
    } else if (rc == 8 && rs == 2795 && !strcmp(class, "network")) {
        printf("Invalid LAN parameter\n");
    } else if (rc == 24 ) {
        printf("Syntax error in function parameter %d\n",(rs/100));
    } else if (rc == 28 && rs == 0 && !strcmp(class, "name_list")) {
        printf("Namelist file not found\n");
    } else if (rc == 28 && rs == 0 && !strcmp(class, "auth_list")) {
        printf("Namelist file not found\n");
    } else if (rc == 36 && rs == 0 && !strcmp(class, "name_list")) {
        printf("Namelist file cannot be updated\n");
    } else if (rc == 36 && rs == 0 && !strcmp(class, "auth_list")) {
        printf("Namelist file cannot be updated\n");
    } else if (rc == 40 && rs == 16 && !strcmp(class, "dcssblk")) {
        printf("DCSS Segment Could Not Be Deleted\n");
    } else if (rc == 100 && rs == 8) {
        printf("Request not authorized by external security manager\n");
    } else if (rc == 100 && rs == 12 ) {
        printf("Request not authorized by directory manager\n");
    } else if (rc == 100 && rs == 16 ) {
        printf("Request not authorized by server\n");
    } else if (rc == 104 && rs == 0 && !strcmp(class, "auth_list")) {
        printf("Authorization file not found\n");
    } else if (rc == 106 && rs == 0 && !strcmp(class, "auth_list")) {
        printf("Authorization file cannot be updated\n");
    } else if (rc == 108 && rs == 0 && !strcmp(class, "auth_list")) {
        printf("Authorization file entry already exists");
    } else if (rc == 112 && rs == 0 && !strcmp(class, "auth_list")) {
        printf("Authorization file entry does not exist\n");
    } else if (rc == 120 && rs == 0 ) {
        printf("Authentication error; userid or password not valid\n");
    } else if (rc == 200 && rs == 4 && !strcmp(class, "network")) {
        printf("Image not found\n");
    } else if (rc == 200 && rs == 4 && !strcmp(class, "image")) {
        printf("Image not found\n");
    } else if (rc == 200 && rs == 8 && !strcmp(class, "image")) {
        printf("Image already active\n");
    } else if (rc == 200 && rs == 12 && !strcmp(class, "network")) {
        printf("Image not active\n");
    } else if (rc == 200 && rs == 12 && !strcmp(class, "image")) {
        printf("Image not active\n");
    } else if (rc == 200 && rs == 16 && !strcmp(class, "image")) {
        printf("Image being deactivated\n");
    } else if (rc == 200 && rs == 24 && !strcmp(class, "image")) {
        printf("List not found\n");
    } else if (rc == 200 && rs == 24 && !strcmp(class, "name_list")) {
        printf("List not found\n");
    } else if (rc == 200 && rs == 28 && !strcmp(class, "image")) {
        printf("Some images in list not activated\n");
    } else if (rc == 200 && rs == 32 && !strcmp(class, "image")) {
        printf("Some images in list not deactivated\n");
    } else if (rc == 200 && rs == 36 && !strcmp(class, "image")) {
        printf("Specified time results in interval greater than max allowed\n");
    } else if (rc == 200 && rs == 36 && !strcmp(class, "image")) {
        printf("Some images in list not recycled\n");
    } else if (rc == 204 && rs == 4 && !strcmp(class, "network")) {
        printf("Image device already exists\n");
    } else if (rc == 204 && rs == 4 && !strcmp(class, "image")) {
        printf("Image device already exists\n");
    } else if (rc == 204 && rs == 8 && !strcmp(class, "network")) {
        printf("Image device does not exist\n");
    } else if (rc == 204 && rs == 8 && !strcmp(class, "image")) {
        printf("Image device does not exist\n");
    } else if (rc == 204 && rs == 12 && !strcmp(class, "network")) {
        printf("Image device is busy\n");
    } else if (rc == 204 && rs == 16 && !strcmp(class, "image")) {
        printf("Image device is not available\n");
    } else if (rc == 204 && rs == 24 && !strcmp(class, "image")) {
        printf("Image device is not a tape drive, or cannot be assigned/reset\n");
    } else if (rc == 204 && rs == 28 && !strcmp(class, "image")) {
        printf("Image device is not a shared DASD\n");
    } else if (rc == 204 && rs == 32 && !strcmp(class, "image")) {
        printf("Image device is not a reserved DASD\n");
    } else if (rc == 204 && rs == 36 && !strcmp(class, "image")) {
        printf("I/O error on image device\n");
    } else if (rc == 204 && rs == 40 && !strcmp(class, "image")) {
        printf("Virtual Network Adapter not deleted\n");
    } else if (rc == 204 && rs == 44 && !strcmp(class, "image")) {
        printf("DASD volume cannot be deleted\n");
    } else if (rc == 204 && rs == 48 && !strcmp(class, "network")) {
        printf("Virtual network adapter is already disconnected\n");
    } else if (rc == 208 && rs == 4 && !strcmp(class, "image")) {
        printf("Image disk already in use\n");
    } else if (rc == 208 && rs == 8 && !strcmp(class, "image")) {
        printf("Image disk not in use\n");
    } else if (rc == 208 && rs == 12 && !strcmp(class, "image")) {
        printf("Image disk not available\n");
    } else if (rc == 208 && rs == 16 && !strcmp(class, "image")) {
        printf("Image disk cannot be shared as requested\n");
    } else if (rc == 208 && rs == 20 && !strcmp(class, "image")) {
        printf("MODE Image disk shared in different mode\n");
    } else if (rc == 208 && rs == 28 && !strcmp(class, "image")) {
        printf("Image disk does not have required password\n");
    } else if (rc == 208 && rs == 32 && !strcmp(class, "image")) {
        printf("Incorrect password specified for image disk\n");
    } else if (rc == 208 && rs == 1157 && !strcmp(class, "image")) {
        printf("MDISK DEVNO parameter requires the device to be a free volume\n");
    } else if (rc == 212 && rs == 4 && !strcmp(class, "network")) {
        printf("Partner image not found\n");
    } else if (rc == 212 && rs == 8 && !strcmp(class, "network")) {
        printf("Adapter does not exist\n");
    } else if (rc == 212 && rs == 12 && !strcmp(class, "network")) {
        printf("LAN does not exist\n");
    } else if (rc == 212 && rs == 16 && !strcmp(class, "network")) {
        printf("LAN owner LAN name does not exist\n");
    } else if (rc == 212 && rs == 20 && !strcmp(class, "network")) {
        printf("Requested LAN owner not active\n");
    } else if (rc == 212 && rs == 24 && !strcmp(class, "network")) {
        printf("LAN name already exists with different attributes\n");
    } else if (rc == 212 && rs == 28 && !strcmp(class, "network")) {
        printf("Image device not correct type for requested connection\n");
    } else if (rc == 212 && rs == 36 && !strcmp(class, "network")) {
        printf("Virtual switch already exists\n");
    } else if (rc == 212 && rs == 40 && !strcmp(class, "network")) {
        printf("Virtual switch does not exist\n");
    } else if (rc == 212 && rs == 52 && !strcmp(class, "network")) {
        printf("Maximum number of connections reached\n");
    } else if (rc == 212 && rs == 96 && !strcmp(class, "network")) {
        printf("Unknown reason\n");
    } else if (rc == 216 && rs == 2 && !strcmp(class, "image")) {
        printf("Input virtual CPU value out of range\n");
    } else if (rc == 216 && rs == 4 && !strcmp(class, "image")) {
        printf("Virtual CPU not found\n");
    } else if (rc == 216 && rs == 12 && !strcmp(class, "image")) {
        printf("Image not active\n");
    } else if (rc == 216 && rs == 24 && !strcmp(class, "image")) {
        printf("Virtual CPU already exists\n");
    } else if (rc == 216 && rs == 28 && !strcmp(class, "image")) {
        printf("Virtual CPU address beyond allowable range defined in directory\n");
    } else if (rc == 216 && rs == 40 && !strcmp(class, "image")) {
        printf("Processor type not supported on your system\n");
    } else if (rc == 300 && rs == 0 && !strcmp(class, "image")) {
        printf("Image volume operation successful\n");
    } else if (rc == 300 && rs == 8 && !strcmp(class, "image")) {
        printf("Device not found\n");
    } else if (rc == 300 && rs == 10 && !strcmp(class, "image")) {
        printf("Device not available for attachment\n");
    } else if (rc == 300 && rs == 12 && !strcmp(class, "image")) {
        printf("Device not a volume\n");
    } else if (rc == 300 && rs == 14 && !strcmp(class, "image")) {
        printf("Free modes not available\n");
    } else if (rc == 300 && rs == 16 && !strcmp(class, "image")) {
        printf("Device vary online failed\n");
    } else if (rc == 300 && rs == 18 && !strcmp(class, "image")) {
        printf("Volume label not found in system configuration\n");
    } else if (rc == 300 && rs == 20 && !strcmp(class, "image")) {
        printf("Volume label already in system configuration\n");
    } else if (rc == 300 && rs == 22 && !strcmp(class, "image")) {
        printf("Parm disks 1 and 2 are same\n");
    } else if (rc == 300 && rs == 24 && !strcmp(class, "image")) {
        printf("Error linking parm disk (1 or 2)\n");
    } else if (rc == 300 && rs == 28 && !strcmp(class, "image")) {
        printf("Parm disk (1 or 2) not RW\n");
    } else if (rc == 300 && rs == 32 && !strcmp(class, "image")) {
        printf("System configuration not found on parm disk 1\n");
    } else if (rc == 300 && rs == 34 && !strcmp(class, "image")) {
        printf("System configuration has bad data\n");
    } else if (rc == 300 && rs == 36 && !strcmp(class, "image")) {
        printf("Syntax errors updating system configuration file\n");
    } else if (rc == 300 && rs == 38 && !strcmp(class, "image")) {
        printf("CP disk modes not available\n");
    } else if (rc == 300 && rs == 40 && !strcmp(class, "image")) {
        printf("Parm disk (1 or 2) is full\n");
    } else if (rc == 300 && rs == 42 && !strcmp(class, "image")) {
        printf("Parm disk (1 or 2) access not allowed\n");
    } else if (rc == 300 && rs == 44 && !strcmp(class, "image")) {
        printf("Parm disk (1 or 2) PW not supplied\n");
    } else if (rc == 300 && rs == 46 && !strcmp(class, "image")) {
        printf("Parm disk (1 or 2) PW is incorrect\n");
    } else if (rc == 300 && rs == 48 && !strcmp(class, "image")) {
        printf("Parm disk (1 or 2) is not in server's user directory\n");
    } else if (rc == 300 && rs == 50 && !strcmp(class, "image")) {
        printf("Error in release of CPRELEASE parm disk (1 or 2)\n");
    } else if (rc == 300 && rs == 52 && !strcmp(class, "image")) {
        printf("Error in access of CPACCESS parm disk (1 or 2)\n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "asynchronous_notification")) {
        printf("Image definition not defined\n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "dirmaint_local_tag")) {
        printf("Image definition not found\n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "dirmaint_local_tag_set")) {
        printf("Image definition not found\n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "image")) {
        printf("Image or profile definition not found\n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "image_scsi")) {
        printf("Image definition not found\n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "profile")) {
        printf("Profile definition not defined \n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "network")) {
        printf("Image definition not defined \n");
    } else if (rc == 400 && rs == 4 && !strcmp(class, "shared_memory")) {
        printf("Image definition not defined \n");
    } else if (rc == 400 && rs == 8 && !strcmp(class, "image")) {
        printf("Image name already defined\n");
    } else if (rc == 400 && rs == 8 && !strcmp(class, "profile")) {
        printf("Profile name already defined\n");
    } else if (rc == 400 && rs == 12 && !strcmp(class, "image")) {
        printf("Image definition is locked \n");
    } else if (rc == 400 && rs == 12 && !strcmp(class, "profile")) {
        printf("Profile definition is locked\n");
    } else if (rc == 400 && rs == 12 && !strcmp(class, "network")) {
        printf("Image definition is locked\n");
    } else if (rc == 400 && rs == 12 && !strcmp(class, "shared_memory")) {
        printf("Image definition is locked\n");
    } else if (rc == 400 && rs == 16 && !strcmp(class, "image")) {
        printf("Image definition cannot be deleted\n");
    } else if (rc == 400 && rs == 16 && !strcmp(class, "profile")) {
        printf("Profile definition cannot be deleted\n");
    } else if (rc == 400 && rs == 16 && !strcmp(class, "shared_memory")) {
        printf("DCSS Segment Could Not Be Deleted\n");
    } else if (rc == 400 && rs == 20 && !strcmp(class, "image")) {
        printf("Image prototype is not defined\n");
    } else if (rc == 400 && rs == 24 && !strcmp(class, "image")) {
        printf("Image definition is not locked\n");
    } else if (rc == 400 && rs == 24 && !strcmp(class, "profile")) {
        printf("Profile name is not locked\n");
    } else if (rc == 400 && rs == 40 && !strcmp(class, "image")) {
        printf("Multiple user statements D158\n");
    } else if (rc == 404 && rs == 4 && !strcmp(class, "image")) {
        printf("Image device already defined\n");
    } else if (rc == 404 && rs == 4 && !strcmp(class, "network")) {
        printf("Image device already defined\n");
    } else if (rc == 404 && rs == 8 && !strcmp(class, "image")) {
        printf("Image device not defined\n");
    } else if (rc == 404 && rs == 8 && !strcmp(class, "network")) {
        printf("Image device not defined\n");
    } else if (rc == 404 && rs == 12 && !strcmp(class, "image")) {
        printf("Image Device Is Locked\n");
    } else if (rc == 404 && rs == 12 && !strcmp(class, "network")) {
        printf("Image Device Is Locked\n");
    } else if (rc == 404 && rs == 24 && !strcmp(class, "image")) {
        printf("Image device type not same as source\n");
    } else if (rc == 404 && rs == 28 && !strcmp(class, "image")) {
        printf("Image device size not same as source\n");
    } else if (rc == 408 && rs == 4 && !strcmp(class, "image")) {
        printf("Image disk already defined\n");
    } else if (rc == 408 && rs == 8 && !strcmp(class, "image")) {
        printf("Image disk not defined\n");
    } else if (rc == 408 && rs == 12 && !strcmp(class, "image")) {
        printf("Image device is locked\n");
    } else if (rc == 408 && rs == 16 && !strcmp(class, "image")) {
        printf("Image disk sharing not allowed by target image definition\n");
    } else if (rc == 408 && rs == 24 && !strcmp(class, "image")) {
        printf("Requested image disk space not available\n");
    } else if (rc == 408 && rs == 28 && !strcmp(class, "image")) {
        printf("Image disk does not have required password\n");
    } else if (rc == 408 && rs == 32 && !strcmp(class, "image")) {
        printf("Incorrect password specified for image disk\n");
    } else if (rc == 412 && rs == 4 && !strcmp(class, "network")) {
        printf("Partner image not found\n");
    } else if (rc == 412 && rs == 16 && !strcmp(class, "network")) {
        printf("Parameters do not match existing directory statement\n");
    } else if (rc == 412 && rs == 28 && !strcmp(class, "network")) {
        printf("Image device not correct type for requested connection\n");
    } else if (rc == 416 && rs == 0 && !strcmp(class, "prototype")) {
        printf("Prototype definition error\n");
    } else if (rc == 416 && rs == 4 && !strcmp(class, "prototype")) {
        printf("Prototype definition not found\n");
    } else if (rc == 416 && rs == 8 && !strcmp(class, "prototype")) {
        printf("Prototype already exists\n");
    } else if (rc == 420 && rs == 4 && !strcmp(class, "image")) {
        printf("Group, region, or volume name is already defined\n");
    } else if (rc == 420 && rs == 8 && !strcmp(class, "image")) {
        printf("That group, region, or volume name is not defined.\n");
    } else if (rc == 420 && rs == 12 && !strcmp(class, "image")) {
        printf("That region name is not included in the group.\n");
    } else if (rc == 420 && rs == 36 && !strcmp(class, "image")) {
        printf("The requested volume is offline or is not a DASD device\n");
    } else if (rc == 424 && rs == 4 && !strcmp(class, "shared_memory")) {
        printf("Namesave statement already exists\n");
    } else if (rc == 424 && rs == 8 && !strcmp(class, "shared_memory")) {
        printf("Segment name not found\n");
    } else if (rc == 428 && rs == 4 && !strcmp(class, "asynchronous_notification")) {
        printf("Duplicate subscription\n");
    } else if (rc == 428 && rs == 8 && !strcmp(class, "asynchronous_notification")) {
        printf("No matching entries\n");
    } else if (rc == 432 && rs == 4 && !strcmp(class, "dirmaint_local_tag")) {
        printf("Tag name is already defined.\n");
    } else if (rc == 432 && rs == 8 && !strcmp(class, "dirmaint_local_tag_set")) {
        printf("Tag name is not defined.\n");
    } else if (rc == 432 && rs == 8 && !strcmp(class, "dirmaint_local_tag")) {
        printf("Tag name is not defined.\n");
    } else if (rc == 432 && rs == 12 && !strcmp(class, "dirmaint_local_tag")) {
        printf("Tag ordinal is already defined.\n");
    } else if (rc == 432 && rs == 16 && !strcmp(class, "dirmaint_local_tag")) {
        printf("Tag is in use in one or more directory entries, can not be revoked.\n");
    } else if (rc == 432 && rs == 16 && !strcmp(class, "dirmaint_local_tag_set")) {
        printf("Tag too long\n");
    } else if (rc == 432 && rs == 20 && !strcmp(class, "dirmaint_local_tag_set")) {
        printf("Use not allowed by exit routine.\n");
    } else if (rc == 436 && rs == 4 && !strcmp(class, "image")) {
        printf("Profile included not found\n");
    } else if (rc == 436 && rs == 40 && !strcmp(class, "image")) {
        printf("Multiple profiles included\n");
    } else if (rc == 444 && rs == 0 && !strcmp(class, "image")) {
        printf("Password policy error\n");
    } else if (rc == 448 && rs == 0 && !strcmp(class, "image")) {
        printf("Account policy error\n");
    } else if (rc == 452 && rs == 4 && !strcmp(class, "dirmaint")) {
        printf("Task not found\n");
    } else if (rc == 456 && rs == 4 && !strcmp(class, "image_scsi")) {
        printf("LOADDEV statement not found\n");
    } else if (rc == 460 && rs == 4 && !strcmp(class, "image")) {
        printf("Image does not have an IPL statement\n");
    } else if (rc == 500 && rs == 8) {
        printf("Directory manager is not available\n");
    } else if (rc == 500 && rs == 20 && !strcmp(class, "shared_memory")) {
        printf("Password format not supported\n");
    } else if (rc == 500 && rs == 20 && !strcmp(class, "image")) {
        printf("Password format not supported\n");
    } else if (rc == 504 && !strcmp(class, "shared_memory")) {
        printf("Target ID not added\n");
    } else if (rc == 520 && rs == 24 && !strcmp(class, "image")) {
        printf("Only one base CPU may be defined\n");
    } else if (rc == 520 && rs == 28 && !strcmp(class, "image")) {
        printf("Input virtual CPU value out of range\n");
    } else if (rc == 520 && rs == 30 && !strcmp(class, "image")) {
        printf("CPU not found\n");
    } else if (rc == 520 && rs == 32 && !strcmp(class, "image")) {
        printf("Maximum allowable number of virtual CPUs is exceeded\n");
    } else if (rc == 520 && rs == 45 && !strcmp(class, "image")) {
        printf("The Cryptographic Coprocessor Facility (CCF) is not installed on this system\n");
    } else if (rc == 520 && rs == 2826 && !strcmp(class, "image_scsi")) {
        printf("SCPDATA contains invalid UTF-8 data\n");
    } else if (rc == 592 ) {
        printf("Asynchronous operation started - product-specific asynchronous operation ID : %d",rs);
    } else if (rc == 596 ) {
        printf("Internal directory manager error - product-specific return code : %d",rs);
    } else if (rc == 600 && rs == 8 && !strcmp(class, "shared_memory")) {
        printf("Bad page range\n");
    } else if (rc == 600 && rs == 12 && !strcmp(class, "shared_memory")) {
        printf("User not logged on\n");
    } else if (rc == 600 && rs == 16 && !strcmp(class, "shared_memory")) {
        printf("Could not save segment\n");
    } else if (rc == 600 && rs == 20 && !strcmp(class, "shared_memory")) {
        printf("Not authorized to issue internal system command or is not authorized for RSTD segment\n");
    } else if (rc == 600 && rs == 24 && !strcmp(class, "shared_memory")) {
        printf("Conflicting parameters\n");
    } else if (rc == 600 && rs == 28 && !strcmp(class, "shared_memory")) {
        printf("Segment not found or does not exist\n");
    } else if (rc == 600 && rs == 299 && !strcmp(class, "shared_memory")) {
        printf("Class S (skeleton) segment file already exists\n");
    } else if (rc == 620 && rs == 14 && !strcmp(class, "network")) {
        printf("Free modes not available\n");
    } else if (rc == 620 && rs == 20 && !strcmp(class, "shared_memory")) {
        printf("Not authorized to issue internal system command or is not authorized for RSTD segment\n");
    } else if (rc == 620 && rs == 22 && !strcmp(class, "network")) {
        printf("System config parm disks 1 and 2 are same\n");
    } else if (rc == 620 && rs == 24 && !strcmp(class, "network")) {
        printf("Error linking parm disk (1 or 2)\n");
    } else if (rc == 620 && rs == 28 && !strcmp(class, "network")) {
        printf("Parm disk (1 or 2) not RW\n");
    } else if (rc == 620 && rs == 32 && !strcmp(class, "network")) {
        printf("System config not found on parm disk 1\n");
    } else if (rc == 620 && rs == 34 && !strcmp(class, "network")) {
        printf("System config has bad data\n");
    } else if (rc == 620 && rs == 36 && !strcmp(class, "network")) {
        printf("Syntax errors updating system config\n");
    } else if (rc == 620 && rs == 38 && !strcmp(class, "network")) {
        printf("CP disk modes not available\n");
    } else if (rc == 620 && rs == 40 && !strcmp(class, "network")) {
        printf("Parm disk (1 or 2) is full\n");
    } else if (rc == 620 && rs == 42 && !strcmp(class, "network")) {
        printf("Parm disk (1 or 2) access not allowed\n");
    } else if (rc == 620 && rs == 44 && !strcmp(class, "network")) {
        printf("Parm disk (1 or 2) PW not supplied\n");
    } else if (rc == 620 && rs == 46 && !strcmp(class, "network")) {
        printf("Parm disk (1 or 2) PW is incorrect\n");
    } else if (rc == 620 && rs == 48 && !strcmp(class, "network")) {
        printf("Parm disk (1 or 2) is not in server's directory\n");
    } else if (rc == 620 && rs == 50 && !strcmp(class, "network")) {
        printf("Error in release of CPRELEASE parm disk (1 or 2)\n");
    } else if (rc == 620 && rs == 52 && !strcmp(class, "network")) {
        printf("Error in access of CPACCESS parm disk (1 or 2)\n");
    } else if (rc == 620 && rs == 54 && !strcmp(class, "network")) {
        printf("DEFINE VSWITCH statement already exists in system config\n");
    } else if (rc == 620 && rs == 58 && !strcmp(class, "network")) {
        printf("MODIFY VSWITCH statement to userid not found in system config\n");
    } else if (rc == 620 && rs == 60 && !strcmp(class, "network")) {
        printf("DEFINE VSWITCH statement does not exist in system config\n");
    } else if (rc == 620 && rs == 62 && !strcmp(class, "network")) {
        printf("DEFINE operands conflict, cannot be updated in the system config\n");
    } else if (rc == 620 && rs == 64 && !strcmp(class, "network")) {
        printf("Multiple DEFINE or MODIFY statements found in system config\n");
    } else if (rc == 800 && rs == 8 && !strcmp(class, "vmrm")) {
        printf("No measurement data exists\n");
    } else if (rc == 800 && rs == 12 && !strcmp(class, "vmrm")) {
        printf("Incorrect Syntax In Update Data \n");
    } else if (rc == 800 && rs == 16 && !strcmp(class, "vmrm")) {
        printf("Not authorized to access file\n");
    } else if (rc == 800 && rs == 24 && !strcmp(class, "vmrm")) {
        printf("Error writing file(s) to directory\n");
    } else if (rc == 800 && rs == 28 && !strcmp(class, "vmrm")) {
        printf("Specified configuration file not found\n");
    } else if (rc == 900 && rs == 12) {
        printf("Specified function does not exist\n");
    } else if (rc == 900 && rs == 20) {
        printf("Total length does not match the specified input data\n");
    } else if (rc == 900 && rs == 24) {
        printf("Error accessing SFS directory\n");
    } else if (rc == 900 && rs == 36) {
        printf("Specified length was not valid, out of valid server data range\n");
    } else {
        printf("Unknown\n");
    }
}

