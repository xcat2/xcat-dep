/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "wrapperutils.h"

/**
 * The following APIs are needed by OVF:
 * 		Directory_Manager_Search_DM
 *		Image_Activate
 * 		Image_Create_DM
 * 		Image_Deactivate
 * 		Image_Delete_DM
 * 		Image_Disk_Create_DM
 * 		Image_Disk_Delete_DM
 * 		Image_Name_Query_DM
 * 		Image_Query_DM
 * 		Image_Volume_Space_Query_DM
 * 		Query_Asynchronous_Operation_DM
 */

/**
 * Print return code and reason code
 */
void printReturnCode(int rc, int returnCode, int reasonCode) {
	// Handle return code and reason code
	if (rc || returnCode || reasonCode) {
		rc ? printf("Failed\n  Return Code: %d\n", rc) : printf("Failed\n  Return Code: %d\n"
					"  Reason Code: %d\n", returnCode, reasonCode);
	} else {
		printf("Done\n");
	}
}

/**
 * Internal query for async operations
 */
int queryAsyncOperation(char* image, int operationId) {
	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiQueryAsynchronousOperationDmOutput* output;

	int rc = smQuery_Asychronous_Operation_DM(&context, "", 0, "",
			image, operationId, &output);

	// Handle return code and reason code
	if (rc || output->returnCode || output->reasonCode) {
		if (rc) {
			printf("Return Code: %d\n", rc);
		} else {
			if (output->returnCode == 0 && output->reasonCode == 0) {
				printf("Done\n");
			} else if (output->returnCode == 0 && output->reasonCode == 100) {
				printf("Done\n");
			} else if (output->returnCode == 0 && output->reasonCode == 104) {
				// Asynchronous operation in progress
				smMemoryGroupFreeAll(&context);
				smMemoryGroupTerminate(&context);
				sleep(5);	// Wait 5 seconds

				// Query asnc operation again
				queryAsyncOperation(image, operationId);
			} else if (output->returnCode == 0 && output->reasonCode == 108) {
				printf("Failed\n  Asynchronous operation failed\n");
			} else {
				printf("Failed\n  Return Code: %d\n"
					"  Reason Code: %d\n", output->returnCode, output->reasonCode);
			}
		}
	} else {
		printReturnCode(rc, output->returnCode, output->reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

/**
 * Command line interface to SMAPI socket API
 */
int main(int argC, char* argV[]) {
	int rc = 0; // Return code
	if (argC < 2 || !strcmp(argV[1], "--help") || !strcmp(argV[1], "-h")) {
		printf("Command line interface to SMAPI socket APIs.\n\n"
				"Usage: smcli function_name\n"
				"The API function names:\n"
				"  Asynchronous_Notification_Disable_DM\n"
				"  Asynchronous_Notification_Enable_DM\n"
				"  Asynchronous_Notification_Query_DM\n"
				"  Authorization_List_Add\n"
				"  Authorization_List_Query\n"
				"  Authorization_List_Remove\n"
				"  Check_Authentication\n"
				"  Directory_Manager_Local_Tag_Define_DM\n"
				"  Directory_Manager_Local_Tag_Delete_DM\n"
				"  Directory_Manager_Local_Tag_Query_DM\n"
				"  Directory_Manager_Local_Tag_Set_DM\n"
				"  Directory_Manager_Search_DM\n"
				"  Directory_Manager_Task_Cancel_DM\n"
				"  Image_Activate\n"
				"  Image_Active_Configuration_Query\n"
				"  Image_CPU_Define\n"
				"  Image_CPU_Define_DM\n"
				"  Image_CPU_Delete\n"
				"  Image_CPU_Delete_DM\n"
				"  Image_CPU_Query\n"
				"  Image_CPU_Query_DM\n"
				"  Image_CPU_Set_Maximum_DM\n"
				"  Image_Create_DM\n"
				"  Image_Deactivate\n"
				"  Image_Delete_DM\n"
				"  Image_Device_Dedicate\n"
				"  Image_Device_Dedicate_DM\n"
				"  Image_Device_Reset\n"
				"  Image_Device_Undedicate\n"
				"  Image_Device_Undedicate_DM\n"
				"  Image_Disk_Copy\n"
				"  Image_Disk_Copy_DM\n"
				"  Image_Disk_Create\n"
				"  Image_Disk_Create_DM\n"
				"  Image_Disk_Delete\n"
				"  Image_Disk_Delete_DM\n"
				"  Image_Disk_Share\n"
				"  Image_Disk_Share_DM\n"
				"  Image_Disk_Unshare\n"
				"  Image_Disk_Unshare_DM\n"
				"  Image_IPL_Delete_DM\n"
				"  Image_IPL_Query_DM\n"
				"  Image_IPL_Set_DM\n"
				"  Image_Lock_DM\n"
				"  Image_Name_Query_DM\n"
				"  Image_Password_Set_DM\n"
				"  Image_Query_Activate_Time\n"
				"  Image_Query_DM\n"
				"  Image_Recycle\n"
				"  Image_Replace_DM\n"
				"  Image_SCSI_Characteristics_Define_DM\n"
				"  Image_SCSI_Characteristics_Query_DM\n"
				"  Image_Status_Query\n"
				"  Image_Unlock_DM\n"
				"  Image_Volume_Add\n"
				"  Image_Volume_Delete\n"
				"  Image_Volume_Space_Define_DM\n"
				"  Image_Volume_Space_Query_DM\n"
				"  Image_Volume_Space_Remove_DM\n"
				"  Name_List_Add\n"
				"  Name_List_Destroy\n"
				"  Name_List_Query\n"
				"  Name_List_Remove\n"
				"  Profile_Create_DM\n"
				"  Profile_Delete_DM\n"
				"  Profile_Lock_DM\n"
				"  Profile_Query_DM\n"
				"  Profile_Replace_DM\n"
				"  Profile_Unlock_DM\n"
				"  Prototype_Create_DM\n"
				"  Prototype_Delete_DM\n"
				"  Prototype_Name_Query_DM\n"
				"  Prototype_Query_DM\n"
				"  Prototype_Replace_DM\n"
				"  Query_API_Functional_Level\n"
				"  Query_Asynchronous_Operation_DM\n"
				"  Query_Directory_Manager_Level_DM\n"
				"  Shared_Memory_Access_Add_DM\n"
				"  Shared_Memory_Access_Query_DM\n"
				"  Shared_Memory_Access_Remove_DM\n"
				"  Shared_Memory_Create\n"
				"  Shared_Memory_Delete\n"
				"  Shared_Memory_Query\n"
				"  Shared_Memory_Replace\n"
				"  Static_Image_Changes_Activate_DM\n"
				"  Static_Image_Changes_Deactivate_DM\n"
				"  Static_Image_Changes_Immediate_DM\n"
				"  System_Config_Syntax_Check\n"
				"  Virtual_Channel_Connection_Create\n"
				"  Virtual_Channel_Connection_Create_DM\n"
				"  Virtual_Channel_Connection_Delete\n"
				"  Virtual_Channel_Connection_Delete_DM\n"
				"  Virtual_Network_Adapter_Connect_LAN\n"
				"  Virtual_Network_Adapter_Connect_LAN_DM\n"
				"  Virtual_Network_Adapter_Connect_Vswitch\n"
				"  Virtual_Network_Adapter_Connect_Vswitch_DM\n"
				"  Virtual_Network_Adapter_Create\n"
				"  Virtual_Network_Adapter_Create_DM\n"
				"  Virtual_Network_Adapter_Delete\n"
				"  Virtual_Network_Adapter_Delete_DM\n"
				"  Virtual_Network_Adapter_Disconnect\n"
				"  Virtual_Network_Adapter_Disconnect_DM\n"
				"  Virtual_Network_Adapter_Query\n"
				"  Virtual_Network_LAN_Access\n"
				"  Virtual_Network_LAN_Access_Query\n"
				"  Virtual_Network_LAN_Create\n"
				"  Virtual_Network_LAN_Delete\n"
				"  Virtual_Network_LAN_Query\n"
				"  Virtual_Network_Vswitch_Create\n"
				"  Virtual_Network_Vswitch_Delete\n"
				"  Virtual_Network_Vswitch_Query\n"
				"  Virtual_Network_Vswitch_Set\n"
				"  VMRM_Configuration_Query\n"
				"  VMRM_Configuration_Update\n"
				"  VMRM_Measurement_Query\n"
				"  xCAT_Commands_IUO\n");
		return 1;
	}

	if (!strcmp(argV[1], "Asynchronous_Notification_Disable_DM")) {
		rc = asynchronousNotificationDisableDM(argC, argV);
	} else if (!strcmp(argV[1], "Asynchronous_Notification_Enable_DM")) {
		rc = asynchronousNotificationEnableDM(argC, argV);
	} else if (!strcmp(argV[1], "Asynchronous_Notification_Query_DM")) {
		rc = asynchronousNotificationQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Authorization_List_Add")) {
		rc = authorizationListAdd(argC, argV);
	} else if (!strcmp(argV[1], "Authorization_List_Query")) {
		rc = authorizationListQuery(argC, argV);
	} else if (!strcmp(argV[1], "Authorization_List_Remove")) {
		rc = authorizationListRemove(argC, argV);
	} else if (!strcmp(argV[1], "Check_Authentication")) {
		rc = checkAuthentication(argC, argV);
	} else if (!strcmp(argV[1], "Directory_Manager_Local_Tag_Define_DM")) {
		rc = directoryManagerLocalTagDefineDM(argC, argV);
	} else if (!strcmp(argV[1], "Directory_Manager_Local_Tag_Delete_DM")) {
		rc = directoryManagerLocalTagDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Directory_Manager_Local_Tag_Query_DM")) {
		rc = directoryManagerLocalTagQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Directory_Manager_Local_Tag_Set_DM")) {
		rc = directoryManagerLocalTagSetDM(argC, argV);
	} else if (!strcmp(argV[1], "Directory_Manager_Search_DM")) {
		rc = directoryManagerSearchDM(argC, argV);
	} else if (!strcmp(argV[1], "Directory_Manager_Task_Cancel_DM")) {
		rc = directoryManagerTaskCancelDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Activate")) {
		rc = imageActivate(argC, argV);
	} else if (!strcmp(argV[1], "Image_Active_Configuration_Query")) {
		rc = imageActiveConfigurationQuery(argC, argV);
	} else if (!strcmp(argV[1], "Image_CPU_Define")) {
		rc = imageCPUDefine(argC, argV);
	} else if (!strcmp(argV[1], "Image_CPU_Define_DM")) {
		rc = imageCPUDefineDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_CPU_Delete")) {
		rc = imageCPUDelete(argC, argV);
	} else if (!strcmp(argV[1], "Image_CPU_Delete_DM")) {
		rc = imageCPUDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_CPU_Query")) {
		rc = imageCPUQuery(argC, argV);
	} else if (!strcmp(argV[1], "Image_CPU_Query_DM")) {
		rc = imageCPUQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_CPU_Set_Maximum_DM")) {
		rc = imageCPUSetMaximumDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Create_DM")) {
		rc = imageCreateDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Deactivate")) {
		rc = imageDeactivate(argC, argV);
	} else if (!strcmp(argV[1], "Image_Delete_DM")) {
		rc = imageDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Device_Dedicate")) {
		rc = imageDeviceDedicate(argC, argV);
	} else if (!strcmp(argV[1], "Image_Device_Dedicate_DM")) {
		rc = imageDeviceDedicateDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Device_Reset")) {
		rc = imageDeviceReset(argC, argV);
	} else if (!strcmp(argV[1], "Image_Device_Undedicate")) {
		rc = imageDeviceUndedicate(argC, argV);
	} else if (!strcmp(argV[1], "Image_Device_Undedicate_DM")) {
		rc = imageDeviceUndedicateDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Copy")) {
		rc = imageDiskCopy(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Copy_DM")) {
		rc = imageDiskCopyDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Create")) {
		rc = imageDiskCreate(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Create_DM")) {
		rc = imageDiskCreateDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Delete")) {
		rc = imageDiskDelete(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Delete_DM")) {
		rc = imageDiskDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Share")) {
		rc = imageDiskShare(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Share_DM")) {
		rc = imageDiskShareDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Unshare")) {
		rc = imageDiskUnshare(argC, argV);
	} else if (!strcmp(argV[1], "Image_Disk_Unshare_DM")) {
		rc = imageDiskUnshareDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_IPL_Delete_DM")) {
		rc = imageIPLDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_IPL_Query_DM")) {
		rc = imageIPLQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_IPL_Set_DM")) {
		rc = imageIPLSetDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Lock_DM")) {
		rc = imageLockDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Name_Query_DM")) {
		rc = imageNameQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Password_Set_DM")) {
		rc = imagePasswordSetDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Query_Activate_Time")) {
		rc = imageQueryActivateTime(argC, argV);
	} else if (!strcmp(argV[1], "Image_Query_DM")) {
		rc = imageQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Recycle")) {
		rc = imageRecycle(argC, argV);
	} else if (!strcmp(argV[1], "Image_Replace_DM")) {
		rc = imageReplaceDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_SCSI_Characteristics_Define_DM")) {
		rc = imageSCSICharacteristicsDefineDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_SCSI_Characteristics_Query_DM")) {
		rc = imageSCSICharacteristicsQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Status_Query")) {
		rc = imageStatusQuery(argC, argV);
	} else if (!strcmp(argV[1], "Image_Unlock_DM")) {
		rc = imageUnlockDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Volume_Add")) {
		rc = imageVolumeAdd(argC, argV);
	} else if (!strcmp(argV[1], "Image_Volume_Delete")) {
		rc = imageVolumeDelete(argC, argV);
	} else if (!strcmp(argV[1], "Image_Volume_Space_Define_DM")) {
		rc = imageVolumeSpaceDefineDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Volume_Space_Query_DM")) {
		rc = imageVolumeSpaceQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Image_Volume_Space_Remove_DM")) {
		rc = imageVolumeSpaceRemoveDM(argC, argV);
	} else if (!strcmp(argV[1], "Name_List_Add")) {
		rc = nameListAdd(argC, argV);
	} else if (!strcmp(argV[1], "Name_List_Destroy")) {
		rc = nameListDestroy(argC, argV);
	} else if (!strcmp(argV[1], "Name_List_Query")) {
		rc = nameListQuery(argC, argV);
	} else if (!strcmp(argV[1], "Name_List_Remove")) {
		rc = nameListRemove(argC, argV);
	} else if (!strcmp(argV[1], "Profile_Create_DM")) {
		rc = profileCreateDM(argC, argV);
	} else if (!strcmp(argV[1], "Profile_Delete_DM")) {
		rc = profileDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Profile_Query_DM")) {
		rc = profileQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Profile_Replace_DM")) {
		rc = profileReplaceDM(argC, argV);
	} else if (!strcmp(argV[1], "Prototype_Create_DM")) {
		rc = prototypeCreateDM(argC, argV);
	} else if (!strcmp(argV[1], "Prototype_Delete_DM")) {
		rc = prototypeDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Prototype_Name_Query_DM")) {
		rc = prototypeNameQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Prototype_Query_DM")) {
		rc = prototypeQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Prototype_Replace_DM")) {
		rc = prototypeReplaceDM(argC, argV);
	} else if (!strcmp(argV[1], "Query_API_Functional_Level")) {
		rc = queryAPIFunctionalLevel(argC, argV);
	} else if (!strcmp(argV[1], "Query_Asynchronous_Operation_DM")) {
		rc = queryAsynchronousOperationDM(argC, argV);
	} else if (!strcmp(argV[1], "Query_Directory_Manager_Level_DM")) {
		rc = queryDirectoryManagerLevelDM(argC, argV);
	} else if (!strcmp(argV[1], "Shared_Memory_Access_Add_DM")) {
		rc = sharedMemoryAccessAddDM(argC, argV);
	} else if (!strcmp(argV[1], "Shared_Memory_Access_Query_DM")) {
		rc = sharedMemoryAccessQueryDM(argC, argV);
	} else if (!strcmp(argV[1], "Shared_Memory_Access_Remove_DM")) {
		rc = sharedMemoryAccessRemoveDM(argC, argV);
	} else if (!strcmp(argV[1], "Shared_Memory_Create")) {
		rc = sharedMemoryCreate(argC, argV);
	} else if (!strcmp(argV[1], "Shared_Memory_Delete")) {
		rc = sharedMemoryDelete(argC, argV);
	} else if (!strcmp(argV[1], "Shared_Memory_Query")) {
		rc = sharedMemoryQuery(argC, argV);
	} else if (!strcmp(argV[1], "Shared_Memory_Replace")) {
		rc = sharedMemoryReplace(argC, argV);
	} else if (!strcmp(argV[1], "Static_Image_Changes_Activate_DM")) {
		rc = staticImageChangesActivateDM(argC, argV);
	} else if (!strcmp(argV[1], "Static_Image_Changes_Deactivate_DM")) {
		rc = staticImageChangesDeactivateDM(argC, argV);
	} else if (!strcmp(argV[1], "Static_Image_Changes_Immediate_DM")) {
		rc = staticImageChangesImmediateDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Channel_Connection_Create")) {
		rc = virtualChannelConnectionCreate(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Channel_Connection_Create_DM")) {
		rc = virtualChannelConnectionCreateDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Channel_Connection_Delete")) {
		rc = virtualChannelConnectionDelete(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Channel_Connection_Delete_DM")) {
		rc = virtualChannelConnectionDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Connect_LAN")) {
		rc = virtualNetworkAdapterConnectLAN(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Connect_LAN_DM")) {
		rc = virtualNetworkAdapterConnectLANDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Connect_Vswitch")) {
		rc = virtualNetworkAdapterConnectVswitch(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Connect_Vswitch_DM")) {
		rc = virtualNetworkAdapterConnectVswitchDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Create")) {
		rc = virtualNetworkAdapterCreate(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Create_DM")) {
		rc = virtualNetworkAdapterCreateDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Delete")) {
		rc = virtualNetworkAdapterDelete(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Delete_DM")) {
		rc = virtualNetworkAdapterDeleteDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Disconnect")) {
		rc = virtualNetworkAdapterDisconnect(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Disconnect_DM")) {
		rc = virtualNetworkAdapterDisconnectDM(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Adapter_Query")) {
		rc = virtualNetworkAdapterQuery(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_LAN_Access")) {
		rc = virtualNetworkLANAccess(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_LAN_Access_Query")) {
		rc = virtualNetworkLANAccessQuery(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_LAN_Create")) {
		rc = virtualNetworkLANCreate(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_LAN_Delete")) {
		rc = virtualNetworkLANDelete(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_LAN_Query")) {
		rc = virtualNetworkLANQuery(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Vswitch_Create")) {
		rc = virtualNetworkVswitchCreate(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Vswitch_Delete")) {
		rc = virtualNetworkVswitchDelete(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Vswitch_Query")) {
		rc = virtualNetworkVswitchQuery(argC, argV);
	} else if (!strcmp(argV[1], "Virtual_Network_Vswitch_Set")) {
		rc = virtualNetworkVswitchSet(argC, argV);
	} else if (!strcmp(argV[1], "VMRM_Configuration_Query")) {
		rc = VMRMConfigurationQuery(argC, argV);
	} else if (!strcmp(argV[1], "VMRM_Configuration_Update")) {
		rc = VMRMConfigurationUpdate(argC, argV);
	} else if (!strcmp(argV[1], "VMRM_Measurement_Query")) {
		rc = VMRMMeasurementQuery(argC, argV);
	} else if (!strcmp(argV[1], "xCAT_Commands_IUO")) {
		rc = xCATCommandsIUO(argC, argV);
	} else {
		printf("ERROR: Unsupported API function name\n");
		return 1;
	}

	return rc;
}

int asynchronousNotificationDisableDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char* image = NULL;
	int entity = 0;
	int communication = 0;
	int portNumber = 0;
	char* ip = "";
	int encoding = 0;
	char* subscriberData = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:t:c:p:i:e:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 't':
				entity = atoi(optarg);
				break;

			case 'c':
				communication = atoi(optarg);
				break;

			case 'p':
				portNumber = atoi(optarg);
				break;

			case 'i':
				ip = optarg;
				break;

			case 'e':
				encoding = atoi(optarg);
				break;

			case 's':
				subscriberData = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Asynchronous_Notification_Disable_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Asynchronous_Notification_Disable_DM [-T] image_name\n"
					"    [-t] entity_type [-c] communication_type [-p] port_number\n"
					"    [-i] ip_address [-e] encoding [-s] subscriber_data\n\n"
					"DESCRIPTION\n"
					"  Use Asynchronous_Notification_Disable_DM to end notification of updates to\n"
					"  specified entities as they occur.\n\n"
					"  The following options are required:\n"
					"    -T    The userid for which notifications will be disabled\n"
					"    -t    The entity type for which notifications will be sent:\n"
					"            1: DIRECTORY\n"
					"    -c    The communication type used for notifications:\n"
					"            1: TCP\n"
					"            2: UDP\n"
					"    -p    The port number of the socket that will no longer be receiving the\n"
					"          notifications\n"
					"    -i    The IPV4 dotted-decimal IP address of the socket that will no longer\n"
					"          receive the notifications\n"
					"    -e    The encoding of the notification data string:\n"
					"            0: Unspecified\n"
					"            1: ASCII\n"
					"            2: EBCDIC\n"
					"    -s    The matching subscriber data\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Ending notification of updates to %s... ", image);
	if (!image || !entity || !communication || !portNumber || !ip || !encoding || !subscriberData) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiAsynchronousNotificationDisableDmOutput* output;

	int rc = smAsynchronous_Notification_Disable_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, entity, communication, portNumber, ip, encoding, strlen(subscriberData), subscriberData, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int asynchronousNotificationEnableDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char* image = NULL;
	int entity = 0;
	int subscription = 0;
	int communication = 0;
	int portNumber = 0;
	char* ip = "";
	int encoding = 0;
	char* subscriberData = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:t:r:c:p:i:e:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 't':
				entity = atoi(optarg);
				break;

			case 'r':
				subscription = atoi(optarg);
				break;

			case 'c':
				communication = atoi(optarg);
				break;

			case 'p':
				portNumber = atoi(optarg);
				break;

			case 'i':
				ip = optarg;
				break;

			case 'e':
				encoding = atoi(optarg);
				break;

			case 's':
				subscriberData = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Asynchronous_Notification_Enable_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Asynchronous_Notification_Enable_DM [-T] image_name\n"
					"    [-t] entity_type [-r] subscription_type [-c] communication_type\n"
					"    [-p] port_number [-i] ip_address [-e] encoding\n"
					"    [-s] subscriber_data\n\n"
					"DESCRIPTION\n"
					"  Use Asynchronous_Notification_Enable_DM to begin notification of updates\n"
					"  to a specified entity as the updates occur.\n\n"
					"  The following options are required:\n"
					"    -T    The image to be notified\n"
					"    -t    The entity type for which notifications will be sent:\n"
					"            1: DIRECTORY\n"
					"	 -r    The subscription type:\n"
					"            1: The target_identifier will receive notifications for\n"
					"               associated directory changes\n"
					"            2: The target_identifier will not receive notifications\n"
					"               for associated directory changes\n"
					"    -c    The communication type used for notifications:\n"
					"            1: TCP\n"
					"            2: UDP\n"
					"    -p    The port number of the socket that will receive the notifications\n"
					"    -i    The IPV4 dotted-decimal IP address of the socket that will receive\n"
					"          the notifications\n"
					"    -e    The encoding of the notification data string:\n"
					"            0: Unspecified\n"
					"            1: ASCII\n"
					"            2: EBCDIC\n"
					"    -s    Anything the subscriber wishes to receive along with the notifications\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Begining notification of updates to %s... ", image);
	if (!image || !entity || !subscription || !communication || !portNumber || !ip || !encoding || !subscriberData) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiAsynchronousNotificationEnableDmOutput* output;

	int rc = smAsynchronous_Notification_Enable_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, entity, subscription, communication, portNumber, ip, encoding, strlen(subscriberData), subscriberData, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int asynchronousNotificationQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char* image = NULL;
	int entity = 0;
	int communication = 0;
	int portNumber = 0;
	char* ip = "";
	int encoding = 0;
	char* subscriberData = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:t:r:c:p:i:e:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 't':
				entity = atoi(optarg);
				break;

			case 'c':
				communication = atoi(optarg);
				break;

			case 'p':
				portNumber = atoi(optarg);
				break;

			case 'i':
				ip = optarg;
				break;

			case 'e':
				encoding = atoi(optarg);
				break;

			case 's':
				subscriberData = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Asynchronous_Notification_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Asynchronous_Notification_Query_DM [-T] image_name\n"
					"    [-t] entity_type [-r] subscription_type [-c] communication_type\n"
					"    [-p] port_number [-i] ip_address [-e] encoding\n"
					"    [-s] subscriber_data\n\n"
					"DESCRIPTION\n"
					"  Use Asynchronous_Notification_Query_DM to query which users\n"
					"  are subscribed to receive notification of updates to specified\n"
					"  entities.\n\n"
					"  The following options are required:\n"
					"    -T    The images to be notified\n"
					"    -t    The entity type for which notifications will be sent:\n"
					"            1: DIRECTORY\n"
					"	 -r    The subscription type:\n"
					"            1: The target_identifier will receive notifications for\n"
					"               associated directory changes\n"
					"            2: The target_identifier will not receive notifications\n"
					"               for associated directory changes\n"
					"    -c    The communication type of the notification strings being queried:\n"
					"            0: Unspecified\n"
					"            1: TCP\n"
					"            2: UDP\n"
					"    -p    The port number of the socket that will receive the notifications\n"
					"    -i    The IPV4 dotted-decimal IP address of the socket that will receive\n"
					"          the notifications\n"
					"    -e    The encoding of the notification strings being queried:\n"
					"            0: Unspecified\n"
					"            1: ASCII\n"
					"            2: EBCDIC\n"
					"    -s    Subscriber data\n"
					"            Anything the subscriber wishes to receive along with the\n"
					"            notifications\n"
					"            *: Selects all that qualify\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Querying notification updates to %s... ", image);
	if (!image || !entity || !communication || !portNumber || !ip || !encoding || !subscriberData) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiAsynchronousNotificationQueryDmOutput* output;

	int rc = smAsynchronous_Notification_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, entity, communication, portNumber, ip,
		encoding, strlen(subscriberData), subscriberData, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->common.returnCode, output->common.reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int authorizationListAdd(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * forId = "";
	char * functionId = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:i:f:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'i':
				forId = optarg;
				break;

			case 'f':
				functionId = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Authorization_List_Add\n\n"
					"SYNOPSIS\n"
					"  smcli Authorization_List_Add [-T] image_name [-i] for_id [-f] function_id\n\n"
					"DESCRIPTION\n"
					"  Use Authorization_List_Add to add an entry to the authorization file.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name\n"
					"    -i    This is the virtual image or list of virtual images which will be\n"
					"          authorized to perform the designated function(s)\n"
					"    -f    The function or list of functions that is authorized to perform\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Adding an entry to the authorization file for %s... ", image);
	if (!image || !forId || !functionId) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiAsynchronousNotificationEnableDmOutput* output;

	int rc = smAuthorization_List_Add(&context, "", 0, "", // Authorizing user, password length, password.
		image, forId, functionId, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int authorizationListQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * forId = "";
	char * functionId = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:i:f:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'i':
				forId = optarg;
				break;

			case 'f':
				functionId = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Authorization_List_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Authorization_List_Query [-T] image_name [-i] for_id [-f] function_id\n\n"
					"DESCRIPTION\n"
					"  Use Authorization_List_Query to query the entries in the authorization file.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name\n"
					"  The following options are optional:\n"
					"    -i    The userid or list of userids in the 'Requesting User(s)' field of the\n"
					"          authorization file record(s) being queried\n"
					"    -f    The function or list of functions that target_identifier is authorized\n"
					"          to perform for for_id\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiAuthorizationListQueryOutput* output;

	int rc = smAuthorization_List_Query(&context, "", 0, "", // Authorizing user, password length, password.
		image, forId, functionId, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out image volumes
		int i, length;
		int recCount = output->authorizationRecordCount;
		for (i = 0; i < recCount; i++) {
			char* reqUserId = output->authorizationRecordList[i].requestingUserid;
			char* forUserId = output->authorizationRecordList[i].forUserid;
			char* functionName = output->authorizationRecordList[i].functionName;
			printf("Entry:\n"
				"  Requesting user ID: %s\n"
				"  For user ID: %s\n"
				"  Function name: %s\n", reqUserId, forUserId, functionName);
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int authorizationListRemove(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * forId = NULL;
	char * functionId = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:i:f:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'i':
				forId = optarg;
				break;

			case 'f':
				functionId = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Authorization_List_Remove\n\n"
					"SYNOPSIS\n"
					"  smcli Authorization_List_Remove [-T] image_name [-i] for_id [-f] function_id\n\n"
					"DESCRIPTION\n"
					"  Use Authorization_List_Remove to remove an entry from the authorization file.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name\n"
					"    -i    The userid or list of userids whose authorization to perform the designated\n"
					"          function(s) is to be removed"
					"    -f    The function or list of functions for which target_identifier's\n"
					"          authorization to perform for for_id will be removed");
				return 1;
				break;

			default:
				break;
		}

	printf("Removing %s from the authorization file... ", forId);
	if (!image || !forId || !functionId) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiAuthorizationListRemoveOutput* output;

	int rc = smAuthorization_List_Remove(&context, "", 0, "", // Authorizing user, password length, password.
		image, forId, functionId, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int checkAuthentication(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "h?")) != -1)
		switch (option) {
			case 'h':
				printf("NAME\n"
					"  Check_Authentication\n\n"
					"SYNOPSIS\n"
					"  smcli Check_Authentication\n\n"
					"DESCRIPTION\n"
					"  Use Check_Authentication to validate a userid/password pair.\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Validating userid/password pair... ");

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiCheckAuthenticationOutput* output;

	int rc = smCheck_Authentication(&context, "", 0, "", // Authorizing user, password length, password.
		&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int directoryManagerLocalTagDefineDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * tagName = NULL;
	int tagOrdinal = 0;
	int action = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:o:a:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				tagName = optarg;
				break;

			case 'o':
				tagOrdinal = atoi(optarg);
				break;

			case 'a':
				action = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Directory_Manager_Local_Tag_Define_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Directory_Manager_Local_Tag_Define_DM [-T] image_name\n"
					"  [-t] tag_name [-o] tag_ordinal [-a] action\n\n"
					"DESCRIPTION\n"
					"  Use Directory_Manager_Local_Tag_Define_DM to define a local tag or named\n"
					"  comment record to contain installation-specific information about a virtual\n"
					"  image.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -n    The name of the local tag or named comment to be defined\n"
					"    -o    The value of the tag sort ordinal, relative to other defined\n"
					"          local tags\n"
					"    -a    Specifies creation of a new tag or change of a tag ordinal value:\n"
					"            1: Create a new tag\n"
					"            2: Change an existing tag's ordinal value\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Defining a local tag or named comment record... ");
	if (!image || !tagName || !tagOrdinal || !action) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiDirectoryManagerLocalTagDefineDmOutput* output;

	int rc = smDirectory_Manager_Local_Tag_Define_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, tagName, tagOrdinal, action, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int directoryManagerLocalTagDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * tagName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				tagName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Directory_Manager_Local_Tag_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Directory_Manager_Local_Tag_Delete_DM [-T] image_name [-n] tag_name\n\n"
					"DESCRIPTION\n"
					"  Use Directory_Manager_Local_Tag_Delete_DM to remove a local tag or\n"
					"  named comment record from the directory manager's internal tables.\n"
					"  Users will no longer be able to set or query the tag.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file that\n"
					"          also contains the authenticated_userid and the function_name\n"
					"    -n    Specifies the name of the tag to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Removing a local tag or named comment record... ");
	if (!image || !tagName) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiDirectoryManagerLocalTagDeleteDmOutput* output;

	int rc = smDirectory_Manager_Local_Tag_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, tagName, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int directoryManagerLocalTagQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * tagName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				tagName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Directory_Manager_Local_Tag_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Directory_Manager_Local_Tag_Query_DM [-T] image_name [n] tag_name\n\n"
					"DESCRIPTION\n"
					"  Use Directory_Manager_Local_Tag_Query_DM to obtain the value of a\n"
					"  virtual image's local tag or named comment record.\n\n"
					"  The following options are required:\n"
					"    -T    The target userid whose tag is being queried\n"
					"    -n    The name of the local tag or named comment to be queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !tagName) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiDirectoryManagerLocalTagQueryDmOutput* output;

	int rc = smDirectory_Manager_Local_Tag_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, tagName, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print value of the associated tag
		printf("%s\n", output->tagValue);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int directoryManagerLocalTagSetDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * tagName = NULL;
	char * tagValue = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				tagName = optarg;
				break;

			case 'v':
				tagValue = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Directory_Manager_Local_Tag_Set_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Directory_Manager_Local_Tag_Set_DM [-T] image_name\n"
					"  [-n] tag_name [-v] tag_value\n\n"
					"DESCRIPTION\n"
					"  Use Directory_Manager_Local_Tag_Set_DM to set the value of a virtual\n"
					"  image's local tag or named comment record.\n\n"
					"  The following options are required:\n"
					"    -T    The target userid whose tag is being set\n"
					"    -n    The name of the local tag or named comment to be set\n"
					"    -v    The value of a virtual image's local tag or named comment\n"
					"          to be set\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Setting the value of a virtual image's local tag or named comment record... ");
	if (!image || !tagName || !tagValue) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiDirectoryManagerLocalTagSetDmOutput* output;

	int rc = smDirectory_Manager_Local_Tag_Set_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, tagName, strlen(tagValue), tagValue, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int directoryManagerSearchDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * searchPattern = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				searchPattern = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Directory_Manager_Search_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Directory_Manager_Search_DM [-T] image_name [-s] search_pattern\n\n"
					"DESCRIPTION\n"
					"  Use Directory_Manager_Search_DM to search the directory for records that\n"
					"  match the specified pattern.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -s    The records to be searched for. Tokens must be separated by blanks\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !searchPattern) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiDirectoryManagerSearchDmOutput* output;

	int rc = smDirectory_Manager_Search_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, strlen(searchPattern), searchPattern, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out image names
		int i;
		int recCount = output->statementCount;
		int RECORD_LENGTH = 72;
		char line[RECORD_LENGTH];
		if (recCount > 0) {
			// Loop through the records and print it out
			for (i = 0; i < recCount; i++) {
				memset(line, 0, RECORD_LENGTH);
				memcpy(line, output->statementList[i].statement, output->statementList[i].statementLength);
				trim(line);
				printf("%s: %s\n", output->statementList[i].targetId, line);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int directoryManagerTaskCancelDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int opId = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:i:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'i':
				opId = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Directory_Manager_Task_Cancel_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Directory_Manager_Task_Cancel_DM [-T] image_name\n"
					"  [-i] operation_id\n\n"
					"DESCRIPTION\n"
					"  Use Directory_Manager_Task_Cancel_DM to cancel a specific asynchronous\n"
					"  task being performed by the directory manager.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -i    The identifier of the task\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Canceling asynchronous task... ");
	if (!image || !opId) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiDirectoryManagerTaskCancelDmOutput* output;

	int rc = smDirectory_Manager_Task_Cancel_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, opId, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageActivate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Activate\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Activate [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_Activate to activate a virtual image or list of virtual images.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being activated\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Activating %s... ", image);
	if (!image) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageActivateOutput* output;

	int rc = smImage_Activate(&context, "", 0, "", // Authorizing user, password length, password.
		image, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->common.returnCode, output->common.reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageActiveConfigurationQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Active_Configuration_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Active_Configuration_Query [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_Active_Configuration_Query to obtain current configuration\n"
					"  information for an active virtual image.\n\n"
					"  The following options are required:\n"
					"    -T    The userid being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageActiveConfigurationQueryOutput * output;

	// Handle return code and reason code
	int rc = smImage_Active_Configuration_Query(&context, "", 0, "", // Authorizing user, password length, password.
			image, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out active configuration
		int cpuInfoCount = output->cpuInfoCount;
		int deviceCount = output->deviceCount;
		int memorySize = output->memorySize;
		int numberOfCpus = output->numberOfCpus;

		char* shareType = "";
		if (output->shareType == 1) {
			shareType = "Relative";
		} else if (output->shareType == 2) {
			shareType = "Absolute";
		}

		char* shareValue = output->shareValue;

		char* memoryUnit = "";
		if (output->memoryUnit == 1) {
			memoryUnit = "KB";
		} else if (output->memoryUnit == 2) {
			memoryUnit = "MB";
		} else if (output->memoryUnit == 3) {
			memoryUnit = "GB";
		}

		printf("Memory: %i %s\n"
			"Share type: %s\n"
			"Share value: %s\n"
			"CPU count: %i\n", memorySize, memoryUnit, shareType, shareValue, numberOfCpus);

		vmApiImageCpuInfo* cpuList = output->cpuList;
		int i;
		char* cpuType;
		char* cpuStatus;
		printf("CPUs\n");
		for (i = 0; i < numberOfCpus; i++) {
			if (cpuList[i].cpuStatus == 1) {
				cpuStatus = "Base";
			} else if (cpuList[i].cpuStatus == 2) {
				cpuStatus = "Stopped";
			} else if (cpuList[i].cpuStatus == 3) {
				cpuStatus = "Check-stopped";
			} else if (cpuList[i].cpuStatus == 4) {
				cpuStatus = "Non-base, active";
			}

			printf("  Address: %i\n"
				"  ID: %s (%s)\n", cpuList[i].cpuNumber, cpuList[i].cpuId, cpuStatus);
		}

		vmApiImageDeviceInfo* deviceList = output->deviceList;
		char* deviceType;
		printf("Devices\n");
		for (i = 0; i < deviceCount; i++) {
			if (deviceList[i].deviceType == 1) {
				deviceType = "CONS";
			} else if (deviceList[i].deviceType == 2) {
				deviceType = "RDR";
			} else if (deviceList[i].deviceType == 3) {
				deviceType = "PUN";
			} else if (deviceList[i].deviceType == 4) {
				deviceType = "PRT";
			} else if (deviceList[i].deviceType == 5) {
				deviceType = "DASD";
			}

			printf("  Address: %s (%s)\n", deviceList[i].deviceAddress, deviceType);
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCPUDefine(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * cpuAddress = NULL;
	int cpuType = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:t:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				cpuAddress = optarg;
				break;

			case 't':
				cpuType = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_CPU_Define\n\n"
					"SYNOPSIS\n"
					"  smcli Image_CPU_Define [-T] image_name [-v] virtual_address\n"
					"  [-t] cpu_type\n\n"
					"DESCRIPTION\n"
					"  Use Image_CPU_Define to add a virtual processor to an active virtual\n"
					"  image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the virtual image for which to define a virtual CPU\n"
					"    -v    The virtual CPU address to add to the virtual image\n"
					"    -t    The type of processor to add:\n"
					"            0: Unspecified\n"
					"            1: CP\n"
					"            2: IFL\n"
					"            3: ZAAP\n"
					"            4: ZIIP\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Adding a virtual processor to %s's configuration...\n", image);
	if (!image || !cpuAddress || !cpuType) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCpuDefineOutput* output;

	int rc = smImage_CPU_Define(&context, "", 0, "", // Authorizing user, password length, password.
		image, cpuAddress, cpuType, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCPUDefineDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * cpuAddress = NULL;
	int baseCpu = 0;
	char * cpuId = "";
	int dedicateCpu = 0;
	int cryto = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:b:c:d:y:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				cpuAddress = optarg;
				break;

			case 'b':
				baseCpu = atoi(optarg);
				break;

			case 'c':
				cpuId = optarg;
				break;

			case 'd':
				dedicateCpu = atoi(optarg);
				break;

			case 'y':
				cryto = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_CPU_Define_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_CPU_Define_DM [-T] image_name [-v] virtual_address\n"
					"    [-b] base_cpu [-d] dedicate_cpu [-y] cryto_cpu [-c] cpu_id\n\n"
					"DESCRIPTION\n"
					"  Use Image_CPU_Define_DM to add a virtual processor to a virtual image's\n"
					"  directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the virtual image for which to statically define a\n"
					"          virtual CPU.\n"
					"    -v    The virtual CPU address to add to the static definition of the\n"
					"          virtual image (in the hexadecimal range of 0-3F)\n"
					"    -b    Whether this CPU defines the base virtual processor:\n"
					"            0: Unspecified\n"
					"            1: BASE\n"
					"    -d    Whether the virtual processor is to be dedicated at LOGON time to a\n"
					"          real processor:\n"
					"            0: Unspecified\n"
					"            1: NODEDICATE\n"
					"            2: DEDICATE\n"
					"    -y    Whether the virtual Cryptographic Coprocessor Facility (CCF) should be\n"
					"          defined automatically for the virtual CPU at LOGON time:\n"
					"            0: Unspecified (no CRYPTO)\n"
					"            1: CRYPTO\n"
					"  The following options are optional:\n"
					"    -c    The processor identification number to be stored in bits 8 through 31\n"
					"          of the CPU ID, returned in response to the store processor ID (STIDP)\n"
					"          instruction\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Adding a virtual processor to $s's directory entry...\n", image);
	if (!image || !cpuAddress || !baseCpu || !dedicateCpu || !cryto) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCpuDefineDmOutput* output;

	int rc = smImage_CPU_Define_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, cpuAddress, baseCpu,
			cpuId, dedicateCpu, cryto, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCPUDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * cpuAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				cpuAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_CPU_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Image_CPU_Delete [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_CPU_Delete to delete a virtual processor from an active\n"
					"  virtual image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of a virtual image for which a virtual CPU will\n"
					"          be deleted.\n"
					"    -v    The virtual CPU address to delete from the virtual image");
				return 1;
				break;

			default:
				break;
		}

	printf("Deleting a virtual processor from $s's active configuration...\n", image);
	if (!image || !cpuAddress) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCpuDeleteOutput* output;

	int rc = smImage_CPU_Delete(&context, "", 0, "", // Authorizing user, password length, password.
		image, cpuAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCPUDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_CPU_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_CPU_Delete_DM [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_CPU_Delete_DM to delete a virtual processor from a\n"
					"  virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the virtual image from which to statically\n"
					"          delete a virtual CPU.\n"
					"    -v    The virtual CPU address to delete from the static\n"
					"          definition of the virtual image (in the hexadecimal\n"
					"          range of 0-3F).\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Deleting a virtual processor from $s's directory entry...\n", image);
	if (!image || !virtualAddress) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCpuDeleteDmOutput* output;

	int rc = smImage_CPU_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCPUQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_CPU_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Image_CPU_Query [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_CPU_Query to query the virtual processors in an active\n"
					"  virtual image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the virtual image whose virtual CPUs are\n"
					"          being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCpuQueryOutput* output;

	int rc = smImage_CPU_Query(&context, "", 0, "", // Authorizing user, password length, password.
		image, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out active configuration
		int cpuInfoCount = output->cpuInfoCount;
		int numberOfCpus = output->numberOfCpus;

		printf("CPU count: %i\n", numberOfCpus);

		vmApiImageCpuInfo* cpuList = output->cpuList;
		int i;
		char* cpuType;
		char* cpuStatus;
		printf("CPUs\n");
		for (i = 0; i < numberOfCpus; i++) {
			if (cpuList[i].cpuStatus == 1) {
				cpuStatus = "Base";
			} else if (cpuList[i].cpuStatus == 2) {
				cpuStatus = "Stopped";
			} else if (cpuList[i].cpuStatus == 3) {
				cpuStatus = "Check-stopped";
			} else if (cpuList[i].cpuStatus == 4) {
				cpuStatus = "Non-base, active";
			}

			if (cpuList[i].cpuType == 1) {
				cpuType = "CP";
			} else if (cpuList[i].cpuType == 2) {
				cpuType = "IFL";
			} else if (cpuList[i].cpuType == 3) {
				cpuType = "ZAAP";
			} else if (cpuList[i].cpuType == 4) {
				cpuType = "ZIIP";
			}

			printf("  Address: %i\n"
				"    Type: %s\n"
				"    ID: %s (%s)\n", cpuList[i].cpuNumber, cpuType, cpuList[i].cpuId, cpuStatus);
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCPUQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * cpuAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				cpuAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_CPU_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_CPU_Query_DM [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_CPU_Query_DM to query a virtual processor in a virtual\n"
					"  image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the virtual image from which to query a\n"
					"          virtual CPU\n"
					"    -v    The virtual CPU address to query from the static definition\n"
					"          of the virtual image\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !cpuAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCpuQueryDmOutput* output;

	int rc = smImage_CPU_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, cpuAddress, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		char* cpuAddress = output->cpuAddress;

		char* baseCpu = "Unspecified";
		if (output->baseCpu == 0) {
			baseCpu = "Unspecified";
		} else if (output->baseCpu == 1) {
			baseCpu = "BASE";
		}

		char* cpuId = output->cpuId;

		char* dedicateCpu = "Unspecified";
		if (output->cpuDedicate == 0) {
			dedicateCpu = "Unspecified";
		} else if (output->cpuDedicate == 1) {
			dedicateCpu = "NODEDICATE";
		} else if (output->cpuDedicate == 2) {
			dedicateCpu = "DEDICATE";
		}

		char* crypto = "Unspecified";
		if (output->cpuCrypto == 0) {
			crypto = "Unspecified";
		} else if (output->cpuCrypto == 1) {
			crypto = "CRYPTO";
		}

		printf("Address: %i (%s)\n"
			"ID: %s\n"
			"Dedicated: %s\n"
			"CCF: %s\n", cpuAddress, baseCpu, cpuId, dedicateCpu, crypto);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCPUSetMaximumDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int maxCpu = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:m:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'm':
				maxCpu = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_CPU_Set_Maximum_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_CPU_Set_Maximum_DM [-T] image_name [-m] max_cpu\n\n"
					"DESCRIPTION\n"
					"  Use Image_CPU_Set_Maximum_DM to set the maximum number of virtual\n"
					"  processors that can be defined in a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T     The name of the virtual image for which to set the maximum\n"
					"           number of virtual processors\n"
					"    -m     The maximum number of virtual processors the user can define\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !maxCpu) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCpuSetMaximumDmOutput* output;

	int rc = smImage_CPU_Set_Maximum_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, maxCpu, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageCreateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * userEntryFile = NULL;
	char * prototype = "";
	char * password = "";
	char * accountNumber = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:p:w:a:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;
			case 'f':
				userEntryFile = optarg;
				break;
			case 'p':
				prototype = optarg;
				break;
			case 'w':
				password = optarg;
				break;
			case 'a':
				accountNumber = optarg;
				break;
			case 'h':
				printf("NAME\n"
					"  Image_Create_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Create_DM [-T] image_name [-f] user_entry_file\n"
					"  [-p] prototype [-w] password [-a] account_number\n\n"
					"DESCRIPTION\n"
					"  Use Image_Create_DM to define a new virtual image in the directory.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image to be created\n"
					"    -f    The user entry file\n"
					"  The following options are optional:\n"
					"    -p    The prototype to use for creating the image\n"
					"    -w    The logon password to be assigned initially to the virtual image\n"
					"          being created\n"
					"    -a    The account number to be assigned initially to the virtual image\n"
					"          being created\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Defining %s in the directory... ", image);
	if (!image || !userEntryFile) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageCreateDmOutput* output;

	// Open the user entry file
	FILE * fp = fopen(userEntryFile, "r");

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create image record
	vmApiImageRecord record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].imageRecordLength = strlen(line[i]);
		record[i].imageRecord = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	int rc = smImage_Create_DM(&context, "", 0, "", // Authorizing user, password length, password
				image, prototype,
				strlen(password), password, // Initial password length, initial password
				accountNumber, recordCount, // Initial account number, image record array length
				(vmApiImageRecord *) record, // Image record
				&output);

	// Handle async operation
	if (output->common.returnCode == 592 && output->operationId) {
		queryAsyncOperation(image, output->operationId);
	} else {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDeactivate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * forceTime = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'f':
				forceTime = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Deactivate\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Deactivate [-T] image_name [-f] force_time\n\n"
					"DESCRIPTION\n"
					"  Use Image_Deactivate to stop a virtual image or list of virtual images.\n"
					"  The virtual image(s) will no longer be active on the system.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being deactivated\n"
					"    -f    Specifies when the Image_Deactivate function is to take place:\n"
					"            IMMED: Immediate image deactivation\n"
					"            WITHIN interval: Where interval is a number of seconds in the\n"
					"                             the range 1–65535\n"
					"            BY time: Where time is specified as hh:mm or hh:mm:ss\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Stopping %s... ", image);
	if (!image || !forceTime) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDeactivateOutput* output;

	int rc = smImage_Deactivate(&context, "", 0, "", // Authorizing user, password length, password.
			image, forceTime, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->common.returnCode, output->common.reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int erase = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:e:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'e':
				erase = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Delete_DM [-T] image_name [-e] erase\n\n"
					"DESCRIPTION\n"
					"  Use Image_Delete_DM to delete a virtual image's definition from the directory.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image to be deleted\n"
					"    -e    Indicates whether to erase data from the disk(s) being released:\n"
					"            0: Unspecified (use installation default)\n"
					"            1: Do not erase (override installation default)\n"
					"            2: Erase (override installation default)\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Deleting %s from the directory... ", image);
	if (!image) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDeleteDmOutput* output;

	int rc = smImage_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, erase, &output);

	// Handle async operation
	if (output->common.returnCode == 592 && output->operationId) {
		queryAsyncOperation(image, output->operationId);
	} else {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDeviceDedicate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	char * realDevice = NULL;
	char * readOnly = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:r:o:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'r':
				realDevice = optarg;
				break;

			case 'o':
				readOnly = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Device_Dedicate\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Device_Dedicate [-T] image_name [-v] virtual_address\n"
					"  [-r] real_device_number [-o] readonly\n\n"
					"DESCRIPTION\n"
					"  Use Image_Device_Dedicate to add a dedicated device to an active virtual\n"
					"  image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image obtaining a dedicated device\n"
					"    -v    The virtual device number of the device\n"
					"    -r    A real device number to be dedicated or attached to the\n"
					"          specified virtual image\n"
					"    -o    Specify a 1 if the virtual device is to be in read-only\n"
					"          mode. Otherwise, specify a 0\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress || !realDevice || !readOnly) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	return 0;
}

int imageDeviceDedicateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualDevice = NULL;
	char * realDevice = NULL;
	int readOnly = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:r:R:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualDevice = optarg;
				break;

			case 'r':
				realDevice = optarg;
				break;

			case 'R':
				readOnly = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Device_Dedicate_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Device_Dedicate_DM [-T] image_name [-v] virtual_device_number\n"
					"    [-r] real_device_number [-R] read_only\n\n"
					"DESCRIPTION\n"
					"  Use Image_Device_Dedicate_DM to add a dedicated device to a virtual\n"
					"  image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image obtaining a dedicated device\n"
					"    -v    The virtual device number of the device\n"
					"    -r    A real device number to be dedicated or attached to the\n"
					"          specified virtual image\n"
					"    -R    Specify a 1 if the virtual device is to be in read-only mode.\n"
					"          Otherwise, specify a 0.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualDevice || !realDevice || !readOnly) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDeviceDedicateDmOutput* output;

	int rc = smImage_Device_Dedicate_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualDevice, realDevice, readOnly, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDeviceReset(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualDevice = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualDevice = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Device_Reset\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Device_Reset [-T] image_name [-v] virtual_device\n\n"
					"DESCRIPTION\n"
					"  Use Image_Device_Reset to clear all pending interrupts from the specified\n"
					"  virtual device.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name for which the device is being reset\n"
					"    -v    The virtual device number of the device to reset\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualDevice) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDeviceResetOutput* output;

	int rc = smImage_Device_Reset(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualDevice, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDeviceUndedicate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualDevice = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualDevice = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Device_Undedicate\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Device_Undedicate [-T] image_name [-v] virtual_device\n\n"
					"DESCRIPTION\n"
					"  Use Image_Device_Undedicate to delete a dedicated device from an active\n"
					"  virtual image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image from which a dedicated device is being\n"
					"          removed\n"
					"    -v    The virtual device number of the device to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualDevice) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDeviceUndedicateOutput* output;

	int rc = smImage_Device_Undedicate(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualDevice, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDeviceUndedicateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualDevice = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualDevice = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Device_Undedicate_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Device_Undedicate_DM [-T] image_name [-v] virtual_device\n\n"
					"DESCRIPTION\n"
					"  Use Image_Device_Undedicate_DM to delete a dedicated device from a virtual\n"
					"  image's directory entry\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image from which a dedicated device is being removed\n"
					"    -v    The virtual device number of the device to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualDevice) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDeviceUndedicateDmOutput* output;

	int rc = smImage_Device_Undedicate_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualDevice, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskCopy(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualDevice = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualDevice = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Copy\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Copy [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Copy to clone a disk in an active virtual image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name of the single image for which the disk is being copied\n"
					"    -v     The virtual device address of the target disk for the copy\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualDevice) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskCopyOutput* output;

	int rc = smImage_Disk_Copy(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualDevice, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskCopyDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * srcImage = NULL;
	char * srcDiskAddress = NULL;
	char * tgtDiskAddress = NULL;
	char * tgtImage = NULL;
	char * allocType = NULL;
	char * areaOrVolser = NULL;
	char * accessMode = NULL;
	char * readPass = NULL;
	char * writePass = NULL;
	char * multiPass = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:t:S:s:a:n:m:r:w:x:h?")) != -1)
		switch (option) {
			case 'S':
				srcImage = optarg;
				break;

			case 's':
				srcDiskAddress = optarg;
				break;

			case 'T':
				tgtImage = optarg;
				break;

			case 't':
				tgtDiskAddress = optarg;
				break;

			case 'a':
				allocType = optarg;
				break;

			case 'n':
				areaOrVolser = optarg;
				break;

			case 'm':
				accessMode = optarg;
				break;

			case 'r':
				readPass = optarg;
				break;

			case 'w':
				writePass = optarg;
				break;

			case 'x':
				multiPass = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Copy_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Copy_DM [-T] image_name [-s] src_disk_address\n"
					"  [-t] target_image [-u] target_disk_address [-a] alloc_type\n"
					"  [-n] area_or_volser [-m] access_mode [-r] read_password\n"
					"  [-w] write_password [-x] multi_password\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Copy_DM to clone a disk in a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name of the single image for which the disk is\n"
					"          being copied\n"
					"    -t    The virtual device address of the target disk for the copy\n"
					"    -S    The name of the virtual image that owns the image disk being copied\n"
					"    -s    The image disk number of the virtual image that owns the disk\n"
					"          being copied\n"
					"    -a    Disk allocation type:\n"
					"            The starting location\n"
					"            AUTOG: Automatic_Group_Allocation\n"
					"            AUTOR: Automatic_Region_Allocation\n"
					"            AUTOV: Automatic_Volume_Allocation\n"
					"            DEVNO: Full Volume Minidisk\n"
					"    -n    Allocation area name or volser\n"
					"    -m    The access mode requested for the disk:\n"
					"            R: Read-only (R/O) access\n"
					"            RR: Read-only (R/O) access\n"
					"            W: Write access\n"
					"            WR: Write access\n"
					"            M: Multiple access\n"
					"            MR: Write or any exclusive access\n"
					"            MW: Write access is allowed to the disk unconditionally\n"
					"  The following options are optional:\n"
					"    -r    Defines the read password that will be used for accessing the disk\n"
					"    -w    Defines the write password that will be used for accessing the disk\n"
					"    -x    Defines the multi password that will be used for accessing the disk\n");
				return 1;
				break;

			default:
				break;
		}
	if (!srcImage || !srcDiskAddress || !tgtDiskAddress || !tgtImage || !allocType || !areaOrVolser || !accessMode) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskCopyDmOutput* output;

	int rc = smImage_Disk_Copy_DM(&context, "", 0, "", // Authorizing user, password length, password.
			tgtImage, tgtDiskAddress, srcImage, srcDiskAddress, allocType, areaOrVolser,
			accessMode, readPass, writePass, multiPass, &output);

	// Handle async operation
	if (output->common.returnCode == 592 && output->operationId) {
		queryAsyncOperation(srcImage, output->operationId);
	} else {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskCreate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char* image = NULL;
	char* deviceAddr = NULL;
	char* accessMode = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:m:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				deviceAddr = optarg;
				break;

			case 'm':
				accessMode = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Create\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Create [-T] image_name [-v] virtual_address [-m] access_mode\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Create to add a disk that is defined in a virtual image's\n"
					"  directory entry to that virtual image's active configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name of the single image for which the disk\n"
					"          is being created.\n"
					"    -v    The virtual device address of the disk to be added\n"
					"    -m    The access mode requested for the disk\n"
					"            R: Read-only (R/O) access\n"
					"            RR: Read-only (R/O) access\n"
					"            W: Write access\n"
					"            WR: Write access\n"
					"            M: Multiple access\n"
					"            MR: Write or any exclusive access\n"
					"            MW: Write access is allowed to the disk unconditionally\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !deviceAddr || !accessMode) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskCreateOutput * output;

	int rc = smImage_Disk_Create(&context, "", 0, "", // Authorizing user, password length, password.
			image, deviceAddr, accessMode, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskCreateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char* image = NULL;
	char* deviceAddr = "";
	char* deviceType = "";
	char* allocType = "";
	char* allocName = "";
	int allocSize = 0;
	int diskSize = 0;
	char* accessMode = "";
	int diskFormat = 0;
	char* diskLabel = "";
	char* readPass = "";
	char* writePass = "";
	char* multiPass = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:t:a:r:u:z:m:f:l:R:W:M:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;
			case 'v':
				deviceAddr = optarg;
				break;
			case 't':
				deviceType = optarg;
				break;
			case 'a':
				allocType = optarg;
				break;
			case 'r':
				allocName = optarg;
				break;
			case 'u':
				allocSize = atoi(optarg);
				break;
			case 'z':
				diskSize = atoi(optarg);
				break;
			case 'm':
				accessMode = optarg;
				break;
			case 'f':
				diskFormat = atoi(optarg);
				break;
			case 'l':
				diskLabel = optarg;
				break;
			case 'R':
				readPass = optarg;
				break;
			case 'W':
				writePass = optarg;
				break;
			case 'M':
				multiPass = optarg;
				break;
			case 'h':
				printf("NAME\n"
					"  Image_Disk_Create_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Create_DM [-T] image_name [-v] virtual_address\n"
					"    [-t] device_type [-a] allocation_type [-r] area_name_or_volser\n"
					"    [-u] unit_size [-z] disk_size [-m] access_mode\n"
					"    [-f] disk_format [-l] disk_label [-R] read_password\n"
					"    [-W] write_password [-M] multi_password\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Create_DM to add a disk to a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or image name of the single image for which the disk\n"
					"          is being created\n"
					"    -v    The virtual device address of the disk to be added\n"
					"    -t    The device type of the volume to which the disk is assigned\n"
					"    -a    Allocation type:\n"
					"            AUTOG: Automatic_Group_Allocation\n"
					"            AUTOR: Automatic_Region_Allocation\n"
					"            AUTOV: Automatic_Volume_Allocation\n"
					"            DEVNO: Full Volume Minidisk\n"
					"            T-DISK: Automatic Temporary Disk\n"
					"            V-DISK: Automatic Virtual Disk\n"
					"              In this case, image_disk_device_type must have value = FB-512\n"
					"    -r    Allocation area name or volser:\n"
					"            - The group or region where the new image disk is to be created.\n"
					"              This is specified when allocationtype is AUTOG or AUTOR.\n"
					"            - The label of the DASD volume where the new image disk is to\n"
					"              be created. This is specified when allocation type is the\n"
					"              starting location or AUTOV.\n"
					"            - The device address of the full volume minidisk where the new\n"
					"              image disk is to be created. This is specified when allocation\n"
					"              type is DEVNO.\n"
					"    -u    Unit size:\n"
					"            1: CYLINDERS\n"
					"            2: BLK0512\n"
					"            3: BLK1024\n"
					"            4: BLK2048\n"
					"            5: BLK4096\n"
					"    -z    The size of the disk to be created:\n"
					"            - Cylinders, if the allocation_unit_size is CYLINDERS\n"
					"            - Logical disk blocks of size nnnn if allocation_unit_size is\n"
					"              BLKnnnn. nnnn is either 512 (or 0512), 1024, 2048, or 4096.\n"
					"    -m    The access mode requested for the disk:\n"
					"            R: Read-only (R/O) access\n"
					"            RR: Read-only (R/O) access\n"
					"            W: Write access\n"
					"            WR: Write access\n"
					"            M: Multiple access\n"
					"            MR: Write or any exclusive access\n"
					"            MW: Write access is allowed to the disk unconditionally\n"
					"    -f    Disk format:\n"
					"            0: Unspecified\n"
					"            1: Unformatted\n"
					"            2: CMS formatted with 512 bytes per block\n"
					"            3: CMS formatted with 1024 bytes per block\n"
					"            4: CMS formatted with 2048 bytes per block\n"
					"            5: CMS formatted with 4096 bytes per block\n"
					"            6: CMS formatted with the default block size for the allocated\n"
					"               device type\n"
					"  The following options are optional:\n"
					"    -l    The disk label to use when formatting the new extent\n"
					"    -R    Read password\n"
					"    -W    Write password\n"
					"    -M    Multi password\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Adding a disk to %s's directory entry... ", image);
	if (!image || !deviceAddr || !deviceType || !allocType || !allocName || !allocSize || !diskSize || !accessMode) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;

	vmApiImageDiskCreateDmOutput* output;

	int rc = smImage_Disk_Create_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, deviceAddr, deviceType, allocType, allocName, allocSize,
			diskSize, accessMode, diskFormat, diskLabel,
			readPass, writePass, multiPass, // Read, write, and multi passwords
			&output);

	// Handle async operation
	if (output->common.returnCode == 592 && output->operationId) {
		queryAsyncOperation(image, output->operationId);
	} else {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Delete [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Delete to delete a disk from an active virtual image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which the disk is being deleted\n"
					"    -v    The virtual device address of the disk to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !address) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskDeleteOutput * output;

	int rc = smImage_Disk_Delete(&context, "", 0, "", // Authorizing user, password length, password.
			image, address, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	int securityErase = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:e:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'e':
				securityErase = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Delete_DM [-T] image_name [-v] virtual_address\n"
					"    [-e] security_erase\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Delete_DM to delete a disk from a virtual image's directory\n"
					"  entry.\n\n"
					"  The following options are required:\n"
					"    -T    Target image or authorization entry name\n"
					"    -v    The virtual device address of the disk to be deleted.\n"
					"    -e    Indicates whether to erase data from the disk(s) being released:\n"
					"            0: Unspecified (use installation default)\n"
					"            1: Do not erase (override installation default)\n"
					"            2: Erase (override installation default)\n");
				return 1;
				break;

			default:
				break;
		}

	printf("Deleting a disk from %s's directory entry... ", image);
	if (!image || !virtualAddress || !securityErase) {
		printf("\nERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskDeleteDmOutput* output;

	int rc = smImage_Disk_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualAddress, securityErase, &output);

	// Handle async operation
	if (output->common.returnCode == 592 && output->operationId) {
		queryAsyncOperation(image, output->operationId);
	} else {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskShare(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = NULL;
	char * tgtImage = NULL;
	char * tgtAddress = NULL;
	char * accessMode = NULL;
	char * password = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:t:r:a:p:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 't':
				tgtImage = optarg;
				break;

			case 'r':
				tgtAddress = optarg;
				break;

			case 'a':
				accessMode = optarg;
				break;

			case 'p':
				password = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Share\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Share [-T] image_name [-v] virtual_address [-t] target_image\n"
					"  [-r] target_address [-a] access_mode [-p] password\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Share to add a disk that is defined in a virtual\n"
					"  image's directory entry to a different active virtual image's\n"
					"  configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the single image attempting to share the disk\n"
					"    -v    The virtual device address of the disk to be shared\n"
					"    -t    The name of the virtual image that owns the image disk\n"
					"          being shared\n"
					"    -r    The virtual device number to assign to the shared disk\n"
					"    -a    The access mode requested for the disk:\n"
					"            R: Read-only (R/O) access\n"
					"            RR: Read-only (R/O) access\n"
					"            W: Write access\n"
					"            WR: Write access\n"
					"            M: Multiple access\n"
					"            MR: Write or any exclusive access\n"
					"            MW: Write access is allowed to the disk unconditionally\n"
					"  The following options are optional:\n"
					"    -p    The password that may be required to share the disk\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !address || !tgtImage || !tgtAddress || !accessMode) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskShareOutput* output;

	int rc = smImage_Disk_Share(&context, "", 0, "", // Authorizing user, password length, password.
			image, address, tgtImage, tgtAddress, accessMode, password, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskShareDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = NULL;
	char * tgtImage = NULL;
	char * tgtAddress = NULL;
	char * accessMode = NULL;
	char * password = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:t:r:a:p:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 't':
				tgtImage = optarg;
				break;

			case 'r':
				tgtAddress = optarg;
				break;

			case 'a':
				accessMode = optarg;
				break;

			case 'p':
				password = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Share_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Share_DM [-T] image_name [-v] virtual_address\n"
					"  [-t] target_image [-r] target_address [-a] access_mode\n"
					"  [-p] password\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Share_DM to add a disk that is defined in a virtual\n"
					"  image's directory entry to a different virtual image's directory entry\n\n"
					"    -T    The name of the single image attempting to share the disk\n"
					"    -v    The virtual device address of the disk to be shared\n"
					"    -t    The name of the virtual image that owns the image disk\n"
					"          being shared\n"
					"    -r    The virtual device number to assign to the shared disk\n"
					"    -a    The access mode requested for the disk:\n"
					"            R: Read-only (R/O) access\n"
					"            RR: Read-only (R/O) access\n"
					"            W: Write access\n"
					"            WR: Write access\n"
					"            M: Multiple access\n"
					"            MR: Write or any exclusive access\n"
					"            MW: Write access is allowed to the disk unconditionally\n"
					"    -p    The password that may be required to share the disk\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !address || !tgtImage || !tgtAddress || !accessMode || !password) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskShareDmOutput* output;

	int rc = smImage_Disk_Share_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, address, tgtImage, tgtAddress, accessMode, password, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskUnshare(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Unshare\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Unshare [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Unshare to delete a shared disk from an active\n"
					"  virtual image's configuration.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image from which the previously-shared\n"
					"          disk is to be removed from the configuration\n"
					"    -v    The virtual device address of the previously-shared\n"
					"          disk to be removed from the configuration\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !address) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskUnshareOutput* output;

	int rc = smImage_Disk_Unshare(&context, "", 0, "", // Authorizing user, password length, password.
			image, address, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageDiskUnshareDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = NULL;
	char * tgtImage = NULL;
	char * tgtAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:t:r:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 't':
				tgtImage = optarg;
				break;

			case 'r':
				tgtAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Unshare_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Unshare_DM [-T] image_name [-v] virtual_address\n"
					"  [-t] target_image [-r] target_virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_Disk_Unshare_DM to delete a shared disk from a virtual\n"
					"  image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image from which the previously-shared\n"
					"          disk is to be removed from the configuration\n"
					"    -v    The virtual device address of the previously-shared\n"
					"          disk to be removed from the configuration\n"
					"    -t    The name of the virtual image that owns the previously-shared\n"
					"          disk to be removed from the configuration\n"
					"    -r    The virtual device number previously assigned to the shared\n"
					"          disk\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !address || !tgtImage || !tgtAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageDiskUnshareDmOutput* output;

	int rc = smImage_Disk_Unshare_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, address, tgtImage, tgtAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageIPLDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_IPL_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_IPL_Delete_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_IPL_Delete_DM to delete the IPL statement from a virtual\n"
					"  image's directory entry or a profile directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    Specifies the name of the user or profile for which the IPL\n"
					"          statement is to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageIplDeleteDmOutput* output;

	int rc = smImage_IPL_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageIPLQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_IPL_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_IPL_Query_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_IPL_Query_DM to query the information about the operating\n"
					"  system, or device containing the operating system, that is specified\n"
					"  on the IPL statement in a virtual image's directory entry or a\n"
					"  profile directory entry. This operating system is automatically\n"
					"  loaded and started when the virtual image is activated.\n\n"
					"  The following options are required:\n"
					"    -T    Specifies the name of the user or profile for which the IPL\n"
					"          statement is to be queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageIplQueryDmOutput* output;

	int rc = smImage_IPL_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		printf("IPL: %s\n"
			"Load parameter: %s\n"
			"Parameters: %s\n", output->savedSystem, output->loadParameter,
				output->parameters);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageIPLSetDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * savedSystem = "";
	char * loadParameter = "";
	char * parameter = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:l:p:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				savedSystem = optarg;
				break;

			case 'l':
				loadParameter = optarg;
				break;

			case 'p':
				parameter = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_IPL_Set_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_IPL_Set_DM [-T] image_name [-s] saved_system\n"
					"    [-l] load_parameter [-p] parameter\n\n"
					"DESCRIPTION\n"
					"  Use Image_IPL_Set_DM to add an IPL statement to a virtual image's\n"
					"  directory entry or a profile directory entry. The IPL statement\n"
					"  identifies an operating system, or a device containing an operating\n"
					"  system, which is automatically loaded and started when the virtual\n"
					"  image is activated.\n\n"
					"  The following options are required:\n"
					"    -T    Specifies the name of the user or profile for which the\n"
					"          IPL statement is to be set.\n"
					"    -s    Specifies the name of the saved system or virtual device\n"
					"          address of the device containing the system to be loaded.\n"
					"    -l    Specifies the load parameter (up to 8 characters) that is\n"
					"          used by the IPL'd system. It may be necessary to enclose\n"
					"          the load parameter in single quotes.\n"
					"    -p    Specifies the parameters to be passed to the IPL'd operating\n"
					"          system. Although the IPL command allows for 64 bytes of\n"
					"          parameters, the string on the directory statement is limited\n"
					"          to the number of characters that can be specified in the first\n"
					"          72 positions of the statement.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageIplSetDmOutput* output;

	int rc = smImage_IPL_Set_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, savedSystem, loadParameter, parameter, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageLockDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Profile_Lock_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Profile_Lock_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Profile_Lock_DM to lock a profile directory entry so that it cannot be changed.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the profile to be locked\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageLockDmOutput * output;

	int rc = smImage_Lock_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, "", // Image name, device virtual address
			&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageNameQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "h?")) != -1)
		switch (option) {
			case 'h':
				printf("NAME\n"
					"  Image_Name_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Name_Query_DM\n\n"
					"DESCRIPTION\n"
					"  Use Image_Name_Query_DM to obtain a list of defined virtual images.\n");
				return 1;
				break;

			default:
				break;
		}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageNameQueryDmOutput* output;

	int rc = smImage_Name_Query_DM(&context, "", 0, "", // Authorizing user, password length, password
			"FOOBAR", // Does not matter what image name is used
			&output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out image names
		int i;
		int n = output->nameCount;
		for (i = 0; i < n; i++) {
			printf("%s\n", output->nameList[i]);
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imagePasswordSetDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * password = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:p:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'p':
				password = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Password_Set_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Password_Set_DM [-T] image_name [-p] password\n\n"
					"DESCRIPTION\n"
					"  Use Image_Password_Set_DM to set or change a virtual image's password.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which the password is being set\n"
					"    -p    The password or passphrase to set for the image\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !password) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImagePasswordSetDmOutput* output;

	int rc = smImage_Password_Set_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, strlen(password), password, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageQueryActivateTime(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int format = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'f':
				format = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Query_Activate_Time\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Query_Activate_Time [-T] image_name [-f] format\n\n"
					"DESCRIPTION\n"
					"  Use Image_Query_Activate_Time to obtain the date and time when a virtual\n"
					"  image was activated.\n\n"
					"  The following options are required:\n"
					"    -T    To specify which virtual image's activation date and time is\n"
					"          being queried\n"
					"    -f    The format of the date stamp that is returned:\n"
					"            1: mm/dd/yy\n"
					"            2: mm/dd/yyyy\n"
					"            3: yy-mm-dd\n"
					"            4: yyyy-mm-dd\n"
					"            5: dd/mm/yy\n"
					"            6: dd/mm/yyyy\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !format) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageQueryActivateTimeOutput* output;

	int rc = smImage_Query_Activate_Time(&context, "", 0, "", // Authorizing user, password length, password
			image, format, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		char * image = output->imageName;
		char * actDate = output->activationDate;
		char * actTime = output->activationTime;
		printf("%s was activated on %s at %s\n", image, actDate, actTime);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

/**
 * Use Image_Query_DM to obtain a virtual image's directory entry
 */
int imageQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Query_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_Query_DM to obtain a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being queried\n");
				return 1;
				break;

			default:
				break;
		}

    if (!image) {
    	printf("ERROR: Missing required options\n");
    	return 1;
    }

    // Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageQueryDmOutput * output;

	int rc = smImage_Query_DM(&context, "", 0, "", image, &output, false);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out directory entry
		int recCount = output->imageRecordCount;
		int recLen = output->imageRecordList[0].imageRecordLength - 8;
		char line[recLen], chs[4];
		if (recCount > 0) {
			int i;
			int token = 0;
			for (i = 0; i < recCount; i++) {
				memset(line, 0, recLen);
				memcpy(line, output->imageRecordList[i].imageRecord, recLen);
				trim(line);
				printf("%s\n", line);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageRecycle(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Recycle\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Recycle [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_Recycle to deactivate and then reactivate a virtual image or\n"
					"  list of virtual images.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being recycled\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageRecycleOutput* output;

	int rc = smImage_Recycle(&context, "", 0, "", // Authorizing user, password length, password
			image, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->common.returnCode, output->common.reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageReplaceDM(int argC, char* argV[]) {
	// IMPORTANT: Image must be locked before it can be replaced

	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * imageFile = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'f':
				imageFile = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Replace_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Replace_DM [-T] image_name [-f] user_entry_file\n\n"
					"DESCRIPTION\n"
					"  Use Image_Replace_DM to replace a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image to be replaced\n"
					"    -f    The virtual image's directory entry file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageReplaceDmOutput* output;

	// Open the user entry file
	FILE * fp = fopen(imageFile, "r");

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create image record
	vmApiImageRecord record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].imageRecordLength = strlen(line[i]);
		record[i].imageRecord = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	int rc = smImage_Replace_DM(&context, "", 0, "", // Authorizing user, password length, password
				image, recordCount,
				(vmApiImageRecord *) record, // Image record
				&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageSCSICharacteristicsDefineDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * bootProgram = NULL;
	char * logicalBlock = NULL;
	char * lun = NULL;
	char * portName = NULL;
	int scpType = 0;
	char * scpData = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:b:k:l:p:s:d:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'b':
				bootProgram = optarg;
				break;

			case 'k':
				logicalBlock = optarg;
				break;

			case 'l':
				lun = optarg;
				break;

			case 'p':
				portName = optarg;
				break;

			case 's':
				scpType = atoi(optarg);
				break;

			case 'd':
				scpData = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_SCSI_Characteristics_Define_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_SCSI_Characteristics_Define_DM [-T] image_name\n"
					"  [-b] boot_program [-k] logical_block [-l] lun [-p] port_name\n"
					"  [-s] scp_data_type [-d] scp_data\n\n"
					"DESCRIPTION\n"
					"  Use Image_SCSI_Characteristics_Define_DM to define or change the\n"
					"  location of a program to be loaded as a result of an FCP\n"
					"  list-directed IPL, and the data to be passed to the loaded program,\n"
					"  in a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The target image name whose LOADDEV is being set\n"
					"    -b    The boot program number (which must be a value in the range\n"
					"          0 to 30), or the keyword 'DELETE' to delete the existing\n"
					"          boot program number. If null, the boot program number will\n"
					"          be unchanged\n"
					"    -k    The logical-block address of the boot record, or the keyword\n"
					"          'DELETE' to delete the existing logical-block address. If\n"
					"          null, the logical-block address will be unchanged\n"
					"    -l    The logical unit number, or the keyword 'DELETE' to delete\n"
					"          the existing logical unit number. If null, the logical unit\n"
					"          number will be unchanged\n"
					"    -p    The port name, or the keyword 'DELETE' to delete the existing\n"
					"          port name. If null, the port name will be unchanged\n"
					"    -s    The type of data specified in the SCP_data parameter, as\n"
					"          follows:\n"
					"            0: Unspecified\n"
					"            1: DELETE – delete the SCP_data for the image\n"
					"            2: EBCDIC – EBCDIC (codepage 924) data\n"
					"            3: HEX – UTF-8 encoded hex data\n"
					"    -d    The SCP data\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !bootProgram || !logicalBlock || !lun || !portName || !scpType || !scpData) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageScsiCharacteristicsDefineDmOutput* output;

	int rc = smImage_SCSI_Characteristics_Define_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, bootProgram, logicalBlock, lun, portName, scpType, strlen(scpData), scpData, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageSCSICharacteristicsQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_SCSI_Characteristics_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_SCSI_Characteristics_Query_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_SCSI_Characteristics_Query_DM to obtain the location of a program\n"
					"  to be loaded as a result of an FCP list-directed IPL, and the data to be\n"
					"  passed to the loaded program, from a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The target userid whose LOADDEV is being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageScsiCharacteristicsQueryDmOutput* output;

	int rc = smImage_SCSI_Characteristics_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
		image, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		char * bootProgram = output->bootProgramNumber;
		char * logicalBlock = output->br_LBA;
		char * lun = output->lun;
		char * portName = output->port;
		char * scpData = output->scpData;

		printf("Boot program number: %s\n"
			"Logical-block address of the boot record: %s\n"
			"Logical unit number: %s\n"
			"Port name: %s\n"
			"Type of data: %s\n", bootProgram, logicalBlock, lun, portName, scpData);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageStatusQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Status_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Status_Query [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_Status_Query to determine whether virtual images are\n"
					"  active (logged on or logged on disconnected) or inactive.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageStatusQueryOutput* output;

	int rc = smImage_Status_Query(&context, "", 0, "", // Authorizing user, password length, password.
		image, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out directory entry
		int imageCount = output->imageNameCount;
		if (imageCount > 0) {
			int i;
			for (i = 0; i < imageCount; i++) {
				printf("%s\n", output->imageNameList[i].imageName);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageUnlockDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Unlock_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Unlock_DM [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Image_Unlock_DM to unlock a virtual image's directory entry\n"
					"  or a specific device in a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image to be unlocked\n"
					"  The following options are optional:\n"
					"    -v    The virtual address of the device being unlocked\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageUnlockDmOutput * output;

	int rc = smImage_Unlock_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, address, // Image name, device virtual address
			&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageVolumeAdd(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = "";
	char * volId = "";
	char * sysConfName = "";
	char * sysConfType = "";
	char * parmDiskOwner = "";
	char * parmDiskNumber = "";
	char * parmDiskPass = "";
	char * altSysConfName = "";
	char * altSysConfType = "";
	char * altParmDiskNumber = "";
	char * altParmDiskOwner = "";
	char * altParmDiskPass = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:l:s:t:o:p:w:c:y:n:m:x:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 'l':
				volId = optarg;
				break;

			case 's':
				sysConfName = optarg;
				break;

			case 't':
				sysConfType = optarg;
				break;

			case 'o':
				parmDiskOwner = optarg;
				break;

			case 'p':
				parmDiskNumber = optarg;
				break;

			case 'w':
				parmDiskPass = optarg;
				break;

			case 'c':
				altSysConfName = optarg;
				break;

			case 'y':
				altSysConfType = optarg;
				break;

			case 'n':
				altParmDiskNumber = optarg;
				break;

			case 'm':
				altParmDiskOwner = optarg;
				break;

			case 'x':
				altParmDiskPass = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Volume_Add\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Volume_Add [-T] image_name [-v] virtual_address\n"
					"  [-l] volid [-s] sys_conf_name [-t] sys_conf_type [-o] parm_disk_owner\n"
					"  [-p] parm_disk_number [-w] parm_disk_password [-c] alt_sys_conf_name\n"
					"  [-y] alt_sys_conf_type [-n] alt_parm_disk_owner [-m] alt_parm_disk_number\n"
					"  [-x] alt_parm_disk_password\n"
					"DESCRIPTION\n"
					"  Use Image_Volume_Add to add a DASD volume to be used by virtual images\n"
					"  to the z/VM system configuration file.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image to which a volume is being added\n"
					"    -v    The virtual device number of the device\n"
					"    -l    The DASD volume label\n"
					"    -s    File name of system configuration file. The default is 'SYSTEM'.\n"
					"    -t    File type of system configuration file. The default is 'CONFIG'.\n"
					"    -o    Owner of the parm disk. The default is 'MAINT''."
					"    -p    Number of the parm disk as defined in the VSMWORK1 directory\n"
					"    -w    Multiwrite password for the parm disk. The default is ','.\n"
					"    -c    File name of the second, or alternative, system configuration file\n"
					"    -y    File type of the second, or alternative, system configuration file.\n"
					"          The default is 'CONFIG'.\n"
					"    -n    Owner of the second, or alternative, parm disk.\n"
					"          The default is 'MAINT'.\n"
					"    -m    Number of the second, or alternative, parm disk.\n"
					"          The default is 'CF2'.\n"
					"    -x    Multiwrite password for the alternate parm disk.\n"
					"          The default is ','.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !address || !volId || !sysConfName || !sysConfType || !parmDiskOwner || !parmDiskNumber
			|| !parmDiskPass || !altSysConfName || !altSysConfType || !altParmDiskOwner || !altParmDiskNumber
			|| !altParmDiskPass) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageVolumeAddOutput * output;

	int rc = smImage_Volume_Add(&context, "", 0, "", // Authorizing user, password length, password
			image, address, volId, sysConfName, sysConfType, parmDiskOwner, parmDiskNumber, parmDiskPass,
			altSysConfName, altSysConfType, altParmDiskOwner, altParmDiskNumber, altParmDiskPass,
			&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageVolumeDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * address = "";
	char * volId = "";
	char * sysConfName = "";
	char * sysConfType = "";
	char * parmDiskOwner = "";
	char * parmDiskNumber = "";
	char * parmDiskPass = "";
	char * altSysConfName = "";
	char * altSysConfType = "";
	char * altParmDiskNumber = "";
	char * altParmDiskOwner = "";
	char * altParmDiskPass = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:l:s:t:o:p:w:c:y:n:m:x:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				address = optarg;
				break;

			case 'l':
				volId = optarg;
				break;

			case 's':
				sysConfName = optarg;
				break;

			case 't':
				sysConfType = optarg;
				break;

			case 'o':
				parmDiskOwner = optarg;
				break;

			case 'p':
				parmDiskNumber = optarg;
				break;

			case 'w':
				parmDiskPass = optarg;
				break;

			case 'c':
				altSysConfName = optarg;
				break;

			case 'y':
				altSysConfType = optarg;
				break;

			case 'n':
				altParmDiskNumber = optarg;
				break;

			case 'm':
				altParmDiskOwner = optarg;
				break;

			case 'x':
				altParmDiskPass = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Volume_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Volume_Delete [-T] image_name [-v] virtual_address\n"
					"  [-l] volid [-s] sys_conf_name [-t] sys_conf_type [-o] parm_disk_owner\n"
					"  [-p] parm_disk_number [-w] parm_disk_password [-c] alt_sys_conf_name\n"
					"  [-y] alt_sys_conf_type [-n] alt_parm_disk_owner [-m] alt_parm_disk_number\n"
					"  [-x] alt_parm_disk_password\n"
					"DESCRIPTION\n"
					"  Use Image_Volume_Delete to delete a DASD volume definition from the z/VM\n"
					"  system configuration file.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being activated\n"
					"    -v    The virtual device number of the device\n"
					"    -l    The DASD volume label\n"
					"    -s    File name of system configuration file. The default is 'SYSTEM'.\n"
					"    -t    File type of system configuration file. The default is 'CONFIG'.\n"
					"    -o    Owner of the parm disk. The default is 'MAINT''."
					"    -p    Number of the parm disk as defined in the VSMWORK1 directory\n"
					"    -w    Multiwrite password for the parm disk. The default is ','.\n"
					"    -c    File name of the second, or alternative, system configuration file\n"
					"    -y    File type of the second, or alternative, system configuration file.\n"
					"          The default is 'CONFIG'.\n"
					"    -n    Owner of the second, or alternative, parm disk.\n"
					"          The default is 'MAINT'.\n"
					"    -m    Number of the second, or alternative, parm disk.\n"
					"          The default is 'CF2'.\n"
					"    -x    Multiwrite password for the alternate parm disk.\n"
					"          The default is ','.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !address || !volId || !sysConfName || !sysConfType || !parmDiskOwner || !parmDiskNumber
			|| !parmDiskPass || !altSysConfName || !altSysConfType || !altParmDiskOwner || !altParmDiskNumber
			|| !altParmDiskPass) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageVolumeAddOutput * output;

	int rc = smImage_Volume_Delete(&context, "", 0, "", // Authorizing user, password length, password
			image, address, volId, sysConfName, sysConfType, parmDiskOwner, parmDiskNumber, parmDiskPass,
			altSysConfName, altSysConfType, altParmDiskOwner, altParmDiskNumber, altParmDiskPass,
			&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageVolumeSpaceDefineDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int function = 0;
	char * regionName = NULL;
	char * volumeId = NULL;
	int startCylinder = -1;
	int regionSize = -1;
	char * groupName = NULL;
	int deviceType = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:g:v:s:z:p:y:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'f':
				function = atoi(optarg);
				break;

			case 'g':
				regionName = optarg;
				break;

			case 'v':
				volumeId = optarg;
				break;

			case 's':
				startCylinder = atoi(optarg);
				break;

			case 'z':
				regionSize = atoi(optarg);
				break;

			case 'p':
				groupName = optarg;
				break;

			case 'y':
				deviceType = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Volume_Space_Define_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Volume_Space_Define_DM [-T] image_name [-f] function_type\n"
					"    [-g] region_name [-v] vol_id [-s] start_cylinder [-z] size"
					"    [-p] group_name [-y] device_type\n\n"
					"DESCRIPTION\n"
					"  Use Image_Volume_Space_Define_DM to define space on a DASD\n"
					"  volume to be allocated by the directory manager for use by\n"
					"  virtual images.\n\n"
					"  The following options are required:\n"
					"    -T    Target image or authorization entry name\n"
					"    -f    Function type:\n"
					"            1: Define region as specified. image_volid,\n"
					"               region_name, start_cylinder, and size are\n"
					"               required for this function\n"
					"            2: Define region as specified and add to group.\n "
					"               image_vol_id, region_name, start_cylinder, size,\n"
					"               and group_name are required for this function\n"
					"            3: Define region as full volume. vol_id and\n"
					"               region_name are required for this function\n"
					"            4: Define region as full volume and add to group.\n"
					"               vol_id, region_name, and group_name are\n"
					"               required for this function\n"
					"            5: Add existing region to group. (This function also\n"
					"               defines the group if it does not already exist.)\n"
					"               region_name and Group are required for this function.\n"
					"    -g    The region to be defined\n"
					"    -v    The DASD volume label\n"
					"    -s    The starting point of the region\n"
					"    -z    The number of cylinders to be used by region\n"
					"    -p    The name of the group to which the region is assigned\n"
					"    -y    The device type designation:\n"
					"            0: Unspecified\n"
					"            1: 3390\n"
					"            2: 9336\n"
					"            3: 3380\n"
					"            4: FB-512\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !function || !regionName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageVolumeSpaceDefineDmOutput* output;

	int rc = smImage_Volume_Space_Define_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, function, regionName, volumeId, startCylinder, regionSize,
			groupName, deviceType, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageVolumeSpaceQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int query = 0;
	int entry = 0;
	char * entryName = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:q:e:n:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'q':
				query = atoi(optarg);
				break;

			case 'e':
				entry = atoi(optarg);
				break;

			case 'n':
				entryName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Volume_Space_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Volume_Space_Query_DM [-T] image_name [-q] query_type [-e] entry_type [-n] entry_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_Volume_Space_Query_DM to query how space on a DASD volume\n"
					"  is allocated by the directory manager.\n\n"
					"  The following options are required:\n"
					"    -T    Target image or authorization entry name\n"
					"    -q    Query type:\n"
					"            1: Query volume definition\n"
					"            2: Query amount of free space available\n"
					"            3: Query amount of space used\n"
					"    -e    Entry type:\n"
					"            1: Query specified volume\n"
					"            2: Query specified region\n"
					"            3: Query specified group\n"
					"  The following options are optional:\n"
					"    -n    Entry name\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !query || !entry) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageVolumeSpaceQueryDmOutput * output;

	// Handle return code and reason code
	int rc = smImage_Volume_Space_Query_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, query, entry, entryName, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out image volumes
		int i, length;
		int recCount = output->recordCount;
		int p = 0;
		for (i = 0; i < recCount; i++) {
			length = output->recordList[i].imageRecordLength;
			printf("%.*s\n", length, output->recordList[0].imageRecord + p);
			p = p + length;
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int imageVolumeSpaceRemoveDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int functionType = 0;
	char * regionName = "";
	char * volId = "";
	char * groupName = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:r:v:g:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'f':
				functionType = atoi(optarg);
				break;

			case 'r':
				regionName = optarg;
				break;

			case 'v':
				volId = optarg;
				break;

			case 'g':
				groupName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Volume_Space_Remove_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Volume_Space_Remove_DM [-T] image_name [-f] function_type\n"
					"    [-r] region_name [-v] image_volid [-g] group_name\n\n"
					"DESCRIPTION\n"
					"  Use Image_Volume_Space_Remove_DM to remove the directory manager's\n"
					"  space allocations from a DASD volume.\n\n"
					"  The following options are required:\n"
					"    -T    Target image or authorization entry name\n"
					"    -f    Function type:\n"
					"            1: Remove named region. RegionName is required for this function.\n"
					"            2: Remove named region from group. region_name and group_name are\n"
					"               required for this function.\n"
					"            3: Remove named region from all groups. region_name is required\n"
					"               for this function.\n"
					"            4: Remove all regions from specific volume. image_volid is required\n"
					"               for this function.\n"
					"            5: Remove all regions from specific volume and group. image_volid\n"
					"               and group_name are required for this function.\n"
					"            6: Remove all regions from specific volume and all groups.\n"
					"               image_volid is required for this function.\n"
					"            7: Remove entire group. group_name is required for this function.\n"
					"    -r    The region to be defined\n"
					"    -v    The DASD volume label\n"
					"    -g    The name of the group to which the region is assigned\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !functionType) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageVolumeSpaceRemoveDmOutput* output;

	int rc = smImage_Volume_Space_Remove_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, functionType, regionName, volId, groupName,
			&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int nameListAdd(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * nameList = NULL;
	char * name = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:h?")) != -1)
		switch (option) {
			case 'T':
				nameList = optarg;
				break;

			case 'n':
				name = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Name_List_Add\n\n"
					"SYNOPSIS\n"
					"  smcli Name_List_Add [-T] name_list [-n] name\n\n"
					"DESCRIPTION\n"
					"  Use Name_List_Add to add a name to a list in the name list file.\n"
					"  If the list that is specified in target_identifier does not exist,\n"
					"  a new list will be created.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the list that is being updated\n"
					"    -n    The name to be added to the list specified\n");
				return 1;
				break;

			default:
				break;
		}

	if (!nameList || !name) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiNameListAddOutput* output;

	int rc = smName_List_Add(&context, "", 0, "", // Authorizing user, password length, password.
			nameList, name, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int nameListDestroy(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * nameList = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				nameList = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Name_List_Destroy\n\n"
					"SYNOPSIS\n"
					"  smcli Name_List_Destroy [-T] name_list\n\n"
					"DESCRIPTION\n"
					"  Use Name_List_Destroy to destroy a list from the name list file.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the list being destroyed\n");
				return 1;
				break;

			default:
				break;
		}

	if (!nameList) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiNameListDestroyOutput* output;

	int rc = smName_List_Destroy(&context, "", 0, "", // Authorizing user, password length, password.
			nameList, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int nameListQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * nameList = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				nameList = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Name_List_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Name_List_Query [-T] name_list\n\n"
					"DESCRIPTION\n"
					"  Use Name_List_Query to query the names that are in a list in the name list file.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the list being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!nameList) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiNameListQueryOutput* output;

	int rc = smName_List_Query(&context, "", 0, "", // Authorizing user, password length, password.
			nameList, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->common.returnCode, output->common.reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int nameListRemove(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * nameList = NULL;
	char * name = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:h?")) != -1)
		switch (option) {
			case 'T':
				nameList = optarg;
				break;

			case 'n':
				name = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Name_List_Remove\n\n"
					"SYNOPSIS\n"
					"  smcli Name_List_Remove [-T] name_list [-n] name\n\n"
					"DESCRIPTION\n"
					"  Use Name_List_Remove to delete a name from a list in the name list\n"
					"  file. If there are no names remaining in the list, the list is also\n"
					"  deleted.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the list that is being updated\n"
					"    -n    A userid or function name or list\n");
				return 1;
				break;

			default:
				break;
		}

	if (!nameList || !name) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiNameListRemoveOutput* output;

	int rc = smName_List_Remove(&context, "", 0, "", // Authorizing user, password length, password.
			nameList, name, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int profileCreateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * profile = NULL;
	char * profileFile = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:h?")) != -1)
		switch (option) {
			case 'T':
				profile = optarg;
				break;

			case 'f':
				profileFile = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Profile_Create_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Profile_Create_DM [-T] profile_name [-f] profile_file\n\n"
					"DESCRIPTION\n"
					"  Use Profile_Create_DM to create a profile directory entry to be included\n"
					"  in the definition of a virtual image in the directory.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the profile to be created\n"
					"    -f    The profile directory entry file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!profile || !profileFile) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiProfileCreateDmOutput* output;

	// Open the user entry file
	FILE * fp = fopen(profileFile, "r");

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create image record
	vmApiProfileRecord record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].profileRecordLength = strlen(line[i]);
		record[i].recordData = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	int rc = smProfile_Create_DM(&context, "", 0, "", // Authorizing user, password length, password
				profile, recordCount,
				(vmApiProfileRecord *) record, // Image record
				&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int profileDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * profile = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "t:h?")) != -1)
		switch (option) {
			case 't':
				profile = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Profile_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Profile_Delete_DM [-t] profile_name\n\n"
					"DESCRIPTION\n"
					"  Use Profile_Delete_DM to delete a profile directory entry.\n\n"
					"  The following options are required:\n"
					"    -t    The name of the profile to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!profile) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiProfileDeleteDmOutput* output;

	int rc = smProfile_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password
			profile, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int profileQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * profile = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				profile = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Profile_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Profile_Query_DM [-T] profile_name\n\n"
					"DESCRIPTION\n"
					"  Use Profile_Query_DM to query a profile directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the profile being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!profile) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	VmApiInternalContext context;

	// Initialize context
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiProfileQueryDmOutput * output;

	int rc = smProfile_Query_DM(&context, "", // Authorizing user
			0, // Password length
			"", // Password
			profile,// Profile name
			&output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out directory profile
		int i;
		int recCount = output->profileRecordCount;
		int RECORD_LENGTH = 72;
		char line[RECORD_LENGTH], chs[4];

		if (recCount > 0) {
			// Loop through profile records and print out profile entry
			for (i = 0; i < recCount; i++) {
				memset(line, 0, output->profileRecordList[i].profileRecordLength);
				memcpy(line, output->profileRecordList[i].recordData, output->profileRecordList[i].profileRecordLength);
				trim(line);
				printf("%s\n", line);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int profileReplaceDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * profile = NULL;
	char * profileFile = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:h?")) != -1)
		switch (option) {
			case 'T':
				profile = optarg;
				break;

			case 'f':
				profileFile = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Profile_Replace_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Profile_Replace_DM [-T] profile_name [-f] profile_file\n\n"
					"DESCRIPTION\n"
					"  Use Profile_Replace_DM to replace the definition of a profile to be\n"
					"  included in a virtual image in the directory.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the profile directory entry to be replaced\n"
					"    -f    The profile directory entry file");
				return 1;
				break;

			default:
				break;
		}

	if (!profile || !profileFile) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiProfileReplaceDmOutput* output;

	// Open the user entry file
	FILE * fp = fopen(profileFile, "r");

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create image record
	vmApiProfileRecord record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].profileRecordLength = strlen(line[i]);
		record[i].recordData = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	int rc = smProfile_Replace_DM(&context, "", 0, "", // Authorizing user, password length, password
				profile, recordCount,
				(vmApiProfileRecord *) record, // Image record
				&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int prototypeCreateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * prototype = NULL;
	char * file = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:h?")) != -1)
		switch (option) {
			case 'T':
				prototype = optarg;
				break;

			case 'f':
				file = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Prototype_Create_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Prototype_Create_DM [-T] prototype_name [-f] prototype_file\n\n"
					"DESCRIPTION\n"
					"  Use Prototype_Create_DM to create a new virtual image prototype.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being activated\n"
					"    -f    The new virtual image prototype");
				return 1;
				break;

			default:
				break;
		}

	if (!prototype || !file) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiPrototypeCreateDmOutput* output;

	// Open the user entry file
	FILE * fp = fopen(file, "r");

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create prototype record
	vmApiPrototypeRecordList record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].recordNameLength = strlen(line[i]);
		record[i].recordName = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	int rc = smPrototype_Create_DM(&context, "", 0, "", // Authorizing user, password length, password
		prototype, recordCount, (vmApiPrototypeRecordList *) record, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int prototypeDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * prototype = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				prototype = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Prototype_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Prototype_Delete_DM [-T] prototype_name\n\n"
					"DESCRIPTION\n"
					"  Use Prototype_Delete_DM to delete an image prototype.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the prototype to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!prototype) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiPrototypeDeleteDmOutput* output;

	int rc = smPrototype_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password
			prototype, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int prototypeNameQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * prototype = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				prototype = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Prototype_Name_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Prototype_Name_Query_DM [-T] prototype_name\n\n"
					"DESCRIPTION\n"
					"  Use Prototype_Name_Query_DM to obtain a list of names of defined prototypes.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!prototype) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiPrototypeNameQueryDmOutput* output;

	int rc = smPrototype_Name_Query_DM(&context, "", 0, "", // Authorizing user, password length, password
			prototype, // Does not matter what image name is used
			&output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out image names
		int i;
		int n = output->nameArrayCount;
		for (i = 0; i < n; i++) {
			printf("%s\n", output->nameList[i]);
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int prototypeQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * prototype = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				prototype = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Prototype_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Prototype_Query_DM [-T] prototype_name\n\n"
					"DESCRIPTION\n"
					"  Use Prototype_Query_DM to query the characteristics of an image prototype.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the prototype to be queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!prototype) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

    // Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiPrototypeQueryDmOutput * output;

	int rc = smPrototype_Query_DM(&context, "", 0, "", prototype, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		// Print out directory entry
		int recCount = output->recordArrayCount;
		int recLen = 0;
		char line[72], chs[4];
		if (recCount > 0) {
			int i;
			int token = 0;
			for (i = 0; i < recCount; i++) {
				recLen = output->recordList[i].recordNameLength;
				memset(line, 0, recLen);
				memcpy(line, output->recordList[i].recordName, recLen);
				trim(line);
				printf("%s\n", line);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int prototypeReplaceDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * prototype = NULL;
	char * file = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:f:h?")) != -1)
		switch (option) {
			case 'T':
				prototype = optarg;
				break;

			case 'f':
				file = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Prototype_Replace_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Prototype_Replace_DM [-T] prototype_name\n\n"
					"DESCRIPTION\n"
					"  Use Prototype_Replace_DM to replace an existing prototype.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image being activated\n"
					"    -f    The new virtual image prototype\n");
				return 1;
				break;

			default:
				break;
		}

	if (!prototype || !file) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiPrototypeReplaceDmOutput* output;

	// Open the user entry file
	FILE * fp = fopen(file, "r");

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create prototype record
	vmApiPrototypeRecordList record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].recordNameLength = strlen(line[i]);
		record[i].recordName = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	int rc = smPrototype_Replace_DM(&context, "", 0, "", // Authorizing user, password length, password
		prototype, recordCount, (vmApiPrototypeRecordList *) record, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int queryAPIFunctionalLevel(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Query_API_Functional_Level\n\n"
					"SYNOPSIS\n"
					"  smcli Query_API_Functional_Level [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Query_API_Functional_Level to obtain the support level of the server\n"
					"  and functions, as follows:\n"
					"    For z/VM V5.3, this API will provide a return and reason code of 0/0\n"
					"    For z/VM V5.4, this API will provide a return and reason code of 0/540\n"
					"    For z/VM V6.1, this API will provide a return and reason code of 0/610\n"
					"    For the updated z/VM V6.1 SPE release, this API will provide a return\n"
					"    and reason code of 0/611.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

    // Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiQueryApiFunctionalLevelOutput * output;

	int rc = smQuery_API_Functional_Level(&context, "", 0, "",
			image, &output);

	if (rc || (output->returnCode && output->returnCode == 0) || (output->reasonCode && output->reasonCode == 0)) {
		printf("Support level is z/VM V5.3\n");
	} else if (rc || (output->returnCode && output->returnCode == 0) || (output->reasonCode && output->reasonCode == 540)) {
		printf("Support level is z/VM V5.4\n");
	} else if (rc || (output->returnCode && output->returnCode == 0) || (output->reasonCode && output->reasonCode == 610)) {
		printf("Support level is z/VM V6.1\n");
	} else {
		// Handle return code and reason code
		printReturnCode(rc, output->returnCode, output->reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int queryAsynchronousOperationDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	int operationId = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:i:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'i':
				operationId = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Query_Asynchronous_Operation_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Query_Asynchronous_Operation_DM [-T] image_name [-i] operation_id\n\n"
					"DESCRIPTION\n"
					"  Use Query_Asynchronous_Operation_DM to query the status of an asynchronous\n"
					"  directory manager operation.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -i    The identifier of the operation to be queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !operationId) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiQueryAsynchronousOperationDmOutput* output;

	int rc = smQuery_Asychronous_Operation_DM(&context, "", 0, "",
			image, operationId, &output);

	// Handle return code and reason code
	if (rc || output->returnCode || output->reasonCode) {
		if (rc) {
			printf("Return Code: %d\n", rc);
		} else {
			if (output->returnCode == 0 && output->reasonCode == 0) {
				printf("Request successful\n");
			} else if (output->returnCode == 0 && output->reasonCode == 100) {
				printf("Asynchronous operation succeeded\n");
			} else if (output->returnCode == 0 && output->reasonCode == 104) {
				printf("Asynchronous operation in progress\n");
			} else if (output->returnCode == 0 && output->reasonCode == 108) {
				printf("Asynchronous operation failed\n");
			} else {
				printf("  Return Code: %d\n"
					"  Reason Code: %d\n", output->returnCode, output->reasonCode);
			}
		}
	} else {
		printReturnCode(rc, output->returnCode, output->reasonCode);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int queryDirectoryManagerLevelDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Query_Directory_Manager_Level_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Query_Directory_Manager_Level_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Query_Directory_Manager_Level_DM to query the directory manager\n"
					"  that is being used and its functional level.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiQueryDirectoryManagerLevelDmOutput* output;

	int rc = smQuery_Directory_Manager_Level_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		printf("%s\n", output->directoryManagerLevel);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int sharedMemoryAccessAddDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * segmentName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Shared_Memory_Access_Add_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Shared_Memory_Access_Add_DM [-T] image_name [-s] segment_name\n\n"
					"DESCRIPTION\n"
					"  Use Shared_Memory_Access_Add_DM to add restricted (RSTD) access to a\n"
					"  shared memory segment.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or list of userids being granted access to the\n"
					"          memory segment\n"
					"    -s    The name of the memory segment to which access is being\n"
					"          granted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !segmentName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiSharedMemoryAccessAddDmOutput* output;

	int rc = smShared_Memory_Access_Add_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, segmentName, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int sharedMemoryAccessQueryDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * segmentName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				segmentName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Shared_Memory_Access_Query_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Shared_Memory_Access_Query_DM [-T] image_name [-s] segment_name\n\n"
					"DESCRIPTION\n"
					"  Use Shared_Memory_Access_Query_DM to query the restricted (RSTD) access\n"
					"  to a shared memory segment.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or list of userids being queried for restricted\n"
					"          access to the specified segment\n"
					"    -s    The name of the memory segment being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !segmentName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiSharedMemoryAccessQueryDmOutput* output;

	int rc = smShared_Memory_Access_Query_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, segmentName, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		int i;
		for (i = 0; i < output->memorySegmentNameCount; i++) {
			printf("%s\n", output->memorySegmentNameList[i].memorySegmentName);
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int sharedMemoryAccessRemoveDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * segmentName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				segmentName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Shared_Memory_Access_Remove_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Shared_Memory_Access_Remove_DM [-T] image_name [-s] segment_name\n\n"
					"DESCRIPTION\n"
					"  Use Shared_Memory_Access_Remove_DM to remove restricted (RSTD) access\n"
					"  from a shared memory segment.\n\n"
					"  The following options are required:\n"
					"    -T    The userid or list of IDs for which access is being removed\n"
					"    -s    The name of the memory segment to which access is being removed\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !segmentName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiSharedMemoryAccessRemoveDmOutput* output;

	int rc = smShared_Memory_Access_Remove_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, segmentName, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int sharedMemoryCreate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * segmentName = NULL;
	long beginPage = 0;
	long endPage = 0;
	int pageAccessType = 0;
	int memoryAttributes = 0;
	char * memoryAccessId = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:b:e:t:m:i:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				segmentName = optarg;
				break;

			case 'b':
				beginPage = atol(optarg);
				break;

			case 'e':
				endPage = atol(optarg);
				break;

			case 't':
				pageAccessType = atoi(optarg);
				break;

			case 'm':
				memoryAttributes = atoi(optarg);
				break;

			case 'i':
				memoryAccessId = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Shared_Memory_Create\n\n"
					"SYNOPSIS\n"
					"  smcli Shared_Memory_Create [-T] image_name [-s] segment_name\n"
					"  [-b] begin_page [-e] end_page [-t] page_type [-m] memory_attributes\n"
					"  [-i] memory_access_id\n\n"
					"DESCRIPTION\n"
					"  Use Shared_Memory_Create to create a memory segment that can be shared\n"
					"  among virtual images.\n\n"
					"  The following options are required:\n"
					"    -T    The userid for which memory is being saved in the segment\n"
					"    -s    The name of the memory segment being created\n"
					"    -b    The beginning page to be saved\n"
					"    -e    The ending page to be saved\n"
					"    -t    The type of page access. Valid values are:\n"
					"            1: SW – Shared read/write access\n"
					"            2: EW – Exclusive read/write access\n"
					"            3: SR – Shared read-only access\n"
					"            4: ER – Exclusive read-only access\n"
					"            5: SN – Shared read/write access, no data saved\n"
					"            6: EN – Exclusive read/write access, no data saved\n"
					"            7: SC – Shared read-only access, no data saved, CP writeable pages\n"
					"    -m    Memory attributes, valid values are:\n"
					"            0: Unspecified\n"
					"            1: RSTD – Restricted saved memory\n"
					"            2: UNRSTD – Unrestricted saved memory. This is the default.\n"
					"  The following options are optional:\n"
					"    -i    The name of the image or list of images authorized to access the\n"
					"          RSTD segment.  If specified, it is used only when RSTD is specified\n"
					"          in the memory_attributes parameter.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !segmentName || !beginPage || !endPage || !pageAccessType || !memoryAttributes) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiSharedMemoryCreateOutput* output;

	int rc = smShared_Memory_Create(&context, "", 0, "", // Authorizing user, password length, password
			image, segmentName, beginPage, endPage, pageAccessType, memoryAttributes, memoryAccessId, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int sharedMemoryDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * segmentName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				segmentName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Shared_Memory_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Shared_Memory_Delete [-T] image_name [-s] segment_name\n\n"
					"DESCRIPTION\n"
					"  Use Shared_Memory_Delete to delete a shared memory segment\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -s    The name of the memory segment being deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !segmentName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiSharedMemoryDeleteOutput* output;

	int rc = smShared_Memory_Delete(&context, "", 0, "", // Authorizing user, password length, password
			image, segmentName, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int sharedMemoryQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * segmentName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				segmentName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Shared_Memory_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Shared_Memory_Query [-T] image_name [-s] segment_name\n\n"
					"DESCRIPTION\n"
					"  Use Shared_Memory_Query to query information about system data files that\n"
					"  are contained in the saved memory segment.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -s    The name of the memory segment being queried\n"
					"            *: Specifies all defined memory segments for query\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !segmentName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiSharedMemoryQueryOutput* output;

	int rc = smShared_Memory_Query(&context, "", 0, "", // Authorizing user, password length, password
			image, segmentName, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		char * status;
		char * access;
		int i, j;
		for (i = 0; i < output->memorySegmentCount; i++) {
			if (output->memorySegmentInfoList[i].memorySegmentStatus == 1) {
				status = "Skeleton";
			} else if (output->memorySegmentInfoList[i].memorySegmentStatus == 2) {
				status = "Available and nonrestricted";
			} else if (output->memorySegmentInfoList[i].memorySegmentStatus == 4) {
				status = "Available and restricted";
			} else if (output->memorySegmentInfoList[i].memorySegmentStatus == 4) {
				status = "Pending purge";
			}

			printf("Memory segment: %s\n"
				"Status: %s\n", output->memorySegmentInfoList[i].memorySegmentName, status);

			for (j = 0; j < output->memorySegmentInfoList[i].pageRangeCount; j++) {
				if (output->memorySegmentInfoList[i].pageRangeList[j].pageAccessDescriptor == 1) {
					access = "Shared read/write access";
				} else if (output->memorySegmentInfoList[i].pageRangeList[j].pageAccessDescriptor == 2) {
					access = "Exclusive read/write access";
				} else if (output->memorySegmentInfoList[i].pageRangeList[j].pageAccessDescriptor == 3) {
					access = "Shared read-only access";
				} else if (output->memorySegmentInfoList[i].pageRangeList[j].pageAccessDescriptor == 4) {
					access = "Exclusive read-only access";
				} else if (output->memorySegmentInfoList[i].pageRangeList[j].pageAccessDescriptor == 5) {
					access = "Shared read/write access, no data saved";
				} else if (output->memorySegmentInfoList[i].pageRangeList[j].pageAccessDescriptor == 6) {
					access = "Exclusive read/write access, no data saved";
				} else if (output->memorySegmentInfoList[i].pageRangeList[j].pageAccessDescriptor == 7) {
					access = "Shared read-only access, no data saved, CP writeable pages";
				}

				printf("Beginning page: %s\n"
					"Ending page: %s\n"
					"Page access: %s\n", output->memorySegmentInfoList[i].pageRangeList[j].beginPage, output->memorySegmentInfoList[i].pageRangeList[j].endPage, access);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int sharedMemoryReplace(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * segmentName = NULL;
	char * memoryAccessId = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:i:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				segmentName = optarg;
				break;

			case 'i':
				memoryAccessId = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Shared_Memory_Replace\n\n"
					"SYNOPSIS\n"
					"  smcli Shared_Memory_Replace [-T] image_name [-s] segment_name\n"
					"  [-i] memory_access_id\n\n"
					"DESCRIPTION\n"
					"  Use Shared_Memory_Replace to replace a shared memory segment\n"
					"  previously defined by Shared_Memory_Create.\n\n"
					"  The following options are required:\n"
					"    -T    The userid for whom the memory is being replaced\n"
					"    -s    The name of the memory segment being replaced\n"
					"    -i    The image name or the name of a list of new users who\n"
					"          have access to the RSTD memory segment\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !segmentName || !memoryAccessId) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiSharedMemoryReplaceOutput* output;

	int rc = smShared_Memory_Replace(&context, "", 0, "", // Authorizing user, password length, password
			image, segmentName, memoryAccessId, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int staticImageChangesActivateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Static_Image_Changes_Activate_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Static_Image_Changes_Activate_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Static_Image_Changes_Activate_DM to enable changes to the source\n"
					"  directory to be made available to virtual images.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiStaticImageChangesActivateDmOutput* output;

	int rc = smStatic_Image_Changes_Activate_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int staticImageChangesDeactivateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Static_Image_Changes_Deactivate_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Static_Image_Changes_Deactivate_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Static_Image_Changes_Deactivate_DM to prevent changes to the\n"
					"  source directory from being made available to virtual images.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiStaticImageChangesDeactivateDmOutput* output;

	int rc = smStatic_Image_Changes_Deactivate_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int staticImageChangesImmediateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Static_Image_Changes_Immediate_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Static_Image_Changes_Immediate_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Static_Image_Changes_Immediate_DM to make changes to the source\n"
					"  directory immediately available to virtual images regardless of the\n"
					"  current status of static image changes (active or inactive).\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiStaticImageChangesImmediateDmOutput* output;

	int rc = smStatic_Image_Changes_Immediate_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualChannelConnectionCreate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	char * coupledImage = NULL;
	char * coupledVirtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:c:d:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'c':
				coupledImage = optarg;
				break;

			case 'd':
				coupledVirtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Channel_Connection_Create\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Channel_Connection_Create [-T] image_name [-v] virtual_address\n"
					"  [-c] coupled_image [-d] coupled_virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Channel_Connection_Create to establish a virtual network\n"
					"  connection between two active virtual images. A virtual network\n"
					"  connector (CTCA) is added to each virtual image's configuration if one\n"
					"  is not already defined.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image obtaining a connection device\n"
					"    -v    The virtual device number of the network device in the active\n"
					"          virtual image\n"
					"    -c    The virtual image name of the target virtual image that is to\n"
					"          be connected\n"
					"    -d    The virtual device number of the network device in another\n"
					"          virtual image.");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress || !coupledImage || !coupledVirtualAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualChannelConnectionCreateOutput* output;

	int rc = smVirtual_Channel_Connection_Create(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, coupledImage, coupledVirtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualChannelConnectionCreateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	char * coupledImage = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:c:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'c':
				coupledImage = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Channel_Connection_Create_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Channel_Connection_Create_DM [-T] image_image [-v] device_number\n"
					"    [-c] coupled_image\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Channel_Connection_Create_DM to add a virtual network connection\n"
					"  between two virtual images to their directory entries. A virtual network\n"
					"  connector (CTCA) is added to each virtual image's directory entry if one is\n"
					"  not already defined.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image obtaining a connection device\n"
					"    -v    The virtual device number of the network device in the active virtual\n"
					"          image\n"
					"    -c    The virtual image name of the target virtual image that is to be\n"
					"          connected.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress || !coupledImage) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualChannelConnectionCreateDmOutput* output;

	int rc = smVirtual_Channel_Connection_Create_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, coupledImage, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualChannelConnectionDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Channel_Connection_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Channel_Connection_Delete [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Channel_Connection_Delete to terminate a virtual network connection\n"
					"  between two active virtual images and to remove the virtual network connector\n"
					"  (CTCA) from the virtual image's configuration. \n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which the connection device is being removed\n"
					"    -v    The virtual device number of the device to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualChannelConnectionDeleteOutput* output;

	int rc = smVirtual_Channel_Connection_Delete(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualChannelConnectionDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Channel_Connection_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Channel_Connection_Delete_DM [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Channel_Connection_Delete_DM to remove a virtual network\n"
					"  connection from a virtual image's directory entry and to remove the virtual\n"
					"  network connector (CTCA) from the virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which the connection device is\n"
					"          being removed\n"
					"    -v    The virtual device number of the device to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualChannelConnectionDeleteDmOutput* output;

	int rc = smVirtual_Channel_Connection_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterConnectLAN(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	char * lanName = NULL;
	char * lanOwner = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:l:o:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'l':
				lanName = optarg;
				break;

			case 'o':
				lanOwner = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Connect_LAN\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Connect_LAN [-T] image_name [-v] virtual_address\n"
					"  [-l] lan_name [-o] lan_owner\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Connect_LAN to connect an existing virtual\n"
					"  network adapter on an active virtual image to an existing virtual network\n"
					"  LAN.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which a LAN connection is being created\n"
					"    -v    The virtual device address for the new adapter\n"
					"    -l    The name of the guest LAN segment to connect the virtual image\n"
					"    -o    The virtual image owning the guest LAN segment to be connected\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress || !lanName || !lanOwner) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterConnectLanOutput* output;

	int rc = smVirtual_Network_Adapter_Connect_LAN(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, lanName, lanOwner, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterConnectLANDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * deviceAddress = NULL;
	char * lanName = "";
	char * lanOwner = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:n:o:c:m:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				deviceAddress = optarg;
				break;

			case 'n':
				lanName = optarg;
				break;

			case 'o':
				lanOwner = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Connect_LAN_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Connect_LAN_DM [-T] image_name\n"
					"   [-v] virtual_address [-n] lan_name [-o] lan_owner\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Connect_LAN_DM to define a virtual network LAN\n"
					"  connection for an existing virtual network adapter in a virtual image's\n"
					"  directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which a LAN connection is being created\n"
					"    -v    The virtual device address for the new adapter\n"
					"    -n    The name of the guest LAN segment to connect the virtual image\n"
					"    -o    The virtual image owning the guest LAN segment to be connected\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !deviceAddress || !lanName || !lanOwner) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterConnectVswitchDmOutput* output;

	int rc = smVirtual_Network_Adapter_Connect_LAN_DM(&context, "", 0, "",
			image, deviceAddress, lanName, lanOwner, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterConnectVswitch(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * deviceAddress = NULL;
	char * vswitchName = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:n:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				deviceAddress = optarg;
				break;

			case 'n':
				vswitchName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Connect_Vswitch\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Connect_Vswitch [-T] image_name\n"
					"   [-v] virtual_address [-n] vswitch_name\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Connect_Vswitch to connect an existing virtual "
					"  network adapter on an active virtual image to an existing virtual switch.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the user or profile to which virtual network adapter\n"
					"          virtual switch connection information will be added.\n"
					"    -v    The virtual device address for the new adapter\n"
					"    -n    The name of the virtual switch segment to connect to the virtual\n"
					"          image\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !deviceAddress || !vswitchName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterConnectVswitchOutput* output;

	int rc = smVirtual_Network_Adapter_Connect_Vswitch(&context, "", 0, "",
			image, deviceAddress, vswitchName, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterConnectVswitchDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	char * switchName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:n:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'n':
				switchName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Connect_Vswitch_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Connect_Vswitch_DM [-T] image_name\n"
					"  [-v] virtual_address [-n] switch_name\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Connect_Vswitch_DM to define a virtual switch\n"
					"  connection for an existing virtual network adapter in a virtual image's\n"
					"  directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the user or profile to which virtual network adapter\n"
					"          virtual switch connection information will be added\n"
					"    -v    The virtual device address for the new adapter\n"
					"    -n    The name of the virtual switch segment to connect to the virtual\n"
					"          image\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress || !switchName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterConnectVswitchDmOutput* output;

	int rc = smVirtual_Network_Adapter_Connect_Vswitch_DM(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, switchName, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterCreate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	int adapterType = 0;
	int virtualDevices = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:t:d:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 't':
				adapterType = atoi(optarg);
				break;

			case 'd':
				virtualDevices = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Create\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Create [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Create to add a virtual network interface card (NIC)"
					"  to an active virtual image.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which a network adapter is being defined\n"
					"    -v    The virtual device address for the new adapter\n"
					"    -t    The adapter type must be one of the following:\n"
					"            1: Defines this adapter as a simulated HiperSockets NIC\n"
					"            2: Defines this adapter as a simulated QDIO NIC\n"
					"    -d    The number of virtual devices associated with this adapter\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress || !adapterType || !virtualDevices) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterCreateOutput* output;

	int rc = smVirtual_Network_Adapter_Create(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, adapterType, virtualDevices, "", &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterCreateDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * deviceAddress = NULL;
	int adapterType = 0;
	int adapterDevices = 0;
	char * chpId = "";
	char * macId = "";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:a:n:c:m:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				deviceAddress = optarg;
				break;

			case 'a':
				adapterType = atoi(optarg);
				break;

			case 'n':
				adapterDevices = atoi(optarg);
				break;

			case 'c':
				chpId = optarg;
				break;

			case 'm':
				macId = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Create_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Create_DM [-T] image_name [-v] virtual_address\n"
					"    [-a] adapter_type [-n] devices_count [-c] channel_path_id [-m] mac_id\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Create_DM to add a virtual network interface\n"
					"  card (NIC) to a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which a network adapter is being defined.\n"
					"    -v    The virtual device address for the new adapter\n"
					"    -a    The adapter type:\n"
					"            1: Defines this adapter as a simulated HiperSockets NIC\n"
					"            2: Defines this adapter as a simulated QDIO NIC\n"
					"    -n    The number of virtual devices associated with this adapter\n"
					"  The following options are optional:\n"
					"    -c    The hex CHPID numbers for the first- and second-level systems\n"
					"    -m    The MAC identifier\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !deviceAddress || !adapterType || !adapterDevices) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterCreateDmOutput* output;

	int rc = smVirtual_Network_Adapter_Create_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, deviceAddress, adapterType, adapterDevices, chpId, macId,
			&output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Delete [-T] image_name\n"
					"  [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Delete to remove a virtual network interface\n"
					"  card (NIC) from an active virtual image.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which the network adapter is being\n"
					"          removed\n"
					"    -v    The virtual device number of the base address for the adapter\n"
					"          to be deleted");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterDeleteOutput* output;

	int rc = smVirtual_Network_Adapter_Delete(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterDeleteDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Image_Disk_Delete_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Image_Disk_Delete_DM [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Delete_DM to remove a virtual\n"
					"  network interface card (NIC) from a virtual image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which the network adapter is being removed\n"
					"    -v    The virtual device number of the base address for the adapter to be\n"
					"          deleted.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterDeleteDmOutput* output;

	int rc = smVirtual_Network_Adapter_Delete_DM(&context, "", 0, "", // Authorizing user, password length, password.
			image, virtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterDisconnect(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Disconnect\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Disconnect [-T] image_name\n"
					"  [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Disconnect to disconnect a virtual network adapter\n"
					"  on an active virtual image from a virtual network LAN or virtual switch.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the user or profile from which virtual network adapter\n"
					"          guest LAN connection information will be removed\n"
					"    -v    Specifies the virtual device address of the connected adapter\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterDisconnectOutput* output;

	int rc = smVirtual_Network_Adapter_Disconnect(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterDisconnectDM(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Disconnect_DM\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Disconnect_DM [-T] image_name [-v] virtual_address\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Disconnect_DM to remove a virtual network LAN or\n"
					"  virtual switch connection from a virtual network adapter definition in a virtual\n"
					"  image's directory entry.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the user or profile from which virtual network adapter\n"
					"          guest LAN connection information will be removed\n"
					"    -v    Specifies the virtual device address of the connected adapter\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterDisconnectDmOutput* output;

	int rc = smVirtual_Network_Adapter_Disconnect_DM(&context, "", 0, "",
			image, virtualAddress, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkAdapterQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * virtualAddress = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:v:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'v':
				virtualAddress = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Adapter_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Adapter_Query [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Adapter_Query to obtain information about the\n"
					"  specified adapter for an active virtual image.\n\n"
					"  The following options are required:\n"
					"    -T    The virtual image name of the owner of the adapter\n"
					"    -v    The virtual device address of the adapter\n"
					"            *: Request is made for information about all adapters owned\n"
					"               by the target userid\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !virtualAddress) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkAdapterQueryOutput* output;

	int rc = smVirtual_Network_Adapter_Query(&context, "", 0, "", // Authorizing user, password length, password
			image, virtualAddress, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		int count = output->adapterArrayCount;
		if (count > 0) {
			int i;
			char * adapterType;
			char * adapterStatus;
			for (i = 0; i < count; i++) {
				if (output->adapterList[i].adapterType == 1) {
					adapterType = "HiperSockets";
				} else if (output->adapterList[i].adapterType == 2) {
					adapterType = "QDIO";
				} else {
					adapterType = "";
				}

				if (output->adapterList[i].adapterStatus == 0) {
					adapterStatus = "Not coupled";
				} else if (output->adapterList[i].adapterType == 1) {
					adapterStatus = "Coupled but not active";
				} else if (output->adapterList[i].adapterType == 2) {
					adapterStatus = "Coupled and active";
				} else {
					adapterStatus = "";
				}

				printf("Adapter:\n"
					"  Address: %s\n"
					"  Device count: %d\n"
					"  Adapter type: %s\n"
					"  Adapter status: %s\n"
					"  LAN owner: %s\n"
					"  LAN name: %s\n", output->adapterList[i].imageDeviceNumber, output->adapterList[i].networkAdapterDevices, adapterType, adapterStatus, output->adapterList[i].lanName, output->adapterList[i].lanOwner);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkLANAccess(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * lanName = NULL;
	char * lanOwner = NULL;
	char * accessOpt = NULL;
	char * accessGrantUser = NULL;
	char * promiscuity = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:o:a:u:p:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				lanName = optarg;
				break;

			case 'o':
				lanOwner = optarg;
				break;

			case 'a':
				accessOpt = optarg;
				break;

			case 'u':
				accessGrantUser = optarg;
				break;

			case 'p':
				promiscuity = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Lan_Access\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Lan_Access [-T] image_name [-n] lan_name\n"
					"  [-o] lan_owner [-a] access_op [-u] access_user [-p] promiscuity\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Lan_Access to grant users access to a restricted\n"
					"  virtual network LAN.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -n    The name of the LAN to which access is being granted or\n"
					"          revoked\n"
					"    -o    The virtual image owning the guest LAN segment to be created\n"
					"    -a    Access operation:\n"
					"            GRANT: Grant access\n"
					"            REVOKE: Revoke access\n"
					"    -u    Virtual image to be granted access to the LAN\n"
					"    -p    Promiscuity:\n"
					"            NONPROMISCUOUS: Nonpromiscuous access\n"
					"            PROMISCUOUS: Promiscuous access\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !lanName || !lanOwner || !accessOpt || !accessGrantUser || !promiscuity) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkLanAccessOutput* output;

	int rc = smVirtual_Network_LAN_Access(&context, "", 0, "",
			image, lanName, lanOwner, accessOpt, accessGrantUser, promiscuity, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkLANAccessQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * lanName = NULL;
	char * lanOwner = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:o:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				lanName = optarg;
				break;

			case 'o':
				lanOwner = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_LAN_Access_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_LAN_Access_Query [-T] image_name"
					"  [-n] lan_name [-o] lan_owner\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_LAN_Access_Query to query which users are\n"
					"  authorized to access a specified restricted virtual network LAN.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -n    The name of the LAN being queried\n"
					"    -o    The owner of the LAN being queried\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !lanName || !lanOwner) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkLanAccessQueryOutput* output;

	int rc = smVirtual_Network_LAN_Access_Query(&context, "", 0, "",
			image, lanName, lanOwner, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		int count = output->lanAccessCount;
		if (count > 0) {
			int i;
			for (i = 0; i < count; i++) {
				printf("%s\n", output->lanAccessList[i].vmapiString);
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkLANCreate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * lanName = NULL;
	char * lanOwner = NULL;
	int lanType = 0;
	int transportType = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:o:t:p:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				lanName = optarg;
				break;

			case 'o':
				lanOwner = optarg;
				break;

			case 't':
				lanType = atoi(optarg);
				break;

			case 'p':
				transportType = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_LAN_Create\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_LAN_Create [-T] image_name [-n] lan_name\n"
					"  [-o] lan_owner [-t] lan_type [-p] transport_type\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_LAN_Create to create a virtual network LAN.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which a LAN connection is being created\n"
					"    -n    The name of the guest LAN segment to be created\n"
					"    -o    The virtual image owning the guest LAN segment to be created\n"
					"    -t    The type of guest LAN segment. This must be one of the following:\n"
					"            1: Defines this adapter as an unrestricted simulated\n"
					"               HiperSockets NIC\n"
					"            2: Defines this adapter as an unrestricted simulated QDIO NIC\n"
					"            3: Defines this adapter as a restricted simulated\n"
					"               HiperSockets NIC\n"
					"            4: Defines this adapter as a restricted simulated QDIO NIC\n"
					"    -p    Specifies the transport mechanism to be used for guest LANs and\n"
					"          virtual switches, as follows:\n"
					"            0: Unspecified\n"
					"            1: IP – Reference all target nodes on LAN or switch using\n"
					"               IP addresses\n"
					"            2: Ethernet – Reference all target nodes on LAN or switch using\n"
					"               MAC addresses\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !lanName || !lanOwner || !lanType || !transportType) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkLanCreateOutput* output;

	int rc = smVirtual_Network_LAN_Create(&context, "", 0, "",
			image, lanName, lanOwner, lanType, transportType, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkLANDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * lanName = NULL;
	char * lanOwner = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:o:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				lanName = optarg;
				break;

			case 'o':
				lanOwner = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_LAN_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_LAN_Delete [-T] image_name [-n] lan_name\n"
					"  [-o] lan_owner\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_LAN_Delete to delete a virtual network LAN.\n\n"
					"  The following options are required:\n"
					"    -T    The name of the image for which a LAN connection is being deleted\n"
					"    -n    The name of the guest LAN segment to be deleted\n"
					"    -o    The virtual image owning the guest LAN segment to be deleted\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !lanName || !lanOwner) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkLanDeleteOutput* output;

	int rc = smVirtual_Network_LAN_Delete(&context, "", 0, "",
			image, lanName, lanOwner, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkLANQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * lanName = NULL;
	char * lanOwner = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:o:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				lanName = optarg;
				break;

			case 'o':
				lanOwner = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_LAN_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_LAN_Query [-T] image_name [-n] lan_name\n"
					"  [-o] lan_owner\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_LAN_Query to obtain information about a virtual\n"
					"  network LAN.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -n    The name of the guest LAN segment to be queried\n"
					"    -o    The name of the virtual image owning the guest LAN segment\n"
					"            *: A request is made for all qualified guest LAN segments\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !lanName || !lanOwner) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkLanQueryOutput* output;

	int rc = smVirtual_Network_LAN_Query(&context, "", 0, "",
			image, lanName, lanOwner, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		int count = output->lanCount;
		if (count > 0) {
			int i, j;
			char * lanType;
			for (i = 0; i < count; i++) {
				if (output->lanList[i].lanType == 1) {
					lanType = "HiperSockets NIC";
				} else if (output->lanList[i].lanType == 2) {
					lanType = "QDIO NIC";
				} else {
					lanType = "";
				}

				printf("LAN:\n"
					"  Name: %s\n"
					"  Owner: %s\n"
					"  LAN type: %s\n"
					"  Connections:\n", output->lanList[i].lanName, output->lanList[i].lanOwner, lanType);

				for (j = 0; j < output->lanList[i].connectedAdapterCount; j++) {
					printf("    Adapter owner: %s  Address: %s\n", output->lanList[i].connectedAdapterList[j].adapterOwner, output->lanList[i].connectedAdapterList[j].imageDeviceNumber);
				}
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkVswitchCreate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * switchName = "";
	char * realDeviceAddress = "NONE";
	char * portName = "";
	char * controllerName = "*";
	int connectionValue = 1;
	int queueMemoryLimit = 8;
	int routingValue = 0;
	int transportType = 0;
	int vlanId = 0;
	int portType = 0;
	int updateSystemConfigIndicator = 1;
	char * systemConfigName = "SYSTEM";
	char * systemConfigType = "CONFIG";
	char * parmDiskOwner = "MAINT";
	char * parmDiskNumber = "CF1";
	char * parmDiskPassword = ",";
	char * altSystemConfigName = "SYSTEM";
	char * altSystemConfigType = "CONFIG";
	char * altParmDiskOwner = "MAINT";
	char * altParmDiskNumber = "CF2";
	char * altParmDiskPassword = ",";
	int gvrpValue = 0;
	int nativeVlanId = 0;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:r:a:i:c:q:e:t:v:p:u:L:F:R:C:P:N:Y:O:M:D:G:V:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				switchName = optarg;
				break;

			case 'r':
				realDeviceAddress = optarg;
				break;

			case 'a':
				portName = optarg;
				break;

			case 'i':
				controllerName = optarg;
				break;

			case 'c':
				connectionValue = atoi(optarg);
				break;

			case 'q':
				queueMemoryLimit = atoi(optarg);
				break;

			case 'e':
				routingValue = atoi(optarg);
				break;

			case 't':
				transportType = atoi(optarg);
				break;

			case 'v':
				vlanId = atoi(optarg);
				break;

			case 'p':
				portType = atoi(optarg);
				break;

			case 'u':
				updateSystemConfigIndicator = atoi(optarg);
				break;

			case 'L':
				systemConfigName = optarg;
				break;

			case 'F':
				systemConfigType = optarg;
				break;

			case 'R':
				parmDiskOwner = optarg;
				break;

			case 'C':
				parmDiskNumber = optarg;
				break;

			case 'P':
				parmDiskPassword = optarg;
				break;

			case 'N':
				altSystemConfigName = optarg;
				break;

			case 'Y':
				altSystemConfigType = optarg;
				break;

			case 'O':
				altParmDiskOwner = optarg;
				break;

			case 'M':
				altParmDiskNumber = optarg;
				break;

			case 'D':
				altParmDiskPassword = optarg;
				break;

			case 'G':
				gvrpValue = atoi(optarg);
				break;

			case 'V':
				nativeVlanId = atoi(optarg);
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Vswitch_Create\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Vswitch_Create [-T] image_name [-n] switch_name\n"
					"  [-r] real_device_address [-a] port_name [-i] controller_name [-c] connection_value\n"
					"  [-q] queue_memory_limit [-e] routing_value [-t] transport_type [-v] vlan_id\n"
					"  [-p] port_type [-u] update_sys_config [-L] sys_config_name [-F] sys_config_type\n"
					"  [-R] parm_disk_owner [-C] parm_disk_number [-P] parm_disk_passwd\n"
					"  [-N] alt_sys_config_name [-Y] alt_sys_config_type [-O] alt_parm_disk_owner\n"
					"  [-M] alt_parm_disk_number [-D] alt_parm_disk_passwd [-G] gvrp [-V] native_vlan_id\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Vswitch_Create to create a virtual switch.\n\n"
					"  The following options are required:\n"
					"    -T    The virtual image name of the owner of the virtual switch\n"
					"  The following options are optional:\n"
					"    -n    The name of the virtual switch segment\n"
					"    -r    The real device address of a real OSA-Express QDIO device\n"
					"          used to create the switch to the virtual adapter\n"
					"    -a    The name used to identify the OSA Expanded adapter\n"
					"    -i    The user ID controlling the real device\n"
					"    -c    Connection value. This can be any of the following values:\n"
					"            0: Unspecified\n"
					"            1: Activate the real device connection\n"
					"            2: Do not activate the real device connection\n"
					"    -q    Queue memory limit. A number between 1 and 8 specifying the QDIO\n"
					"          buffer size in megabytes. If unspecified, the default is 8.\n"
					"    -e    Specifies whether the OSA-Express QDIO device will act as a router\n"
					"          to the virtual switch, as follows:\n"
					"            0: Unspecified\n"
					"            1: NONROUTER – The OSA-Express device will not act as a router to\n"
					"               the virtual switch\n"
					"            2: PRIROUTER – The OSA-Express device identified will act as a\n"
					"               primary router to the virtual switch\n"
					"    -t    Specifies the transport mechanism to be used for the virtual\n"
					"          switch, as follows:\n"
					"            0: Unspecified\n"
					"            1: IP\n"
					"            2: ETHERNET\n"
					"    -v    The VLAN ID. This can be any of the following values:\n"
					"           -1: The VLAN ID is not specified\n"
					"            0: UNAWARE\n"
					"            1-4094: Any number in this range is a valid VLAN ID\n"
					"    -p    Specifies the port type, as follows:\n"
					"            0: Unspecified\n"
					"            1: ACCESS\n"
					"            2: TRUNK\n"
					"    -u    Update system config indicator. This can be any of the following values:\n"
					"            0: Unspecified\n"
					"            1: Create a virtual switch on the active system\n"
					"            2: Create a virtual switch on the active system and add the virtual\n"
					"               switch definition to the system configuration file\n"
					"            3: Add the virtual switch definition to the system configuration file\n"
					"    -L    File name of the system configuration file. The default is 'SYSTEM'.\n"
					"    -F    File type of the system configuration file. The default is 'CONFIG'.\n"
					"    -R    Owner of the parm disk. The default is 'MAINT'.\n"
					"    -C    Number of the parm disk, as defined in the server's directory.\n"
					"          The default is 'CF1'.\n"
					"    -P    Multiwrite password for the parm disk. The default is ','.\n"
					"    -N    File name of the second (alternative) system configuration file.\n"
					"          The default is 'SYSTEM'.\n"
					"    -Y    File type of the second (alternative) system configuration file.\n"
					"          The default is 'CONFIG'.\n"
					"    -O    Owner of the second (alternative) parm disk. The default is 'MAINT'.\n"
					"    -M    Number of the second (alternative) parm disk. The default is 'CF2'.\n"
					"    -D    Multiwrite password for the second (alternative) parm disk.\n"
					"          The default is ','.\n"
					"    -G    GVRP value. This can be any of the following values:\n"
					"            0: Unspecified\n"
					"            1: GVRP\n"
					"            2: NOGVRP\n"
					"    -V    The native VLAN ID. This can be any of the following values:\n"
					"           -1: The native VLAN ID is not specified\n"
					"            1-4094: Any number in this range is a valid native VLAN ID\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !switchName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkVswitchCreateOutput* output;

	int rc = smVirtual_Network_Vswitch_Create(&context, "", 0, "",
			image, switchName, realDeviceAddress, portName, controllerName, connectionValue,
			queueMemoryLimit, routingValue, transportType, vlanId, portType, updateSystemConfigIndicator,
			systemConfigName, systemConfigType, parmDiskOwner, parmDiskNumber, parmDiskPassword,
			altSystemConfigName, altSystemConfigType, altParmDiskOwner, altParmDiskNumber,
			altParmDiskPassword, gvrpValue, nativeVlanId, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkVswitchDelete(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * switchName = "";
	int updateSystemConfigIndicator = 1;
	char * systemConfigName = "SYSTEM";
	char * systemConfigType = "CONFIG";
	char * parmDiskOwner = "MAINT";
	char * parmDiskNumber = "CF1";
	char * parmDiskPassword = ",";
	char * altSystemConfigName = "SYSTEM";
	char * altSystemConfigType = "CONFIG";
	char * altParmDiskOwner = "MAINT";
	char * altParmDiskNumber = "CF2";
	char * altParmDiskPassword = ",";
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:u:L:F:W:C:P:N:Y:O:M:D:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				switchName = optarg;
				break;

			case 'u':
				updateSystemConfigIndicator = atoi(optarg);
				break;

			case 'L':
				systemConfigName = optarg;
				break;

			case 'F':
				systemConfigType = optarg;
				break;

			case 'W':
				parmDiskOwner = optarg;
				break;

			case 'C':
				parmDiskNumber = optarg;
				break;

			case 'P':
				parmDiskPassword = optarg;
				break;

			case 'N':
				altSystemConfigName = optarg;
				break;

			case 'Y':
				altSystemConfigType = optarg;
				break;

			case 'O':
				altParmDiskOwner = optarg;
				break;

			case 'M':
				altParmDiskNumber = optarg;
				break;

			case 'D':
				altParmDiskPassword = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Vswitch_Delete\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Vswitch_Delete [-T] image_name [-n] switch_name\n"
					"  [-u] update_indicator [-L] sys_config_name [-F] sys_config_type\n"
					"  [-R] parm_disk_owner [-C] parm_disk_number [-P] parm_disk_passwd\n"
					"  [-N] alt_sys_config_name [-Y] alt_sys_config_type [-O] alt_parm_disk_owner\n"
					"  [-M] alt_parm_disk_number [-D] alt_parm_disk_passwd\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Vswitch_Delete to delete a virtual switch.\n\n"
					"  The following options are required:\n"
					"    -T    The virtual image name of the owner of the virtual switch\n"
					"    -n    The name of the virtual switch segment\n"
					"  The following options are optional:\n"
					"    -u    Update system config indicator. This can be any of the following values:\n"
					"            0: Unspecified\n"
					"            1: Delete the virtual switch from the active system\n"
					"            2: Delete the virtual switch from the active system and delete the\n"
					"               virtual switch definition from the system configuration file\n"
					"            3: Delete the virtual switch definition from the system configuration\n"
					"               file\n"
					"    -L    File name of the system configuration file. The default is 'SYSTEM'.\n"
					"    -F    File type of the system configuration file. The default is 'CONFIG'.\n"
					"    -R    Owner of the parm disk. The default is 'MAINT'.\n"
					"    -C    Number of the parm disk, as defined in the server's directory.\n"
					"          The default is 'CF1'.\n"
					"    -P    Multiwrite password for the parm disk. The default is ','.\n"
					"    -N    File name of the second (alternative) system configuration file.\n"
					"          The default is 'SYSTEM'.\n"
					"    -Y    File type of the second (alternative) system configuration file.\n"
					"          The default is 'CONFIG'.\n"
					"    -O    Owner of the second (alternative) parm disk. The default is 'MAINT'.\n"
					"    -M    Number of the second (alternative) parm disk. The default is 'CF2'.\n"
					"    -D    Multiwrite password for the second (alternative) parm disk.\n"
					"          The default is ','.\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkVswitchCreateOutput* output;

	int rc = smVirtual_Network_Vswitch_Delete(&context, "", 0, "",
			image, switchName, updateSystemConfigIndicator,
			systemConfigName, systemConfigType, parmDiskOwner, parmDiskNumber, parmDiskPassword,
			altSystemConfigName, altSystemConfigType, altParmDiskOwner, altParmDiskNumber,
			altParmDiskPassword, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkVswitchQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * switchName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:s:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 's':
				switchName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Vswitch_Query\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Vswitch_Query [-T] image_name [-s] switch_name\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Vswitch_Query to obtain information about the specified\n"
					"  virtual switch or switches.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -s    The name of the virtual switch\n"
					"            *: All virtual switches\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !switchName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkVswitchQueryOutput* output;

	int rc = smVirtual_Network_Vswitch_Query(&context, "", 0, "",
			image, switchName, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		int count = output->vswitchCount;
		if (count > 0) {
			int i, j, k, l, m;
			char * transportType;
			char * portType;
			char * routingValue;
			char * gvrpRequest;
			char * gvrpEnabled;
			char * switchStatus;
			char * deviceStatus;
			char * deviceErrorStatus;
			char * vlanIds;
			char * vlanId;
			for (i = 0; i < count; i++) {
				if (output->vswitchList[i].transportType == 1)
					transportType = "IP";
				else if (output->vswitchList[i].transportType == 2)
					transportType = "Ethernet";
				else
					transportType = "";

				if (output->vswitchList[i].portType == 1)
					portType = "Access";
				else if (output->vswitchList[i].portType == 2)
					portType = "Trunk";
				else
					portType = "Unknown";

				if (output->vswitchList[i].routingValue == 1)
					routingValue = "The device will not act as a router";
				else if (output->vswitchList[i].routingValue == 2)
					routingValue = "The device will act as a router";
				else
					routingValue = "";

				if (output->vswitchList[i].grvpRequestAttribute == 1)
					gvrpRequest = "GVRP requested";
				else if (output->vswitchList[i].grvpRequestAttribute == 2)
					gvrpRequest = "GVRP not requested";
				else
					gvrpRequest = "";

				if (output->vswitchList[i].grvpEnabledAttribute == 1)
					gvrpEnabled = "GVRP enabled";
				else if (output->vswitchList[i].grvpEnabledAttribute == 2)
					gvrpEnabled = "GVRP not enabled";
				else
					gvrpEnabled = "";

				if (output->vswitchList[i].switchStatus == 1)
					switchStatus = "Virtual switch defined";
				else if (output->vswitchList[i].switchStatus == 2)
					switchStatus = "Controller not available";
				else if (output->vswitchList[i].switchStatus == 3)
					switchStatus = "Operator intervention required";
				else if (output->vswitchList[i].switchStatus == 4)
					switchStatus = "Disconnected";
				else if (output->vswitchList[i].switchStatus == 5)
					switchStatus = "Virtual devices attached to controller";
				else if (output->vswitchList[i].switchStatus == 6)
					switchStatus = "OSA initialization in progress";
				else if (output->vswitchList[i].switchStatus == 7)
					switchStatus = "OSA device not ready";
				else if (output->vswitchList[i].switchStatus == 8)
					switchStatus = "OSA device ready";
				else if (output->vswitchList[i].switchStatus == 9)
					switchStatus = "OSA devices being detached";
				else if (output->vswitchList[i].switchStatus == 10)
					switchStatus = "Virtual switch delete pending";
				else if (output->vswitchList[i].switchStatus == 11)
					switchStatus = "Virtual switch failover recovering";
				else if (output->vswitchList[i].switchStatus == 12)
					switchStatus = "Autorestart in progress";
				else
					gvrpEnabled = "";

				printf("VSWITCH:"
					"  Name: %s\n"
					"  Transport type: %s\n"
					"  Port type: %s\n"
					"  Queue memory limit: %d\n"
					"  Routing value: %s\n"
					"  VLAN ID: %d\n"
					"  Native VLAN ID: %d\n"
					"  MAC ID: %llu\n"
					"  GVRP request attributes: %s\n"
					"  GVRP enabled attributes: %s\n"
					"  Switch status: %s\n", output->vswitchList[i].switchName, transportType, portType,
							output->vswitchList[i].queueMemoryLimit, routingValue, output->vswitchList[i].vlanId,
							output->vswitchList[i].nativeVlanId, output->vswitchList[i].macId, gvrpRequest,
							gvrpEnabled, switchStatus);

				printf("  Devices:\n");
				for (j = 0; j < output->vswitchList[i].realDeviceCount; j++) {
					if (output->vswitchList[i].realDeviceList[j].deviceStatus == 0)
						deviceStatus = "Device is not active";
					else if (output->vswitchList[i].realDeviceList[j].deviceStatus == 1)
						deviceStatus = "Device is active";
					else if (output->vswitchList[i].realDeviceList[j].deviceStatus == 2)
						deviceStatus = "Device is a backup device";
					else
						deviceStatus = "";

					if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 0)
						deviceErrorStatus = "No error";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 1)
						deviceErrorStatus = "Port name conflict";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 2)
						deviceErrorStatus = "No layer 2 support";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 3)
						deviceErrorStatus = "Real device does not exist";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 4)
						deviceErrorStatus = "Real device is attached elsewhere";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 5)
						deviceErrorStatus = "Real device is not QDIO OSA-E";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 6)
						deviceErrorStatus = "Initialization error";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 7)
						deviceErrorStatus = "Stalled OSA";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 8)
						deviceErrorStatus = "Stalled controller";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 9)
						deviceErrorStatus = "Controller connection severed";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 10)
						deviceErrorStatus = "Primary or secondary routing conflict";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 11)
						deviceErrorStatus = "Device is offline";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 12)
						deviceErrorStatus = "Device was detached";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 13)
						deviceErrorStatus = "IP/Ethernet type mismatch";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 14)
						deviceErrorStatus = "Insufficient memory in controller virtual machine";
					else if (output->vswitchList[i].realDeviceList[j].deviceErrorStatus == 15)
						deviceErrorStatus = "TCP/IP configuration conflict";
					else
						deviceErrorStatus = "";

					printf("    Real device: %d\n"
						"    Controller name: %s\n"
						"    Port name: %s\n"
						"    Device status: %s\n"
						"    Device error status: %s\n\n", output->vswitchList[i].realDeviceList[j].realDeviceAddress, output->vswitchList[i].realDeviceList[j].controllerName,
							output->vswitchList[i].realDeviceList[j].portName, deviceStatus, deviceErrorStatus);
				}

				printf("  Authorized users:\n");
				for (k = 0; k < output->vswitchList[i].authorizedUserCount; k++) {
					printf("    User: %s\n", output->vswitchList[i].authorizedUserList[k].grantUserid);
				}

				printf("  Connections:\n");
				for (m = 0; m < output->vswitchList[i].connectedAdapterCount; m++) {
					printf("    Adapter owner: %s  Device number: %s\n", output->vswitchList[i].connectedAdapterList[m].adapterOwner, output->vswitchList[i].connectedAdapterList[m].imageDeviceNumber);
				}
			}
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int virtualNetworkVswitchSet(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * switchName = "";
	char * grantUserid = "";
	char * userVlanId = "";
	char * revokeUserid = "";
	char * realDeviceAddress = "NONE";
	char * portName = "";
	char * controllerName = "*";
	int connectionValue = 0;
	int queueMemoryLimit = 8;
	int routingValue = 0;
	int portType = 0;
	int updateSystemConfigIndicator = 0;
	char * systemConfigName = "SYSTEM";
	char * systemConfigType = "CONFIG";
	char * parmDiskOwner = "MAINT";
	char * parmDiskNumber = "CF1";
	char * parmDiskPassword = ",";
	char * altSystemConfigName = "SYSTEM";
	char * altSystemConfigType = "CONFIG";
	char * altParmDiskOwner = "MAINT";
	char * altParmDiskNumber = "CF2";
	char * altParmDiskPassword = ",";
	int gvrpValue;
	char * macId;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:n:I:v:U:r:a:i:c:q:e:p:u:L:F:R:C:P:N:Y:O:M:D:G:V:m:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'n':
				switchName = optarg;
				break;

			case 'I':
				grantUserid = optarg;
				break;

			case 'v':
				userVlanId = optarg;
				break;

			case 'U':
				revokeUserid = optarg;
				break;

			case 'r':
				realDeviceAddress = optarg;
				break;

			case 'a':
				portName = optarg;
				break;

			case 'i':
				controllerName = optarg;
				break;

			case 'c':
				connectionValue = atoi(optarg);
				break;

			case 'q':
				queueMemoryLimit = atoi(optarg);
				break;

			case 'e':
				routingValue = atoi(optarg);
				break;

			case 'p':
				portType = atoi(optarg);
				break;

			case 'u':
				updateSystemConfigIndicator = atoi(optarg);
				break;

			case 'L':
				systemConfigName = optarg;
				break;

			case 'F':
				systemConfigType = optarg;
				break;

			case 'R':
				parmDiskOwner = optarg;
				break;

			case 'C':
				parmDiskNumber = optarg;
				break;

			case 'P':
				parmDiskPassword = optarg;
				break;

			case 'N':
				altSystemConfigName = optarg;
				break;

			case 'Y':
				altSystemConfigType = optarg;
				break;

			case 'O':
				altParmDiskOwner = optarg;
				break;

			case 'M':
				altParmDiskNumber = optarg;
				break;

			case 'D':
				altParmDiskPassword = optarg;
				break;

			case 'G':
				gvrpValue = atoi(optarg);
				break;

			case 'm':
				macId = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  Virtual_Network_Vswitch_Set\n\n"
					"SYNOPSIS\n"
					"  smcli Virtual_Network_Vswitch_Set [-T] image_name [-n] switch_name\n"
					"  [-I] grant_userid [-r] real_device_address [-a] port_name [-i] controller_name\n"
					"  [-c] connection_value [-q] queue_memory_limit [-e] routing_value\n"
					"  [-t] transport_type [-v] vlan_id [-p] port_type [-u] update_sys_config\n"
					"  [-L] sys_config_name [-F] sys_config_type [-R] parm_disk_owner\n"
					"  [-C] parm_disk_number [-P] parm_disk_passwd [-N] alt_sys_config_name\n"
					"  [-Y] alt_sys_config_type [-O] alt_parm_disk_owner [-M] alt_parm_disk_number\n"
					"  [-D] alt_parm_disk_passwd [-G] gvrp [-m] mac_id\n\n"
					"DESCRIPTION\n"
					"  Use Virtual_Network_Vswitch_Set to change the configuration of an existing\n"
					"  virtual switch.\n\n"
					"  The following options are required:\n"
					"    -T    The virtual image name of the owner of the virtual switch\n"
					"    -n    The name of the virtual switch segment\n"
					"  The following options are optional:\n"
					"    -I    A userid to be added to the access list for the specified virtual switch\n"
					"    -v    The user VLAN ID\n"
					"    -U    A userid to be removed from the access list for the specified\n"
					"          virtual switch\n"
					"    -r    The real device address of a real OSA-Express QDIO device used to create\n"
					"          the switch to the virtual adapter\n"
					"    -a    The name used to identify the OSA Expanded adapter\n"
					"    -i    The userid controlling the real device\n"
					"    -c    Connection value:\n"
					"            0: Unspecified\n"
					"            1: Activate the real device connection\n"
					"            2: Do not activate the real device connection\n"
					"    -q    Queue memory limit. A number between 1 and 8 specifying the QDIO\n"
					"          buffer size in megabytes. If unspecified, the default is 8.\n"
					"    -e    Specifies whether the OSA-Express QDIO device will act as a router\n"
					"          to the virtual switch, as follows:\n"
					"            0: Unspecified\n"
					"            1: NONROUTER – The OSA-Express device will not act as a router to\n"
					"               the virtual switch\n"
					"            2: PRIROUTER – The OSA-Express device identified will act as a\n"
					"               primary router to the virtual switch\n"
					"    -p    Specifies the port type, as follows:\n"
					"            0: Unspecified\n"
					"            1: ACCESS\n"
					"            2: TRUNK\n"
					"    -u    Update system config indicator. This can be any of the following values:\n"
					"            0: Unspecified\n"
					"            1: Update the virtual switch definition on the active system\n"
					"            2: Update the virtual switch definition on the active system and in the\n"
					"               system configuration file\n"
					"            3: Update the virtual switch definition in the system configuration file\n"
					"    -L    File name of the system configuration file. The default is 'SYSTEM'.\n"
					"    -F    File type of the system configuration file. The default is 'CONFIG'.\n"
					"    -R    Owner of the parm disk. The default is 'MAINT'.\n"
					"    -C    Number of the parm disk, as defined in the server's directory.\n"
					"          The default is 'CF1'.\n"
					"    -P    Multiwrite password for the parm disk. The default is ','.\n"
					"    -N    File name of the second (alternative) system configuration file.\n"
					"          The default is 'SYSTEM'.\n"
					"    -Y    File type of the second (alternative) system configuration file.\n"
					"          The default is 'CONFIG'.\n"
					"    -O    Owner of the second (alternative) parm disk. The default is 'MAINT'.\n"
					"    -M    Number of the second (alternative) parm disk. The default is 'CF2'.\n"
					"    -D    Multiwrite password for the second (alternative) parm disk.\n"
					"          The default is ','.\n"
					"    -G    GVRP value. This can be any of the following values:\n"
					"            0: Unspecified\n"
					"            1: GVRP\n"
					"            2: NOGVRP\n"
					"    -m    The MAC identifier\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !switchName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVirtualNetworkVswitchSetOutput* output;

	int rc = smVirtual_Network_Vswitch_Set(&context, "", 0, "",
			image, switchName,  grantUserid, userVlanId, revokeUserid, realDeviceAddress,
			portName, controllerName, connectionValue, queueMemoryLimit, routingValue, portType,
			updateSystemConfigIndicator, systemConfigName, systemConfigType, parmDiskOwner, parmDiskNumber,
			parmDiskPassword, altSystemConfigName, altSystemConfigType, altParmDiskOwner,
			altParmDiskNumber, altParmDiskPassword, gvrpValue, macId, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int VMRMConfigurationQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * configFileName = NULL;
	char * configFileType = NULL;
	char * configDirName = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:c:t:d:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'c':
				configFileName = optarg;
				break;

			case 't':
				configFileType = optarg;
				break;

			case 'd':
				configDirName = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  VMRM_Configuration_Query\n\n"
					"SYNOPSIS\n"
					"  smcli VMRM_Configuration_Query [-T] image_name [-c] config_file_name\n"
					"  [-t] config_file_type [-d] config_dir_name\n\n"
					"DESCRIPTION\n"
					"  Use VMRM_Configuration_Query to query the contents of the VMRM configuration file.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -c    The name of the configuration file\n"
					"    -t    The file type of the configuration file\n"
					"    -d    The fully-qualified Shared File System (SFS) directory name\n"
					"          where the configuration file is located\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !configFileName || !configFileType || !configDirName) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVmrmConfigurationQueryOutput* output;

	int rc = smVMRM_Configuration_Query(&context, "", 0, "",
			image, configFileName, configFileType, configDirName, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		printf("%s\n", output->configurationFile);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int VMRMConfigurationUpdate(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * configFileName = NULL;
	char * configFileType = NULL;
	char * configDirName = NULL;
	int syncheck = 0;
	char * updateFile = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:c:t:d:s:u:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'c':
				configFileName = optarg;
				break;

			case 't':
				configFileType = optarg;
				break;

			case 'd':
				configDirName = optarg;
				break;

			case 's':
				syncheck = atoi(optarg);
				break;

			case 'u':
				updateFile = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  VMRM_Configuration_Update\n\n"
					"SYNOPSIS\n"
					"  smcli VMRM_Configuration_Update [-T] image_name [-c] config_file_name\n"
					"  [-t] config_file_type [-d] config_dir_name\n\n"
					"DESCRIPTION\n"
					"  Use VMRM_Configuration_Update to add, delete, and change VMRM configuration\n"
					"  file statements.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n"
					"    -c    The name of the configuration file\n"
					"    -t    The file type of the configuration file\n"
					"    -d    The fully-qualified Shared File System (SFS) directory name\n"
					"          where the configuration file is located\n"
					"    -s    Specify a 1 to choose the SYNCHECK option, meaning that only a syntax\n"
					"          check of the configuration is done, without processing a configuration\n"
					"          file update. Otherwise, specify a 0 to indicate that both a syntax check\n"
					"          and a configuration file update should occur.\n"
					"    -u    A new, complete VMRM configuration file to syntax-check or to replace\n"
					"          the old file.");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !configFileName || !configFileType || !configFileName || !syncheck || !updateFile) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVmrmConfigurationUpdateOutput* output;

	int rc = smVMRM_Configuration_Update(&context, "", 0, "",
			image, configFileName, configFileType, configFileName,
			syncheck, strlen(updateFile), updateFile, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		printf("%s\n", output->logRecordInfoList);
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int VMRMMeasurementQuery(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  VMRM_Measurement_Query\n\n"
					"SYNOPSIS\n"
					"  smcli VMRM_Measurement_Query [-T] image_name\n\n"
					"DESCRIPTION\n"
					"  Use VMRM_Measurement_Query to obtain current VMRM measurement values.\n\n"
					"  The following options are required:\n"
					"    -T    This must match an entry in the authorization file\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiVmrmMeasurementQueryOutput* output;

	int rc = smVMRM_Measurement_Query(&context, "", 0, "",
			image, &output);

	if (rc || output->common.returnCode || output->common.reasonCode) {
		// Handle return code and reason code
		printReturnCode(rc, output->common.returnCode, output->common.reasonCode);
	} else {
		printf("File name: %s\n"
			"File time stamp: %s\n"
			"Query time stamp: %s\n", output->fileName, output->fileTimestamp, output->queryTimestamp);

		int i;
		printf("Workload:\n");
		for (i = 0; i < output->workloadCount; i++) {
			printf("  %s\n", output->workloadInfoList[i].workloadRecord);
		}
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

int xCATCommandsIUO(int argC, char* argV[]) {
	// Parse the command-line arguments
	int option;
	char * image = NULL;
	char * command = NULL;
	// Options that have arguments are followed by a : character
	while ((option = getopt(argC, argV, "T:c:h?")) != -1)
		switch (option) {
			case 'T':
				image = optarg;
				break;

			case 'c':
				command = optarg;
				break;

			case 'h':
				printf("NAME\n"
					"  xCAT_Commands_IUO\n\n"
					"SYNOPSIS\n"
					"  smcli xCAT_Commands_IUO [-T] image_name [-c] command\n\n"
					"DESCRIPTION\n"
					"  Use xCAT_Commands_IUO to execute PURGE, FLASHCOPY, or SEND\n\n"
					"  The following options are required:\n"
					"    -T    The name of the virtual image\n"
					"    -c    The command with all parameters\n");
				return 1;
				break;

			default:
				break;
		}

	if (!image || !command) {
		printf("ERROR: Missing required options\n");
		return 1;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiXCATCommandsIUOOutput* output;

	int rc = smXCAT_Commands_IUO(&context, "", 0, "", // Authorizing user, password length, password
			image, command, &output);

	// Handle return code and reason code
	printReturnCode(rc, output->returnCode, output->reasonCode);

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}
