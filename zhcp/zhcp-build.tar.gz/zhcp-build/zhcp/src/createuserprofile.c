/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "wrapperutils.h"

/**
 * Creates a profile directory entry with the specified name.
 *
 * @param $1: Name of the profile which is to be created
 * @param $2: Text file containing the profile directory entry
 *
 * @return 0 If user profile entry was successfully created
 *         1 If given invalid parameters
 *         2 If user profile creation failed
 */
int main(int argC, char* argV[]) {

    if (argC < 2 || !strcmp(argV[1], "-h") || !strcmp(argV[1], "--help")) {
        printf("Creates a profile directory entry with the specified name.\n\n"
            "Usage: createuserprofile [@params]\n"
            "@param $1: Name of the profile which is to be created\n"
            "@param $2: Text file containing the profile directory entry\n");
        return 1;
    } else if (argC != 3) {
        printf("Error: Wrong number of parameters\n");
        return 1;
    }

    // Get user profile name
    char* profileName = argV[1];
    char* file = argV[2];

    // Check if the user profile name is between 1 and 8 characters
    if (isProfileNameInvalid(profileName))
        return 1;

    // Open the user entry file
    FILE * fp = fopen(file, "r");
    if (fp == NULL) {
        printf("Error: Failed to open %s\n", file);
        return 2;
    }

    printf("Creating user profile %s... ", profileName);

    VmApiInternalContext context;

    // Initialize context
    smMemoryGroupContext memContext;
    memset(&context, 0, sizeof(context));
    memset(&memContext, 0, sizeof(memContext));
    context.memContext = &memContext;
    vmApiProfileCreateDmOutput* output;

    // Count the number of lines and set the record count to it
    int recordCount = 0;
    int c;
    while ((c = fgetc(fp)) != EOF ) {
        if (c == '\n')
            recordCount++;
    }

    // Reset position to start of file
    rewind(fp);

    // Create image record
    vmApiProfileRecord record[recordCount];
    int i = 0, LINE_SIZE = 72;
    char line[recordCount][LINE_SIZE];
    char * ptr;
    while (fgets(line[i], LINE_SIZE, fp) != NULL) {
        // Replace newline with null terminator
        ptr = strstr(line[i], "\n");
        if (ptr != NULL)
            strncpy(ptr, "\0", 1);

        record[i].profileRecordLength = strlen(line[i]);
        record[i].recordData = line[i];
        i++;
    }

    // Close file
    fclose(fp);

    int rc = smProfile_Create_DM(&context, "", 0, "", // Authorizing user, password length, password
                profileName, recordCount,
                (vmApiProfileRecord *) record, // Image record
                &output);

    if (rc || (output->returnCode && output->returnCode != 592)
            || (output->reasonCode && output->reasonCode != 0)) {
        printf("Failed\n");

        rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
                    "  Reason Code: %d\n", output->returnCode, output->reasonCode);
    } else {
        printf("Done\n");
    }

    // Release context
    smMemoryGroupFreeAll(&context);
    smMemoryGroupTerminate(&context);
    return rc;
}
