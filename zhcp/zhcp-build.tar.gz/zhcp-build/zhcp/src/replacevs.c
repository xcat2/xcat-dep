/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "wrapperutils.h"

/**
 * Replace a specified directory entry.
 *
 * @param $1: Name of the guest which is to be replace
 * @param $2: Text file containing the new directory entry
 *
 * @return 0 If directory entry was successfully replaced
 *         1 If given invalid parameters
 *         2 If directory entry replacement failed
 */
int main(int argC, char* argV[]) {

	if (argC < 2 || !strcmp(argV[1], "-h") || !strcmp(argV[1], "--help")) {
		printf("Replace a specified directory entry.\n\n"
			"Usage: replacevs [@params]\n"
			"@param $1: Name of the guest which is to be replace\n"
			"@param $2: Text file containing the new directory entry\n");
		return 1;
	} else if (argC != 3) {
		printf("Error: Wrong number of parameters\n");
		return 1;
	}

	// Get image name
	char* image = argV[1];
	char* file = argV[2];

	// Check if the userID is between 1 and 8 characters
	if (isImageNameInvalid(image))
		return 1;

	// Open the user entry file
	FILE * fp = fopen(file, "r");
	if (fp == NULL) {
		printf("Error: Failed to open %s\n", file);
		return 2;
	}

	// Initialize context
	VmApiInternalContext context;
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageReplaceDmOutput* output;

	// Lock user entry
	int rc = lockImage(image, &context);
	if (rc) {
		// Release context
		smMemoryGroupFreeAll(&context);
		smMemoryGroupTerminate(&context);
		return rc;
	}

	// Count the number of lines and set the record count to it
	int recordCount = 0;
	int c;
	while ((c = fgetc(fp)) != EOF ) {
		if (c == '\n')
			recordCount++;
	}

	// Reset position to start of file
	rewind(fp);

	// Create image record
	vmApiImageRecord record[recordCount];
	int i = 0, LINE_SIZE = 72;
	char line[recordCount][LINE_SIZE];
	char * ptr;
	while (fgets(line[i], LINE_SIZE, fp) != NULL) {
		// Replace newline with null terminator
		ptr = strstr(line[i], "\n");
		if (ptr != NULL)
			strncpy(ptr, "\0", 1);

		record[i].imageRecordLength = strlen(line[i]);
		record[i].imageRecord = line[i];
		i++;
	}

	// Close file
	fclose(fp);

	printf("Replacing user entry of %s... ", image);

	rc = smImage_Replace_DM(&context, "", 0, "", // Authorizing user, password length, password
				image, recordCount,
				(vmApiImageRecord *) record, // Image record
				&output);

	if (rc || (output->returnCode && output->returnCode != 592)
			|| (output->reasonCode && output->reasonCode != 0)) {
		printf("Failed\n");

		rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
					"  Reason Code: %d\n", output->returnCode, output->reasonCode);

		// Unlock user entry
		rc = unlockImage(image, context);
	} else {
		printf("Done\n");
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}

/**
 * Lock a specified user entry.
 *
 * @param $1: Name of the virtual server which is to be locked
 *
 * @return 0 If user entry was successfully locked
 *         1 If given invalid parameters
 *         2 If user entry lock failed
 */
int lockImage(char * image, VmApiInternalContext context) {
	printf("Locking %s... ", image);

	vmApiImageLockDmOutput * output;
	int rc = smImage_Lock_DM(&context, "", // Authorizing user
			0, // Password length
			"", // Password
			image, // Image name
			"", // Device virtual address
			&output);

	if (rc || (output->returnCode && output->returnCode != 400)
			|| (output->reasonCode && output->reasonCode != 12)) {
		printf("Failed\n");

		rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
					"  Reason Code: %d\n", output->returnCode, output->reasonCode);
		return 2;
	} else {
		printf("Done\n");
		return 0;
	}
}

/**
 * Unlock a specified user entry.
 *
 * @param $1: Name of the virtual server which is to be unlocked
 *
 * @return 0 If user entry was successfully unlocked
 *         1 If given invalid parameters
 *         2 If user entry unlock failed
 */
int unlockImage(char * image, VmApiInternalContext context) {
	printf("Unlocking %s... ", image);

	vmApiImageUnlockDmOutput * output;
	int rc = smImage_Unlock_DM(&context, "", // Authorizing user
			0, // Password length
			"", // Password
			image, // Image name
			"", // Device virtual address
			&output);

	if (rc || (output->returnCode && output->returnCode != 592)
			|| (output->reasonCode && output->reasonCode != 0)) {
		printf("Failed\n");

		rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
					"  Reason Code: %d\n", output->returnCode, output->reasonCode);
		return 2;
	} else {
		printf("Done\n");
		return 0;
	}
}
