/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "wrapperutils.h"

/**
 * Remove a disk from a disk pool defined in the EXTENT CONTROL.
 *
 * @param $1: Function type, where
 * 		(1) Remove region
 * 		(2) Remove region from group
 * 		(3) Remove region from all groups
 * 		(7) Remove entire group
 * @param $2: Volume label
 * @param $3: Group name
 *
 * @return 0 If the disk was removed to the disk pool
 *         1 If given invalid parameters
 *         2 If the disk failed to be removed from the disk pool
 */
int main(int argC, char * argV[]) {

	if (argC < 2 || !strcmp(argV[1], "-h") || !strcmp(argV[1], "--help")) {
		printf("Remove a disk from a disk pool defined in the EXTENT CONTROL.\n\n"
			"Usage: removediskfrompool [@params]\n"
			"@param $1: Function type, where the value can be either\n"
			"  (1) Remove region\n"
			"  (2) Remove region from group\n"
			"  (3) Remove region from all groups\n"
			"  (7) Remove entire group\n"
			"@param $2: Region name\n"
			"@param $3: Group name\n");
		return 1;
	} else if (argC > 4) {
		printf("Error: Wrong number of parameters\n");
		return 1;
	}

	char* userId = "ZHCP";
	int functionType = atoi(argV[1]);
	char* regionName = argV[2];
	char* volLabel = "";
	char* groupName = "";

	if (functionType == 1 || functionType == 3) {
		printf("Removing %s... ", regionName);
	} else if (functionType == 2) {
		groupName = argV[3];
		printf("Removing %s from %s... ", regionName, groupName);
	} else if (functionType == 7) {
		groupName = argV[3];
		printf("Removing %s... ", groupName);
	} else {
		printf("Error: Function type must be 1, 2, 3, or 7\n");
		return 1;
	}

	VmApiInternalContext context;

	// Initialize context
	smMemoryGroupContext memContext;
	memset(&context, 0, sizeof(context));
	memset(&memContext, 0, sizeof(memContext));
	context.memContext = &memContext;
	vmApiImageVolumeSpaceRemoveDmOutput* output;

	int rc = smImage_Volume_Space_Remove_DM(&context, "", 0, "", // Authorizing user, password length, password.
			userId, functionType, regionName, volLabel, groupName, // Region name, volume ID, and group name
			&output);

	if (rc || (output->returnCode && output->returnCode != 592)
			|| (output->reasonCode && output->reasonCode != 0)) {
		printf("Failed\n");

		rc ? printf("  Return Code: %d\n", rc) : printf("  Return Code: %d\n"
			"  Reason Code: %d\n", output->returnCode, output->reasonCode);
	} else {
		printf("Done\n");
	}

	// Release context
	smMemoryGroupFreeAll(&context);
	smMemoryGroupTerminate(&context);
	return rc;
}
