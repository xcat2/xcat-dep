// IBM (C) Copyright 2010 Eclipse Public License
// http://www.eclipse.org/org/documents/epl-v10.html
#ifndef _VMAPI_VMRM_H
#define _VMAPI_VMRM_H
#include "smPublic.h"
#include "smapiTableParser.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// VMRM_Configuration_Query
typedef struct _vmApiVmrmConfigurationQuery {
	commonOutputFields common;
	char * configurationFile;
	int configurationFileLength;
} vmApiVmrmConfigurationQueryOutput;

// Parser table for VMRM_Configuration_Query
static tableLayout VMRM_Configuration_Query_Layout = { {
		APITYPE_BASE_STRUCT_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0,
		sizeof(vmApiVmrmConfigurationQueryOutput) }, { APITYPE_INT4, 4, 4,
		STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationQueryOutput, common.requestId) }, {
		APITYPE_INT4, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationQueryOutput, common.returnCode) }, {
		APITYPE_INT4, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationQueryOutput, common.reasonCode) }, {
		APITYPE_CHARBUF_LEN, 1, -1, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationQueryOutput, configurationFile) }, {
		APITYPE_CHARBUF_COUNT, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationQueryOutput, configurationFileLength) },
		{ APITYPE_END_OF_TABLE, 0, 0, 0, 0 } };

int smVMRM_Configuration_Query(struct _VmApiInternalContext* vmapiContextP,
		char * userid, int passwordLength, char * password,
		char * targetIdentifier, char * configurationFileName,
		char * configurationFileType, char * configurationDirName,
		vmApiVmrmConfigurationQueryOutput ** outData);

// VMRM_Configuration_Update
typedef struct _vmApiVmrmConfigurationLogRecordInfo {
	char * logRecord;
	int logRecordLength;
} vmApiVmrmConfigurationLogRecordInfo;

typedef struct _vmApiVmrmConfigurationUpdateOutput {
	commonOutputFields common;
	int logRecordCount;
	vmApiVmrmConfigurationLogRecordInfo * logRecordInfoList;
} vmApiVmrmConfigurationUpdateOutput;

// Parser table for VMRM_Configuration_Update
static tableLayout VMRM_Configuration_Update_Layout = { {
		APITYPE_BASE_STRUCT_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0,
		sizeof(vmApiVmrmConfigurationUpdateOutput) }, { APITYPE_INT4, 4, 4,
		STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationUpdateOutput, common.requestId) }, {
		APITYPE_INT4, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationUpdateOutput, common.returnCode) }, {
		APITYPE_INT4, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmConfigurationUpdateOutput, common.reasonCode) },

{ APITYPE_ARRAY_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
		vmApiVmrmConfigurationUpdateOutput, logRecordInfoList) }, {
		APITYPE_ARRAY_STRUCT_COUNT, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0,
		offsetof(vmApiVmrmConfigurationUpdateOutput, logRecordCount) }, {
		APITYPE_NOBUFFER_STRUCT_LEN, 4, 4, STRUCT_INDX_1, NEST_LEVEL_1,
		sizeof(vmApiVmrmConfigurationLogRecordInfo) }, { APITYPE_CHARBUF_LEN,
		1, -1, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(
				vmApiVmrmConfigurationLogRecordInfo, logRecord) }, {
		APITYPE_CHARBUF_COUNT, 4, 4, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(
				vmApiVmrmConfigurationLogRecordInfo, logRecordLength) },

{ APITYPE_END_OF_TABLE, 0, 0, 0, 0 } };

int smVMRM_Configuration_Update(struct _VmApiInternalContext* vmapiContextP,
		char * userid, int passwordLength, char * password,
		char * targetIdentifier, char * configurationFileName,
		char * configurationFileType, char * configurationDirName,
		char syncheckOnly, int updateFileLength, char * updateFile,
		vmApiVmrmConfigurationUpdateOutput ** outData);

// VMRM_Measurement_Query
typedef struct _vmApiVmrmMeasurementQueryWorkloadInfo {
	char * workloadRecord;
	int workloadRecordLength;
} vmApiVmrmMeasurementQueryWorkloadInfo;

typedef struct _vmApiVmrmMeasurementQueryOutput {
	commonOutputFields common;
	char * queryTimestamp;
	char * fileName;
	char * fileTimestamp;
	int workloadCount;
	vmApiVmrmMeasurementQueryWorkloadInfo * workloadInfoList;
} vmApiVmrmMeasurementQueryOutput;

// Parser table for VMRM_Measurement_Query
static tableLayout VMRM_Measurement_Query_Layout = { { APITYPE_BASE_STRUCT_LEN,
		4, 4, STRUCT_INDX_0, NEST_LEVEL_0,
		sizeof(vmApiVmrmMeasurementQueryOutput) }, { APITYPE_INT4, 4, 4,
		STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiVmrmMeasurementQueryOutput,
				common.requestId) }, { APITYPE_INT4, 4, 4, STRUCT_INDX_0,
		NEST_LEVEL_0, offsetof(vmApiVmrmMeasurementQueryOutput,
				common.returnCode) }, { APITYPE_INT4, 4, 4, STRUCT_INDX_0,
		NEST_LEVEL_0, offsetof(vmApiVmrmMeasurementQueryOutput,
				common.reasonCode) }, { APITYPE_STRING_LEN, 1, 17,
		STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiVmrmMeasurementQueryOutput,
				queryTimestamp) }, { APITYPE_STRING_LEN, 1, 20, STRUCT_INDX_0,
		NEST_LEVEL_0, offsetof(vmApiVmrmMeasurementQueryOutput, fileName) }, {
		APITYPE_STRING_LEN, 1, 17, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
				vmApiVmrmMeasurementQueryOutput, fileTimestamp) },

{ APITYPE_ARRAY_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(
		vmApiVmrmMeasurementQueryOutput, workloadInfoList) }, {
		APITYPE_ARRAY_STRUCT_COUNT, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0,
		offsetof(vmApiVmrmMeasurementQueryOutput, workloadCount) }, {
		APITYPE_NOBUFFER_STRUCT_LEN, 4, 4, STRUCT_INDX_1, NEST_LEVEL_1,
		sizeof(vmApiVmrmMeasurementQueryWorkloadInfo) }, { APITYPE_CHARBUF_LEN,
		1, 35, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(
				vmApiVmrmMeasurementQueryWorkloadInfo, workloadRecord) }, {
		APITYPE_CHARBUF_COUNT, 1, 4, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(
				vmApiVmrmMeasurementQueryWorkloadInfo, workloadRecordLength) },

{ APITYPE_END_OF_TABLE, 0, 0, 0, 0 } };

int smVMRM_Measurement_Query(struct _VmApiInternalContext* vmapiContextP,
		char * userid, int passwordLength, char * password,
		char * targetIdentifier, vmApiVmrmMeasurementQueryOutput ** outData);

#ifdef __cplusplus
}
#endif

#endif
