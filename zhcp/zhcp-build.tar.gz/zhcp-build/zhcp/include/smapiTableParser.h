/**
 * IBM (C) Copyright 2012 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#ifndef _VMAPI_PARSER_ROUTINE_H
#define _VMAPI_PARSER_ROUTINE_H

#include <stddef.h>
#include <sys/types.h>
#include <netinet/in.h>
#include "smPublic.h"

#ifdef __cplusplus
extern "C" {
#endif

// Common information returned by SMAPI
typedef struct _commonOutputFields {
    int requestId;
    int returnCode;
    int reasonCode;
} commonOutputFields;

// Used to handle unknown number of zero terminated data returned by the SMAPI
typedef struct _vmApiCStringInfo {
    char * vmapiString;
} vmApiCStringInfo;

#define APITYPE_END_OF_TABLE 0
#define APITYPE_INT1         1
#define APITYPE_INT4         2
#define APITYPE_INT8         3

#define APITYPE_STRING_LEN          20
#define APITYPE_ARRAY_LEN           21
#define APITYPE_ARRAY_STRUCT_COUNT  22
#define APITYPE_STRUCT_LEN          23
#define APITYPE_NOBUFFER_STRUCT_LEN 24
#define APITYPE_CHARBUF_LEN         25
#define APITYPE_CHARBUF_COUNT       26
#define APITYPE_C_STR_ARRAY_PTR     30
#define APITYPE_C_STR_ARRAY_COUNT   31
#define APITYPE_C_STR_STRUCT_LEN    32
#define APITYPE_C_STR_PTR           33
#define APITYPE_BASE_STRUCT_LEN     98

#define STRUCT_INDX_0    0
#define STRUCT_INDX_1    1
#define STRUCT_INDX_2    2
#define STRUCT_INDX_3    3
#define STRUCT_INDX_4    4
#define STRUCT_INDX_5    5
#define STRUCT_INDX_6    6
#define STRUCT_INDX_7    7
#define STRUCT_INDX_8    8
#define STRUCT_INDX_9    9
#define STRUCT_INDX_10   10

#define NEST_LEVEL_0  0
#define NEST_LEVEL_1  1
#define NEST_LEVEL_2  2
#define NEST_LEVEL_3  3

#define MAX_STRUCT_ARRAYS 10

#define COL_1_TYPE           0
#define COL_2_MINSIZE        1
#define COL_3_MAXSIZE        2
#define COL_4_STRUCT_INDEX   3
#define COL_5_NEST_LEVEL     4
#define COL_6_SIZE_OR_OFFSET 5

enum tableParserModes {
    scan, populate
};

typedef int tableLayout[][6];

/**
 * Input/output structure for use by smapiTableParser
 */
typedef struct _tableParserParms {
    char * smapiBufferCursor;
    int dataBufferSize;
    int byteCount;
    int outStringByteCount;
    int outStructCount[MAX_STRUCT_ARRAYS];
    int outStructSizes[MAX_STRUCT_ARRAYS];
    void * inStructAddrs[MAX_STRUCT_ARRAYS];
    char * inStringCursor;
} tableParserParms;

#define PARSER_ERROR_INVALID_TABLE       -4002
#define PARSER_ERROR_INVALID_STRING_SIZE -4003

#define ntohll(x) (((unsigned long long)(ntohl((int)((x << 32) >> 32))) << 32) | (unsigned int)ntohl(((int)(x >> 32))))
#define htonll(x) ntohll(x)

#define PUT_INT(_inInt_,_outBuf_) \
 ({ int _int;                     \
    _int = htonl(_inInt_) ;       \
    memcpy(_outBuf_, &_int, 4);   \
    _outBuf_ += 4;                \
 })

#define GET_INT(_outInt_,_inBuf_) \
 ({ int _int;                     \
    memcpy(&_int, _inBuf_, 4);    \
    _outInt_ = ntohl(_int) ;      \
    _inBuf_ += 4;                 \
 })

#define PUT_64INT(_in64Int_,_outBuf_) \
 ({ long long _64int;                  \
    _64int = htonll(_in64Int_) ;       \
    memcpy(_outBuf_, &_64int, 8);      \
    _outBuf_ += 8;                     \
 })

#define GET_64INT(_out64Int_,_inBuf_) \
 ({ long long _64int;                 \
    memcpy(&_64int, _inBuf_, 8);      \
    _out64Int_ = ntohll(_64int) ;     \
    _inBuf_ += 8;                     \
 })

int parseBufferWithTable(struct _VmApiInternalContext* vmapiContextP,
        enum tableParserModes mode, tableLayout table, tableParserParms *parms);

int getAndParseSmapiBuffer(struct _VmApiInternalContext* vmapiContextP,
        char * * inputBufferPointerPointer, int inputBufferSize,
        tableLayout parserTable, char * parserTableName, char * * outData);

#ifdef __cplusplus
}
#endif
#endif
