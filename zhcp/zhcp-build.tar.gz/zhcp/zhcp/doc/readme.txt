z/VM Systems Management Application Programming Version 6 Release 2
http://publibz.boulder.ibm.com/epubs/pdf/hcsl8c11.pdf