/**
 * IBM (C) Copyright 2011,2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "cikada.h"

// The first 16 bytes in each track are a label declaring the cylinder and
// track indices.
#define TRACK_BEGINNING_OVERHEAD 16

// Fixed data which appears in gap near the beginning of each track.
uint8_t  trackGap[12] = {0x00,0x00,0x00,0x08,
                         0x00,0x00,0x00,0x00,
                         0x00,0x00,0x00,0x00};

static inline void readNBytesFromStdin(void* buffer, int bytes) {
  int bytesRead = 0;
  while (bytesRead < bytes) {
    bytesRead += read(STDIN_FILENO, buffer + bytesRead, bytes - bytesRead);
  }
}

int main (int argumentCount, char* argumentValues[]) {
  int returnCode, exitCode = 0;
  uint8_t  keyCountRunCount;        // Number of key count runs.
  uint8_t  keyCountRunTotal;        // Sum of key count run lengths.
  uint8_t  keyCountRunLength[256];  // List of key count run lengths.
  uint8_t  keyCountRunValue[256];   // List of key count run values.
  uint8_t  keyCountRunIndex;        // Key run being processed.
  uint8_t  keyCountRunRemaining;    // Keys left in run being processed.
  uint8_t  dataCountRunCount;       // Number of data count runs.
  uint8_t  dataCountRunTotal;       // Sum of data count run lengths.
  uint8_t  dataCountRunLength[256]; // List of data count run lengths.
  uint16_t dataCountRunValue[256];  // List of data count run values.
  uint8_t  dataCountRunIndex;       // Data run being processed.
  uint8_t  dataCountRunRemaining;   // Data blocks left in run being processed.
  uint8_t  recordsInTrack;          // Count of records in track being written.
  uint8_t  keyCount;                // Size of key being processed.
  uint16_t dataCount;               // Size of data block being processed.
  uint32_t trackIndex;              // Index of track being processed.
  void*    trackBuffer;             // Buffer for assembling track data before
                                    // writing it to disk.
  void*    trackBufferCursor;       // Pointer to place within track buffer
                                    // to which the next write should be
                                    // performed.
  if (argumentCount != 2) {
    fprintf(stderr, "Usage: %s DEVICE_NODE\n", argumentValues[0]);
    return 1;
  }
  int dasdDescriptor = open(argumentValues[1], O_WRONLY | O_DIRECT);
  if (dasdDescriptor == -1) {
    fprintf(stderr, "Error opening disk for writing\n");
    return 2;
  }
  returnCode = posix_memalign(&trackBuffer, 4096, 65536);
  if (returnCode) {
    fprintf(stderr, "Error allocating buffer\n");
    return 3;
  }
  trackIndex = 0;
  while ((returnCode = read(STDIN_FILENO,
                            &recordsInTrack,
                            sizeof(recordsInTrack)) > 0)) {
    keyCountRunCount  = 0;
    keyCountRunTotal  = 0;
    dataCountRunCount = 0;
    dataCountRunTotal = 0;
    while (keyCountRunTotal < recordsInTrack) {
      // Read key count run length and value...
      readNBytesFromStdin(&keyCountRunLength[keyCountRunCount], 1);
      readNBytesFromStdin(&keyCountRunValue[keyCountRunCount],  1);
      keyCountRunTotal+=keyCountRunLength[keyCountRunCount];
      keyCountRunCount++;
    }
    while (dataCountRunTotal < recordsInTrack) {
      // Read data count run length and value...
      readNBytesFromStdin(&dataCountRunLength[dataCountRunCount], 1);
      readNBytesFromStdin(&dataCountRunValue[dataCountRunCount], 2);
      dataCountRunTotal+=dataCountRunLength[dataCountRunCount];
      dataCountRunCount++;
    }
    keyCountRunIndex      = 0;
    keyCountRunRemaining  = keyCountRunLength[0] - 1;
    dataCountRunIndex     = 0;
    dataCountRunRemaining = dataCountRunLength[0] - 1;
    // Write the cylinder, track, and gap to beginning of track buffer:
    trackBufferCursor = trackBuffer;
    ((uint16_t*)trackBufferCursor)[0] = (uint16_t)(trackIndex / 15);
    trackBufferCursor += 2;
    ((uint16_t*)trackBufferCursor)[0] = (uint16_t)(trackIndex % 15);
    trackBufferCursor += 2;
    memcpy(trackBufferCursor, trackGap, sizeof(trackGap));
    trackBufferCursor += sizeof(trackGap);
    // Write the records in this track to the track buffer:
    for (uint8_t i = 0; i < recordsInTrack; i++) {
      keyCount = keyCountRunValue[keyCountRunIndex];
      dataCount = dataCountRunValue[dataCountRunIndex];
      // Write record metadata:
      ((uint16_t*)trackBufferCursor)[0] = (uint16_t)(trackIndex / 15);
      trackBufferCursor += 2;
      ((uint16_t*)trackBufferCursor)[0] = (uint16_t)(trackIndex % 15);
      trackBufferCursor += 2;
      // Record numbers are for some reason indexed off of 1 in the raw CKD
      // encoding, despite indexing off of 0 for cylinders and tracks.
      ((uint8_t*)trackBufferCursor)[0] = (i + 1);
      trackBufferCursor += 1;
      ((uint8_t*)trackBufferCursor)[0] = keyCount;
      trackBufferCursor += 1;
      ((uint16_t*)trackBufferCursor)[0] = dataCount;
      trackBufferCursor += 2;
      // Write record key into track buffer:
      while (keyCount > 0) {
        returnCode = read(STDIN_FILENO, trackBufferCursor, keyCount);
        if (returnCode < 0) {
          fprintf(stderr, "Error reading record key\n");
          fprintf(stderr, "0x%02x bytes read\n", returnCode);
          close(dasdDescriptor);
          free(trackBuffer);
          return 5;
        } else {
          trackBufferCursor += returnCode;
          keyCount -= returnCode;
        }
      }
      // Write record data into track buffer:
      while (dataCount > 0) {
        returnCode = read(STDIN_FILENO, trackBufferCursor, dataCount);
        if (returnCode < 0) {
          fprintf(stderr, "Error reading record data\n");
          fprintf(stderr, "0x%04x bytes read\n", returnCode);
          close(dasdDescriptor);
          free(trackBuffer);
          return 5;
        } else {
          trackBufferCursor += returnCode;
          dataCount -= returnCode;
        }
      }
      if (keyCountRunRemaining) {
        keyCountRunRemaining--;
      } else {
        keyCountRunRemaining = keyCountRunLength[++keyCountRunIndex] - 1;
      }
      if (dataCountRunRemaining) {
        dataCountRunRemaining--;
      } else {
        dataCountRunRemaining = dataCountRunLength[++dataCountRunIndex] - 1;
      }
    }
    memset(trackBufferCursor, 0xFF, 12);
    trackBufferCursor += 12;
    memset(trackBufferCursor,
           0x00,
           TRACK_SIZE - (trackBufferCursor - trackBuffer));
    returnCode = write(dasdDescriptor, trackBuffer, TRACK_SIZE);
    if (returnCode < TRACK_SIZE) {
      fprintf(stderr, "A problem was encountered writing to the target disk\n");
      close(dasdDescriptor);
      free(trackBuffer);
      return 6;
    }
    trackIndex++;
  }
  if (returnCode < 0) exitCode = 4;
  close(dasdDescriptor);
  free(trackBuffer);
  return exitCode;
}
