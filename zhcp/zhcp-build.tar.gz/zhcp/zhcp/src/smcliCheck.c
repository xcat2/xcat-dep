/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */

#include "smcliCheck.h"
#include "wrapperutils.h"

int checkAuthentication(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    vmApiCheckAuthenticationOutput* output;

    // Parse the command-line arguments
    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "h?")) != -1)
        switch (option) {
            case 'h':
                printf("NAME\n"
                    "  Check_Authentication\n\n"
                    "SYNOPSIS\n"
                    "  smcli Check_Authentication\n\n"
                    "DESCRIPTION\n"
                    "  Use Check_Authentication to validate a userId/password pair.\n");
                return 1;
                break;

            default:
                return 1;
            break;
    }

    printf("Validating userId/password pair... ");
    rc = smCheck_Authentication(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
             &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Check_Authentication", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Check_Authentication", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}
