/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include <stdio.h>
#include <stdlib.h>
#include "smcliImage.h"
#include "wrapperutils.h"

int imageActivate(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageActivateOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Activate\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Activate [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Activate to activate a virtual image or list of virtual images.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image being activated\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }


    if (!image) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Activating %s... ", image);
    rc = smImage_Activate(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Activate", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Activate", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageActiveConfigurationQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageActiveConfigurationQueryOutput * output;
    vmApiImageCpuInfo* cpuList;
    vmApiImageDeviceInfo* deviceList;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Active_Configuration_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Active_Configuration_Query [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Active_Configuration_Query to obtain current configuration\n"
                    "  information for an active virtual image.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid being queried\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    // Handle return code and reason code
    rc = smImage_Active_Configuration_Query(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Active_Configuration_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Active_Configuration_Query", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out active configuration
        int cpuInfoCount = output->cpuInfoCount;
        int deviceCount = output->deviceCount;
        int memorySize = output->memorySize;
        int numberOfCpus = output->numberOfCpus;
        char* shareType = "";
        if (output->shareType == 1) {
            shareType = "Relative";
        } else if (output->shareType == 2) {
            shareType = "Absolute";
        }

        char* shareValue = output->shareValue;
        char* memoryUnit = "";
        if (output->memoryUnit == 1) {
            memoryUnit = "KB";
        } else if (output->memoryUnit == 2) {
            memoryUnit = "MB";
        } else if (output->memoryUnit == 3) {
            memoryUnit = "GB";
        }

        printf("Memory: %i %s\n"
            "Share type: %s\n"
            "Share value: %s\n"
            "CPU count: %i\n", memorySize, memoryUnit, shareType, shareValue, numberOfCpus);

        cpuList = output->cpuList;
        int i;
        char* cpuType;
        char* cpuStatus;
        printf("CPUs\n");
        for (i = 0; i < numberOfCpus; i++) {
            if (cpuList[i].cpuStatus == 1) {
                cpuStatus = "Base";
            } else if (cpuList[i].cpuStatus == 2) {
                cpuStatus = "Stopped";
            } else if (cpuList[i].cpuStatus == 3) {
                cpuStatus = "Check-stopped";
            } else if (cpuList[i].cpuStatus == 4) {
                cpuStatus = "Non-base, active";
            }
            printf("  Address: %i\n"
                "  ID: %s (%s)\n", cpuList[i].cpuNumber, cpuList[i].cpuId, cpuStatus);
        }

        deviceList = output->deviceList;
        char* deviceType;
        printf("Devices\n");
        for (i = 0; i < deviceCount; i++) {
            if (deviceList[i].deviceType == 1) {
                deviceType = "CONS";
            } else if (deviceList[i].deviceType == 2) {
                deviceType = "RDR";
            } else if (deviceList[i].deviceType == 3) {
                deviceType = "PUN";
            } else if (deviceList[i].deviceType == 4) {
                deviceType = "PRT";
            } else if (deviceList[i].deviceType == 5) {
                deviceType = "DASD";
            }
            printf("  Address: %s (%s)\n", deviceList[i].deviceAddress, deviceType);
        }
    }
    return rc;
}

int imageCPUDefine(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int cpuType = -1;
    char * image = NULL;
    char * cpuAddress = NULL;
    vmApiImageCpuDefineOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:t:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                cpuAddress = optarg;
                break;

            case 't':
                cpuType = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_CPU_Define\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_CPU_Define [-T] image_name [-v] virtual_address\n"
                    "    [-t] cpu_type\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_CPU_Define to add a virtual processor to an active virtual\n"
                    "  image's configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual image for which to define a virtual CPU\n"
                    "    -v    The virtual CPU address to add to the virtual image\n"
                    "    -t    The type of processor to add:\n"
                    "            0: Unspecified\n"
                    "            1: CP\n"
                    "            2: IFL\n"
                    "            3: ZAAP\n"
                    "            4: ZIIP\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !cpuAddress || (cpuType < 0)) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Adding a virtual processor to %s's configuration...\n", image);
    rc = smImage_CPU_Define(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, cpuAddress, cpuType, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_CPU_Define", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_CPU_Define", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageCPUDefineDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int baseCpu = -1;
    int dedicateCpu = -1;
    int cryto = -1;
    char * image = NULL;
    char * cpuAddress = NULL;
    char * cpuId = "";
    vmApiImageCpuDefineDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:b:c:d:y:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                cpuAddress = optarg;
                break;

            case 'b':
                baseCpu = atoi(optarg);
                break;

            case 'c':
                cpuId = optarg;
                break;

            case 'd':
                dedicateCpu = atoi(optarg);
                break;

            case 'y':
                cryto = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_CPU_Define_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_CPU_Define_DM [-T] image_name [-v] virtual_address\n"
                    "    [-b] base_cpu [-d] dedicate_cpu [-y] cryto_cpu [-c] cpu_id\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_CPU_Define_DM to add a virtual processor to a virtual image's\n"
                    "  directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual image for which to statically define a\n"
                    "          virtual CPU.\n"
                    "    -v    The virtual CPU address to add to the static definition of the\n"
                    "          virtual image (in the hexadecimal range of 0-3F)\n"
                    "    -b    Whether this CPU defines the base virtual processor:\n"
                    "            0: Unspecified\n"
                    "            1: BASE\n"
                    "    -d    Whether the virtual processor is to be dedicated at LOGON time to a\n"
                    "          real processor:\n"
                    "            0: Unspecified\n"
                    "            1: NODEDICATE\n"
                    "            2: DEDICATE\n"
                    "    -y    Whether the virtual Cryptographic Coprocessor Facility (CCF) should be\n"
                    "          defined automatically for the virtual CPU at LOGON time:\n"
                    "            0: Unspecified (no CRYPTO)\n"
                    "            1: CRYPTO\n"
                    "  The following options are optional:\n"
                    "    -c    The processor identification number to be stored in bits 8 through 31\n"
                    "          of the CPU ID, returned in response to the store processor ID (STIDP)\n"
                    "          instruction\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }


    if (!image || !cpuAddress || (baseCpu < 0) || (dedicateCpu < 0)|| (cryto < 0)) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Adding a virtual processor to %s's directory entry...", image);
    rc = smImage_CPU_Define_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, cpuAddress, baseCpu, cpuId, dedicateCpu, cryto, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_CPU_Define", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_CPU_Define", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageCPUDelete(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * cpuAddress = NULL;
    vmApiImageCpuDeleteOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                cpuAddress = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_CPU_Delete\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_CPU_Delete [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_CPU_Delete to delete a virtual processor from an active\n"
                    "  virtual image's configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of a virtual image for which a virtual CPU will\n"
                    "          be deleted.\n"
                    "    -v    The virtual CPU address to delete from the virtual image\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }


    if (!image || !cpuAddress) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting a virtual processor from %s's active configuration...\n", image);
    rc = smImage_CPU_Delete(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, cpuAddress, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_CPU_Delete", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_CPU_Delete", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageCPUDeleteDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * virtualAddress = NULL;
    vmApiImageCpuDeleteDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualAddress = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_CPU_Delete_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_CPU_Delete_DM [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_CPU_Delete_DM to delete a virtual processor from a\n"
                    "  virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual image from which to statically\n"
                    "          delete a virtual CPU.\n"
                    "    -v    The virtual CPU address to delete from the static\n"
                    "          definition of the virtual image (in the hexadecimal\n"
                    "          range of 0-3F).\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }


    if (!image || !virtualAddress) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting a virtual processor from %s's directory entry...\n", image);
    rc = smImage_CPU_Delete_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualAddress, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_CPU_Delete_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_CPU_Delete_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageCPUQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageCpuQueryOutput* output;
    vmApiImageCpuInfo* cpuList;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_CPU_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_CPU_Query [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_CPU_Query to query the virtual processors in an active\n"
                    "  virtual image's configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual image whose virtual CPUs are\n"
                    "          being queried\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_CPU_Query(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_CPU_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_CPU_Query", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out active configuration
        int cpuInfoCount = output->cpuInfoCount;
        int numberOfCpus = output->numberOfCpus;

        printf("CPU count: %i\n", numberOfCpus);

        cpuList = output->cpuList;
        int i;
        char* cpuType;
        char* cpuStatus;
        printf("CPUs\n");
        for (i = 0; i < numberOfCpus; i++) {
            if (cpuList[i].cpuStatus == 1) {
                cpuStatus = "Base";
            } else if (cpuList[i].cpuStatus == 2) {
                cpuStatus = "Stopped";
            } else if (cpuList[i].cpuStatus == 3) {
                cpuStatus = "Check-stopped";
            } else if (cpuList[i].cpuStatus == 4) {
                cpuStatus = "Non-base, active";
            }

            if (cpuList[i].cpuType == 1) {
                cpuType = "CP";
            } else if (cpuList[i].cpuType == 2) {
                cpuType = "IFL";
            } else if (cpuList[i].cpuType == 3) {
                cpuType = "ZAAP";
            } else if (cpuList[i].cpuType == 4) {
                cpuType = "ZIIP";
            }
            printf("  Address: %i\n"
                "    Type: %s\n"
                "    ID: %s (%s)\n", cpuList[i].cpuNumber, cpuType, cpuList[i].cpuId, cpuStatus);
        }
    }
    return rc;
}

int imageCPUQueryDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * cpuAddress = NULL;
    vmApiImageCpuQueryDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                cpuAddress = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_CPU_Query_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_CPU_Query_DM [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_CPU_Query_DM to query a virtual processor in a virtual\n"
                    "  image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual image from which to query a\n"
                    "          virtual CPU\n"
                    "    -v    The virtual CPU address to query from the static definition\n"
                    "          of the virtual image\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !cpuAddress) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_CPU_Query_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, cpuAddress, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_CPU_Query_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_CPU_Query_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        char* cpuAddress = output->cpuAddress;

        char* baseCpu = "Unspecified";
        if (output->baseCpu == 0) {
            baseCpu = "Unspecified";
        } else if (output->baseCpu == 1) {
            baseCpu = "BASE";
        }

        char* cpuId = output->cpuId;

        char* dedicateCpu = "Unspecified";
        if (output->cpuDedicate == 0) {
            dedicateCpu = "Unspecified";
        } else if (output->cpuDedicate == 1) {
            dedicateCpu = "NODEDICATE";
        } else if (output->cpuDedicate == 2) {
            dedicateCpu = "DEDICATE";
        }

        char* crypto = "Unspecified";
        if (output->cpuCrypto == 0) {
            crypto = "Unspecified";
        } else if (output->cpuCrypto == 1) {
            crypto = "CRYPTO";
        }

        printf("Address: %s (%s)\n"
            "ID: %s\n"
            "Dedicated: %s\n"
            "CCF: %s\n", cpuAddress, baseCpu, cpuId, dedicateCpu, crypto);
    }
    return rc;
}

int imageCPUSetMaximumDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int maxCpu = 0;
    char * image = NULL;
    vmApiImageCpuSetMaximumDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:m:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'm':
                maxCpu = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_CPU_Set_Maximum_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_CPU_Set_Maximum_DM [-T] image_name [-m] max_cpu\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_CPU_Set_Maximum_DM to set the maximum number of virtual\n"
                    "  processors that can be defined in a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T     The name of the virtual image for which to set the maximum\n"
                    "           number of virtual processors\n"
                    "    -m     The maximum number of virtual processors the user can define\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !maxCpu) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Setting the maximum number of virtual processors to %d for %s directory entry... ", maxCpu, image);
    rc = smImage_CPU_Set_Maximum_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, maxCpu, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_CPU_Set_Maximum_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_CPU_Set_Maximum_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageCreateDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * userEntryFile = NULL;
    int userEntryStdin = 0;
    char * prototype = "";
    char * password = "";
    char * accountNumber = "";

    FILE * fp;
    int recordCount = 0;
    int c;
    char * ptr;

    int i;
    int j;
    int LINE_SIZE = 72;
    char buffer[100][LINE_SIZE];

    vmApiImageCreateDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:p:w:a:sh?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;
            case 'f':
                userEntryFile = optarg;
                break;
            case 's':
                userEntryStdin = 1;
                break;
            case 'p':
                prototype = optarg;
                break;
            case 'w':
                password = optarg;
                break;
            case 'a':
                accountNumber = optarg;
                break;
            case 'h':
                printf("NAME\n"
                    "  Image_Create_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Create_DM [-T] image_name [-f] user_entry_file\n"
                    "    [-p] prototype [-w] password [-a] account_number\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Create_DM to define a new virtual image in the directory.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to be created\n"
                    "   Only one of the following options can be used\n\n"
                    "    -f    The directory entry file. Not required if a directory entry\n"
                    "          is provided from stdin.\n"
                    "    -s    Read the directory entry from stdin. Not required if a directory entry\n"
                    "          file is provided.\n"
                    "    -p    The prototype to use for creating the image\n\n"
                    "  The following options are optional:\n"
                    "    -w    The logon password to be assigned initially to the virtual image\n"
                    "          being created\n"
                    "    -a    The account number to be assigned initially to the virtual image\n"
                    "          being created\n\n"
                    "     Notes:\n"
                    "         1. If both the prototype and directory entry parameters are specified,\n"
                    "            then the prototype will be used and the directory entry parameter\n"
                    "            will be ignored.\n"
                    "         2. Neither the logon password nor the account number input parameters\n"
                    "            may be specified if directory entry is specified.\n");
                return 1;
                break;

            case 1:  // API name type data(other non option element key data)
            	break;

            default:
                return 1;
                break;
        }


    if (image == NULL || (userEntryFile == NULL && userEntryStdin == 0 && strlen(prototype) == 0)) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    if (userEntryFile != NULL) {
        // Open the user entry file
        fp = fopen(userEntryFile, "r");
        if (NULL == fp) {
            printf("\nERROR: Failed to open file %s\n", userEntryFile);
            return 2;
        }

        // Count the number of lines and set the record count to it
        j = 0;
        while ((c = fgetc(fp)) != EOF) {
            if (c == '\n') {
            	j++;
            	if (j <= 72) {
                    recordCount++;
                    j = 0;
                } else {
                    printf("\nERROR: Input file %s line %d contains %d chars of input and the max is 72\n",
                           userEntryFile, recordCount + 1, j);
            	    return 3;
                }
            } else {
                j++;
            }
        }

        // Reset position to start of file
        rewind(fp);
    } else if (userEntryStdin == 1) {
    	i=0;
        // Read in user entry from stdin
        while (fgets(buffer[i], LINE_SIZE, stdin) != NULL) {
            // Replace newline with null terminator
            ptr = strstr(buffer[i], "\n");
            if (ptr != NULL) {
                strncpy(ptr, "\0", 1);
                // Count the number of lines and set the record count to it
                recordCount++;
            }
            i++;
            if ((i == 100) && (stdin != NULL)) {
                printf("\nERROR: stdin contains more then 100 lines of input\n");
                return 4;
            }
        }
    }

    // Create image record
    vmApiImageRecord record[recordCount];
    char line[recordCount][LINE_SIZE];
	i=0;
    if (userEntryFile != NULL) {
        // Read in user entry from file
        while (fgets(line[i], LINE_SIZE, fp) != NULL) {
            // Replace newline with null terminator
            ptr = strstr(line[i], "\n");
            if (ptr != NULL) {
                strncpy(ptr, "\0", 1);
            }
            if (i == recordCount) {
            	// This should never happen but checking anyway
                printf("\nERROR: file contains more then %d lines of input\n", i);
                return 5;
            } else {
                record[i].imageRecordLength = strlen(line[i]);
                record[i].imageRecord = line[i];
                i++;
            }
        }

        // Close file
        fclose(fp);
    } else {
        // Read in user entry from stdin buffer
        for (i = 0; i < recordCount; i++) {
            record[i].imageRecordLength = strlen(buffer[i]);
            record[i].imageRecord = buffer[i];
        }
    }

    printf("Defining %s in the directory... ", image);
    rc = smImage_Create_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, prototype, strlen(password), password,  // Initial password length, initial password
            accountNumber, recordCount,  // Initial account number, image record array length
            (vmApiImageRecord *) record,  // Image record
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Create_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Create_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }

    return rc;
}

int imageDeactivate(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * forceTime = "";
    vmApiImageDeactivateOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'f':
                forceTime = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Deactivate\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Deactivate [-T] image_name [-f] force_time\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Deactivate to stop a virtual image or list of virtual images.\n"
                    "  The virtual image(s) will no longer be active on the system.\n\n"
                    "  The following option is required:\n"
                    "    -T    The name of the image being deactivated\n"
                        "  The following option is optional:\n"
                    "    -f    Specifies when the Image_Deactivate function is to take place. This \n"
                    "          must be inside double quotes because of spaces.\n"
                    "            IMMED: Immediate image deactivation\n"
                    "            WITHIN interval: Where interval is a number of seconds in the\n"
                    "                             the range 1-65535\n"
                    "            BY time: Where time is specified as hh:mm or hh:mm:ss\n"
                    "      Note: If unspecified, deactivation takes place according to the default\n"
                    "            signal timeout value set for the system\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Stopping %s... ", image);
    rc = smImage_Deactivate(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, forceTime, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Deactivate", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Deactivate", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDeleteDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int erase = -1;
    char * image = NULL;
    vmApiImageDeleteDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:e:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'e':
                erase = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Delete_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Delete_DM [-T] image_name [-e] erase\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Delete_DM to delete a virtual image's definition from the directory.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to be deleted\n"
                    "    -e    Indicates whether to erase data from the disk(s) being released:\n"
                    "            0: Unspecified (use installation default)\n"
                    "            1: Do not erase (override installation default)\n"
                    "            2: Erase (override installation default)\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || (erase < 0)) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting %s from the directory... ", image);
    rc = smImage_Delete_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, erase, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Delete_DM", rc, vmapiContextP);
    }  else if (output->common.returnCode == 592 && output->operationId) {
    	// Asynchronous operation started. By the time we query the async ID, it will be done, so do not bother.
    	printAndLogSmapiReturnCodeReasonCodeDescription("Image_Delete_DM", 0, 0, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Delete_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDeviceDedicate(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int readOnly = 0;
    char * image = NULL;
    char * virtualAddress = NULL;
    char * realDevice = NULL;
    vmApiImageDeviceDedicateOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:r:R:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualAddress = optarg;
                break;

            case 'r':
                realDevice = optarg;
                break;

            case 'R':
                readOnly = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Device_Dedicate\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Device_Dedicate [-T] image_name [-v] virtual_address\n"
                    "    [-r] real_device_number [-o] readonly\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Device_Dedicate to add a dedicated device to an active virtual\n"
                    "  image's configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image obtaining a dedicated device\n"
                    "    -v    The virtual device number of the device\n"
                    "    -r    A real device number to be dedicated or attached to the\n"
                    "          specified virtual image\n"
                    "    -R    Specify a 1 if the virtual device is to be in read-only\n"
                    "          mode. Otherwise, specify a 0\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !virtualAddress || !realDevice || (readOnly < 0) || (readOnly > 1)) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Dedicating device %s to %s's active configuration... ", realDevice, image);
    rc = smImage_Device_Dedicate(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualAddress, realDevice, readOnly, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Device_Dedicate", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Device_Dedicate", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDeviceDedicateDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int readOnly = 0;
    char * image = NULL;
    char * virtualDevice = NULL;
    char * realDevice = NULL;
    vmApiImageDeviceDedicateDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:r:R:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualDevice = optarg;
                break;

            case 'r':
                realDevice = optarg;
                break;

            case 'R':
                readOnly = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Device_Dedicate_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Device_Dedicate_DM [-T] image_name [-v] virtual_device_number\n"
                    "    [-r] real_device_number [-R] read_only\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Device_Dedicate_DM to add a dedicated device to a virtual\n"
                    "  image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image obtaining a dedicated device\n"
                    "    -v    The virtual device number of the device\n"
                    "    -r    A real device number to be dedicated or attached to the\n"
                    "          specified virtual image\n"
                    "    -R    Specify a 1 if the virtual device is to be in read-only mode.\n"
                    "          Otherwise, specify a 0.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !virtualDevice || !realDevice || (readOnly < 0) || (readOnly > 1)) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Dedicating device %s to %s's directory entry... ", realDevice, image);
    rc = smImage_Device_Dedicate_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualDevice, realDevice, readOnly, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Device_Dedicate_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Device_Dedicate_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDeviceReset(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * virtualDevice = NULL;
    vmApiImageDeviceResetOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualDevice = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Device_Reset\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Device_Reset [-T] image_name [-v] virtual_device\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Device_Reset to clear all pending interrupts from the specified\n"
                    "  virtual device.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name for which the device is being reset\n"
                    "    -v    The virtual device number of the device to reset\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !virtualDevice) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Clearing all pending interrupts from %s... ", virtualDevice);
    rc = smImage_Device_Reset(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualDevice, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Device_Reset", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Device_Reset", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDeviceUndedicate(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * virtualDevice = NULL;
    vmApiImageDeviceUndedicateOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualDevice = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Device_Undedicate\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Device_Undedicate [-T] image_name [-v] virtual_device\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Device_Undedicate to delete a dedicated device from an active\n"
                    "  virtual image's configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image from which a dedicated device is being\n"
                    "          removed\n"
                    "    -v    The virtual device number of the device to be deleted\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !virtualDevice) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting dedicated device from %s's active configuration... ", image);
    rc = smImage_Device_Undedicate(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualDevice, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Device_Undedicate", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Device_Undedicate", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDeviceUndedicateDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * virtualDevice = NULL;
    vmApiImageDeviceUndedicateDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualDevice = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Device_Undedicate_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Device_Undedicate_DM [-T] image_name [-v] virtual_device\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Device_Undedicate_DM to delete a dedicated device from a virtual\n"
                    "  image's directory entry\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image from which a dedicated device is being removed\n"
                    "    -v    The virtual device number of the device to be deleted\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !virtualDevice) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting dedicated device from %s's directory entry... ", image);
    rc = smImage_Device_Undedicate_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualDevice, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Device_Undedicate_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Device_Undedicate_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskCopy(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * virtualDevice = NULL;
    vmApiImageDiskCopyOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualDevice = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Copy\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Copy [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Copy to clone a disk in an active virtual image's configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name of the single image for which the disk is\n"
                    "          being copied\n"
                    "    -v    The virtual device address of the target disk for the copy\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !virtualDevice) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Cloning disk in %s's active configuration... ", image);
    rc = smImage_Disk_Copy(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualDevice, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Copy", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Copy", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskCopyDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * srcImage = NULL;
    char * srcDiskAddress = NULL;
    char * tgtDiskAddress = NULL;
    char * tgtImage = NULL;
    char * allocType = NULL;
    char * areaOrVolser = NULL;
    char * accessMode = NULL;
    char * readPass = "";
    char * writePass = "";
    char * multiPass = "";
    vmApiImageDiskCopyDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:t:S:s:a:n:m:r:w:x:h?")) != -1)
        switch (option) {
            case 'S':
                srcImage = optarg;
                break;

            case 's':
                srcDiskAddress = optarg;
                break;

            case 'T':
                tgtImage = optarg;
                break;

            case 't':
                tgtDiskAddress = optarg;
                break;

            case 'a':
                allocType = optarg;
                break;

            case 'n':
                areaOrVolser = optarg;
                break;

            case 'm':
                accessMode = optarg;
                break;

            case 'r':
                readPass = optarg;
                break;

            case 'w':
                writePass = optarg;
                break;

            case 'x':
                multiPass = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Copy_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Copy_DM [-T] image_name [-s] src_disk_address\n"
                    "    [-t] target_image [-u] target_disk_address [-a] alloc_type\n"
                    "    [-n] area_or_volser [-m] access_mode [-r] read_password\n"
                    "    [-w] write_password [-x] multi_password\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Copy_DM to clone a disk in a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name of the single image for which the disk is\n"
                    "          being copied\n"
                    "    -t    The virtual device address of the target disk for the copy\n"
                    "    -S    The name of the virtual image that owns the image disk being copied\n"
                    "    -s    The image disk number of the virtual image that owns the disk\n"
                    "          being copied\n"
                    "    -a    Disk allocation type:\n"
                    "            The starting location\n"
                    "            AUTOG: Automatic_Group_Allocation\n"
                    "            AUTOR: Automatic_Region_Allocation\n"
                    "            AUTOV: Automatic_Volume_Allocation\n"
                    "            DEVNO: Full Volume Minidisk\n"
                    "    -n    Allocation area name or volser\n"
                    "    -m    The access mode requested for the disk:\n"
                    "            R: Read-only (R/O) access\n"
                    "            RR: Read-only (R/O) access\n"
                    "            W: Write access\n"
                    "            WR: Write access\n"
                    "            M: Multiple access\n"
                    "            MR: Write or any exclusive access\n"
                    "            MW: Write access is allowed to the disk unconditionally\n"
                    "  The following options are optional:\n"
                    "    -r    Defines the read password that will be used for accessing the disk\n"
                    "    -w    Defines the write password that will be used for accessing the disk\n"
                    "    -x    Defines the multi password that will be used for accessing the disk\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!srcImage || !srcDiskAddress || !tgtDiskAddress || !tgtImage || !allocType || !areaOrVolser || !accessMode) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Cloning disk in %s's directory entry... ", srcImage);
    rc = smImage_Disk_Copy_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            tgtImage, tgtDiskAddress, srcImage, srcDiskAddress, allocType, areaOrVolser, accessMode,
            readPass, writePass, multiPass, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Copy_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Copy_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskCreate(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char* image = NULL;
    char* deviceAddr = NULL;
    char* accessMode = NULL;
    vmApiImageDiskCreateOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:m:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                deviceAddr = optarg;
                break;

            case 'm':
                accessMode = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Create\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Create [-T] image_name [-v] virtual_address [-m] access_mode\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Create to add a disk that is defined in a virtual image's\n"
                    "  directory entry to that virtual image's active configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name of the single image for which the disk\n"
                    "          is being created.\n"
                    "    -v    The virtual device address of the disk to be added\n"
                    "    -m    The access mode requested for the disk\n"
                    "            R: Read-only (R/O) access\n"
                    "            RR: Read-only (R/O) access\n"
                    "            W: Write access\n"
                    "            WR: Write access\n"
                    "            M: Multiple access\n"
                    "            MR: Write or any exclusive access\n"
                    "            MW: Write access is allowed to the disk unconditionally\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !deviceAddr || !accessMode) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Adding disk to %s's active configuration... ", image);
    rc = smImage_Disk_Create(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, deviceAddr, accessMode, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Create", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Create", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskCreateDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char* image = NULL;
    char* deviceAddr = "";
    char* deviceType = "";
    char* allocType = "";
    char* allocName = "";
    int allocSize = 0;
    int diskSize = 0;
    char* accessMode = "";
    int diskFormat = 0;
    char* diskLabel = "";
    char* readPass = "";
    char* writePass = "";
    char* multiPass = "";
    vmApiImageDiskCreateDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:t:a:r:u:z:m:f:l:R:W:M:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;
            case 'v':
                deviceAddr = optarg;
                break;
            case 't':
                deviceType = optarg;
                break;
            case 'a':
                allocType = optarg;
                break;
            case 'r':
                allocName = optarg;
                break;
            case 'u':
                allocSize = atoi(optarg);
                break;
            case 'z':
                diskSize = atoi(optarg);
                break;
            case 'm':
                accessMode = optarg;
                break;
            case 'f':
                diskFormat = atoi(optarg);
                break;
            case 'l':
                diskLabel = optarg;
                break;
            case 'R':
                readPass = optarg;
                break;
            case 'W':
                writePass = optarg;
                break;
            case 'M':
                multiPass = optarg;
                break;
            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Create_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Create_DM [-T] image_name [-v] virtual_address\n"
                    "    [-t] device_type [-a] allocation_type [-r] area_name_or_volser\n"
                    "    [-u] unit_size [-z] disk_size [-m] access_mode\n"
                    "    [-f] disk_format [-l] disk_label [-R] read_password\n"
                    "    [-W] write_password [-M] multi_password\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Create_DM to add a disk to a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name of the single image for which the disk\n"
                    "          is being created\n"
                    "    -v    The virtual device address of the disk to be added\n"
                    "    -t    The device type of the volume to which the disk is assigned\n"
                    "    -a    Allocation type:\n"
                    "            AUTOG: Automatic_Group_Allocation\n"
                    "            AUTOR: Automatic_Region_Allocation\n"
                    "            AUTOV: Automatic_Volume_Allocation\n"
                    "            DEVNO: Full Volume Minidisk\n"
                    "            T-DISK: Automatic Temporary Disk\n"
                    "            V-DISK: Automatic Virtual Disk\n"
                    "              In this case, image_disk_device_type must have value = FB-512\n"
                    "    -r    Allocation area name or volser:\n"
                    "            - The group or region where the new image disk is to be created.\n"
                    "              This is specified when allocationtype is AUTOG or AUTOR.\n"
                    "            - The label of the DASD volume where the new image disk is to\n"
                    "              be created. This is specified when allocation type is the\n"
                    "              starting location or AUTOV.\n"
                    "            - The device address of the full volume minidisk where the new\n"
                    "              image disk is to be created. This is specified when allocation\n"
                    "              type is DEVNO.\n"
                    "    -u    Unit size:\n"
                    "            1: CYLINDERS\n"
                    "            2: BLK0512\n"
                    "            3: BLK1024\n"
                    "            4: BLK2048\n"
                    "            5: BLK4096\n"
                    "    -z    The size of the disk to be created:\n"
                    "            - Cylinders, if the allocation_unit_size is CYLINDERS\n"
                    "            - Logical disk blocks of size nnnn if allocation_unit_size is\n"
                    "              BLKnnnn. nnnn is either 512 (or 0512), 1024, 2048, or 4096.\n"
                    "    -m    The access mode requested for the disk:\n"
                    "            R: Read-only (R/O) access\n"
                    "            RR: Read-only (R/O) access\n"
                    "            W: Write access\n"
                    "            WR: Write access\n"
                    "            M: Multiple access\n"
                    "            MR: Write or any exclusive access\n"
                    "            MW: Write access is allowed to the disk unconditionally\n"
                    "    -f    Disk format:\n"
                    "            0: Unspecified\n"
                    "            1: Unformatted\n"
                    "            2: CMS formatted with 512 bytes per block\n"
                    "            3: CMS formatted with 1024 bytes per block\n"
                    "            4: CMS formatted with 2048 bytes per block\n"
                    "            5: CMS formatted with 4096 bytes per block\n"
                    "            6: CMS formatted with the default block size for the allocated\n"
                    "               device type\n"
                    "  The following options are optional:\n"
                    "    -l    The disk label to use when formatting the new extent\n"
                    "    -R    Read password\n"
                    "    -W    Write password\n"
                    "    -M    Multi password\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !deviceAddr || !deviceType || !allocType || !allocName || !allocSize || !diskSize || !accessMode) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Adding a disk to %s's directory entry... ", image);
    rc = smImage_Disk_Create_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, deviceAddr, deviceType, allocType, allocName, allocSize,
            diskSize, accessMode, diskFormat, diskLabel,
            readPass, writePass, multiPass,  // Read, write, and multi passwords
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Create_DM", rc, vmapiContextP);
    } else if (output->common.returnCode == 592 && output->operationId) {
        queryAsyncOperation(image, output->operationId);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Create_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskDelete(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = NULL;
    vmApiImageDiskDeleteOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Delete\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Delete [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Delete to delete a disk from an active virtual image's\n"
                    "  configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image for which the disk is being deleted\n"
                    "    -v    The virtual device address of the disk to be deleted\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !address) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting disk from %s's configuration... ", image);
    rc = smImage_Disk_Delete(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, address, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Delete", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Delete", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskDeleteDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int securityErase = -1;
    char * image = NULL;
    char * virtualAddress = NULL;
    vmApiImageDiskDeleteDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:e:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                virtualAddress = optarg;
                break;

            case 'e':
                securityErase = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Delete_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Delete_DM [-T] image_name [-v] virtual_address\n"
                    "    [-e] security_erase\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Delete_DM to delete a disk from a virtual image's directory\n"
                    "  entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    Target image or authorization entry name\n"
                    "    -v    The virtual device address of the disk to be deleted.\n"
                    "    -e    Indicates whether to erase data from the disk(s) being released:\n"
                    "            0: Unspecified (use installation default)\n"
                    "            1: Do not erase (override installation default)\n"
                    "            2: Erase (override installation default)\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }


    if (!image || !virtualAddress || (securityErase < 0)) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting a disk from %s's directory entry... ", image);
    rc = smImage_Disk_Delete_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, virtualAddress, securityErase, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Delete_DM", rc, vmapiContextP);
    } else if (output->common.returnCode == 592 && output->operationId) {
        queryAsyncOperation(image, output->operationId);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Delete_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    // Parse the command-line arguments
    int option;
    int rc;
    char * image = NULL;
    int entryCount = 0;
    int argBytes = 0;
    int i;
    int arrayBytes = 0;
    char ** entryArray;
    const char * optString = "-T:k:h?";
    vmApiImageDiskQueryOutput* output;

    // Count up the max number of arguments to create the array
    while ((option = getopt(argC, argV, optString)) != -1) {
        arrayBytes = arrayBytes + sizeof(*entryArray);
    }
    optind = 1;  // Reset optind so getopt can rescan arguments
    if (arrayBytes > 0) {
        entryArray = malloc(arrayBytes);
    }

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, optString)) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;
            case 'k':
                if (!optarg) {
                    FREE_MEMORY_CLEAR_POINTER(entryArray);
                    return INVALID_DATA;
                }
                entryArray[entryCount] = optarg;
                entryCount++;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Query [-T] image_name\n"
                    "    [-k] 'vdasd_id=value' \n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Query to display the status of all DASDs \n"
                    "    accessible to a virtual image, including temporary disks and virtual disks\n"
                    "    in storage.\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual machine being created.\n"
                    "    -k    A quoted 'vdasd_id=value'\n"
                    "          The value is a virtual device number, or ALL \n");
                 FREE_MEMORY_CLEAR_POINTER(entryArray);
                 return 1;
                 break;

            case '?':  // Missing option data!
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
     }
     if (!image || !entryCount) {
       printf("\nERROR: Missing required options\n");
       FREE_MEMORY_CLEAR_POINTER(entryArray);
       return 1;
    }

    rc = smImage_Disk_Query(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
         image, entryCount, entryArray, &output);
    FREE_MEMORY_CLEAR_POINTER(entryArray);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Query", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        char * accessType;
        char * dasdUnit;
        for (i = 0; i < output->dasdCount; i++) {
            if (output->dasdList[i].accessType == 1) {
                accessType = "R/O";
            } else {
                accessType = "R/W";
            }
            if (output->dasdList[i].cylOrBlocks == 1) {
                dasdUnit = "Cylinders";
            } else {
                dasdUnit = "Blocks";
            }
            printf("DASD VDEV: %s\n"
                    "  RDEV: %s\n"
                    "  Access type: %s\n"
                    "  Device type: %s\n"
                    "  Device size: %ul\n"
                    "  Device units: %s\n"
                    "  Device volume label: %s\n\n",
                    output->dasdList[i].vdev, output->dasdList[i].rdev, accessType, output->dasdList[i].devtype,
                    output->dasdList[i].devtype, output->dasdList[i].size, dasdUnit, output->dasdList[i].volid);
        }
    }
    return rc;
}

int imageDiskShare(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = NULL;
    char * tgtImage = NULL;
    char * tgtAddress = NULL;
    char * accessMode = NULL;
    char * password = "";
    vmApiImageDiskShareOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:t:r:a:p:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 't':
                tgtImage = optarg;
                break;

            case 'r':
                tgtAddress = optarg;
                break;

            case 'a':
                accessMode = optarg;
                break;

            case 'p':
                password = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Share\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Share [-T] image_name [-v] virtual_address [-t] target_image\n"
                    "    [-r] target_address [-a] access_mode [-p] password\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Share to add a disk that is defined in a virtual\n"
                    "  image's directory entry to a different active virtual image's\n"
                    "  configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the single image attempting to share the disk\n"
                    "    -v    The virtual device address of the disk to be shared\n"
                    "    -t    The name of the virtual image that owns the image disk\n"
                    "          being shared\n"
                    "    -r    The virtual device number to assign to the shared disk\n"
                    "    -a    The access mode requested for the disk:\n"
                    "            R: Read-only (R/O) access\n"
                    "            RR: Read-only (R/O) access\n"
                    "            W: Write access\n"
                    "            WR: Write access\n"
                    "            M: Multiple access\n"
                    "            MR: Write or any exclusive access\n"
                    "            MW: Write access is allowed to the disk unconditionally\n"
                    "  The following options are optional:\n"
                    "    -p    The password that may be required to share the disk\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !address || !tgtImage || !tgtAddress || !accessMode) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Adding disk in %s's directory entry to %s's active configuration... ", image, tgtImage);
    rc = smImage_Disk_Share(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, address, tgtImage, tgtAddress, accessMode, password, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Share", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Share", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskShareDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = NULL;
    char * tgtImage = NULL;
    char * tgtAddress = NULL;
    char * accessMode = NULL;
    char * password = NULL;
    vmApiImageDiskShareDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:t:r:a:p:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 't':
                tgtImage = optarg;
                break;

            case 'r':
                tgtAddress = optarg;
                break;

            case 'a':
                accessMode = optarg;
                break;

            case 'p':
                password = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Share_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Share_DM [-T] image_name [-v] virtual_address\n"
                    "    [-t] target_image [-r] target_address [-a] access_mode\n"
                    "    [-p] password\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Share_DM to add a disk that is defined in a virtual\n"
                    "  image's directory entry to a different virtual image's directory entry\n\n"
                    "    -T    The name of the single image attempting to share the disk\n"
                    "    -v    The virtual device address of the disk to be shared\n"
                    "    -t    The name of the virtual image that owns the image disk\n"
                    "          being shared\n"
                    "    -r    The virtual device number to assign to the shared disk\n"
                    "    -a    The access mode requested for the disk:\n"
                    "            R: Read-only (R/O) access\n"
                    "            RR: Read-only (R/O) access\n"
                    "            W: Write access\n"
                    "            WR: Write access\n"
                    "            M: Multiple access\n"
                    "            MR: Write or any exclusive access\n"
                    "            MW: Write access is allowed to the disk unconditionally\n"
                    "    -p    The password that may be required to share the disk\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !address || !tgtImage || !tgtAddress || !accessMode || !password) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Adding disk in %s's directory entry to %s's directory entry... ", image, tgtImage);
    rc = smImage_Disk_Share_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, address, tgtImage, tgtAddress, accessMode, password, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Share_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Share_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskUnshare(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = NULL;
    vmApiImageDiskUnshareOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Unshare\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Unshare [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Unshare to delete a shared disk from an active\n"
                    "  virtual image's configuration.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image from which the previously-shared\n"
                    "          disk is to be removed from the configuration\n"
                    "    -v    The virtual device address of the previously-shared\n"
                    "          disk to be removed from the configuration\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !address) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting shared disk from %s's configuration... ", image);
    rc = smImage_Disk_Unshare(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, address, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Unshare", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Unshare", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageDiskUnshareDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = NULL;
    char * tgtImage = NULL;
    char * tgtAddress = NULL;
    vmApiImageDiskUnshareDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:t:r:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 't':
                tgtImage = optarg;
                break;

            case 'r':
                tgtAddress = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Disk_Unshare_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Disk_Unshare_DM [-T] image_name [-v] virtual_address\n"
                    "    [-t] target_image [-r] target_virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Disk_Unshare_DM to delete a shared disk from a virtual\n"
                    "  image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image from which the previously-shared\n"
                    "          disk is to be removed from the configuration\n"
                    "    -v    The virtual device address of the previously-shared\n"
                    "          disk to be removed from the configuration\n"
                    "    -t    The name of the virtual image that owns the previously-shared\n"
                    "          disk to be removed from the configuration\n"
                    "    -r    The virtual device number previously assigned to the shared\n"
                    "          disk\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !address || !tgtImage || !tgtAddress) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting shared disk from %s's directory entry... ", image);
    rc = smImage_Disk_Unshare_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, address, tgtImage, tgtAddress, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Disk_Unshare_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Disk_Unshare_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageIPLDeleteDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageIplDeleteDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_IPL_Delete_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_IPL_Delete_DM [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_IPL_Delete_DM to delete the IPL statement from a virtual\n"
                    "  image's directory entry or a profile directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    Specifies the name of the user or profile for which the IPL\n"
                    "          statement is to be deleted\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting IPL statement from %s's directory entry... ", image);
    rc = smImage_IPL_Delete_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_IPL_Delete_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_IPL_Delete_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageIPLQueryDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageIplQueryDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_IPL_Query_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_IPL_Query_DM [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_IPL_Query_DM to query the information about the operating\n"
                    "  system, or device containing the operating system, that is specified\n"
                    "  on the IPL statement in a virtual image's directory entry or a\n"
                    "  profile directory entry. This operating system is automatically\n"
                    "  loaded and started when the virtual image is activated.\n\n"
                    "  The following options are required:\n"
                    "    -T    Specifies the name of the user or profile for which the IPL\n"
                    "          statement is to be queried\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_IPL_Query_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_IPL_Query_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_IPL_Query_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        printf("IPL: %s\n"
            "Load parameter: %s\n"
            "Parameters: %s\n", output->savedSystem, output->loadParameter,
                output->parameters);
    }
    return rc;
}

int imageIPLSetDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * savedSystem = "";
    char * loadParameter = "";
    char * parameter = "";
    vmApiImageIplSetDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:s:l:p:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 's':
                savedSystem = optarg;
                break;

            case 'l':
                loadParameter = optarg;
                break;

            case 'p':
                parameter = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_IPL_Set_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_IPL_Set_DM [-T] image_name [-s] saved_system\n"
                    "    [-l] load_parameter [-p] parameter\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_IPL_Set_DM to add an IPL statement to a virtual image's\n"
                    "  directory entry or a profile directory entry. The IPL statement\n"
                    "  identifies an operating system, or a device containing an operating\n"
                    "  system, which is automatically loaded and started when the virtual\n"
                    "  image is activated.\n\n"
                    "  The following options are required:\n"
                    "    -T    Specifies the name of the user or profile for which the\n"
                    "          IPL statement is to be set.\n"
                    "    -s    Specifies the name of the saved system or virtual device\n"
                    "          address of the device containing the system to be loaded.\n"
                    "    -l    Specifies the load parameter (up to 8 characters) that is\n"
                    "          used by the IPL'd system. It may be necessary to enclose\n"
                    "          the load parameter in single quotes.\n"
                    "    -p    Specifies the parameters to be passed to the IPL'd operating\n"
                    "          system. Although the IPL command allows for 64 bytes of\n"
                    "          parameters, the string on the directory statement is limited\n"
                    "          to the number of characters that can be specified in the first\n"
                    "          72 positions of the statement.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Adding IPL statement to %s's directory entry... ", image);
    rc = smImage_IPL_Set_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, savedSystem, loadParameter, parameter, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_IPL_Set_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_IPL_Set_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageLockDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = "";
    vmApiImageLockDmOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Lock_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Lock_DM [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Lock_DM to lock a virtual image's directory entry or a specific\n"
                    "  device in a virtual image's directory entry so that it cannot be changed.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to be locked.\n"
                    "  The following options are optional:\n"
                    "    -v    The virtual address of the device being locked.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Locking virtual image's directory entry %s... ", image);
    rc = smImage_Lock_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, address,  // Image name, device virtual address
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Lock_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Lock_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageNameQueryDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    vmApiImageNameQueryDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "h?")) != -1)
        switch (option) {
            case 'h':
                printf("NAME\n"
                    "  Image_Name_Query_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Name_Query_DM\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Name_Query_DM to obtain a list of defined virtual images.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    rc = smImage_Name_Query_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            "FOOBAR",  // Does not matter what image name is used
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Name_Query_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Name_Query_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out image names
        int i;
        int n = output->nameCount;
        for (i = 0; i < n; i++) {
            printf("%s\n", output->nameList[i]);
        }
    }
    return rc;
}

int imagePasswordSetDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * password = "";
    vmApiImagePasswordSetDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:p:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'p':
                password = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Password_Set_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Password_Set_DM [-T] image_name [-p] password\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Password_Set_DM to set or change a virtual image's password.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image for which the password is being set\n"
                    "    -p    The password or passphrase to set for the image\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !password) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Setting %s's password... ", image);
    rc = smImage_Password_Set_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, strlen(password), password, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Password_Set_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Password_Set_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageQueryActivateTime(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int format = 0;
    char * image = NULL;
    vmApiImageQueryActivateTimeOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'f':
                format = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Query_Activate_Time\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Query_Activate_Time [-T] image_name [-f] format\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Query_Activate_Time to obtain the date and time when a virtual\n"
                    "  image was activated.\n\n"
                    "  The following options are required:\n"
                    "    -T    To specify which virtual image's activation date and time is\n"
                    "          being queried\n"
                    "    -f    The format of the date stamp that is returned:\n"
                    "            1: mm/dd/yy\n"
                    "            2: mm/dd/yyyy\n"
                    "            3: yy-mm-dd\n"
                    "            4: yyyy-mm-dd\n"
                    "            5: dd/mm/yy\n"
                    "            6: dd/mm/yyyy\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !format) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_Query_Activate_Time(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, format, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Query_Activate_Time", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Query_Activate_Time", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        char * image = output->imageName;
        char * actDate = output->activationDate;
        char * actTime = output->activationTime;
        printf("%s was activated on %s at %s\n", image, actDate, actTime);
    }
    return rc;
}

/**
 * Use Image_Query_DM to obtain a virtual image's directory entry
 */
int imageQueryDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int i;
    int option;
    char * image = NULL;
    vmApiImageQueryDmOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Query_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Query_DM [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Query_DM to obtain a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image being queried\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_Query_DM(vmapiContextP, "", 0, "", image, &output, false);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Query_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Query_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out directory entry
        int recCount = output->imageRecordCount;
        int recLen = output->imageRecordList[0].imageRecordLength - 8;
        char line[recLen], chs[4];
        if (recCount > 0) {
            for (i = 0; i < recCount; i++) {
                memset(line, 0, recLen);
                memcpy(line, output->imageRecordList[i].imageRecord, recLen);
                trim(line);
                printf("%s\n", line);
            }
        }
    }
    return rc;
}

int imageRecycle(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageRecycleOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Recycle\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Recycle [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Recycle to deactivate and then reactivate a virtual image or\n"
                    "  list of virtual images.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image being recycled\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Recycling %s... ", image);
    rc = smImage_Recycle(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Recycle", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Recycle", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageReplaceDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    // IMPORTANT: Image must be locked before it can be replaced
    int rc;
    int option;
    char * image = NULL;
    char * userEntryFile = NULL;
    int userEntryStdin = 0;

    FILE * fp;
    int recordCount = 0;
    int c;
    char * ptr;

    int i = 0, LINE_SIZE = 72;
    char buffer[100][LINE_SIZE];

    vmApiImageReplaceDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:sh?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;
            case 'f':
                userEntryFile = optarg;
                break;
            case 's':
                userEntryStdin = 1;
                break;
            case 'h':
                printf("NAME\n"
                    "  Image_Replace_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Replace_DM [-T] image_name [-f] user_entry_file\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Replace_DM to replace a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to be replaced\n"
                    "    -f    The file containing the updated directory entry. Not required\n"
                    "          if a directory entry is provided from stdin.\n"
                    "    -s    Read the updated directory entry from stdin. Not required if a\n"
                    "          directory entry file is provided.\n");
                return 1;
                break;
            case '?':  // Missing option data!
                return 1;
                  break;
            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || (!userEntryFile && !userEntryStdin)) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    if (!userEntryStdin) {
        // Open the user entry file
        fp = fopen(userEntryFile, "r");
        if (NULL == fp) {
            printf("\nERROR: Failed to open file %s\n", userEntryFile);
            return 2;
        }

        // Count the number of lines and set the record count to it
        while ((c = fgetc(fp)) != EOF) {
            if (c == '\n') {
                recordCount++;
            }
        }

        // Reset position to start of file
        rewind(fp);
    } else {
        // Read in user entry from stdin
        while (fgets(buffer[i], LINE_SIZE, stdin) != NULL) {
            // Replace newline with null terminator
            ptr = strstr(buffer[i], "\n");
            if (ptr != NULL) {
                strncpy(ptr, "\0", 1);
                // Count the number of lines and set the record count to it
                recordCount++;
            }
            i++;
        }
    }

    // Create image record
    vmApiImageRecord record[recordCount];
    char line[recordCount][LINE_SIZE];
    if (!userEntryStdin) {
        // Read in user entry from file
        while (fgets(line[i], LINE_SIZE, fp) != NULL) {
            // Replace newline with null terminator
            ptr = strstr(line[i], "\n");
            if (ptr != NULL) {
                strncpy(ptr, "\0", 1);
            }
            record[i].imageRecordLength = strlen(line[i]);
            record[i].imageRecord = line[i];
            i++;
        }

        // Close file
        fclose(fp);
    } else {
        // Read in user entry from stdin buffer
        for (i = 0; i < recordCount; i++) {
            record[i].imageRecordLength = strlen(buffer[i]);
            record[i].imageRecord = buffer[i];
        }
    }

    printf("Replacing %s's directory entry... ", image);
    rc = smImage_Replace_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, recordCount,    (vmApiImageRecord *) record,  // Image record
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Replace_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Replace_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageSCSICharacteristicsDefineDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * bootProgram = NULL;
    char * logicalBlock = NULL;
    char * lun = NULL;
    char * portName = NULL;
    int scpType = -1;
    char * scpData = NULL;
    vmApiImageScsiCharacteristicsDefineDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:b:k:l:p:s:d:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'b':
                bootProgram = optarg;
                break;

            case 'k':
                logicalBlock = optarg;
                break;

            case 'l':
                lun = optarg;
                break;

            case 'p':
                portName = optarg;
                break;

            case 's':
                scpType = atoi(optarg);
                break;

            case 'd':
                scpData = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_SCSI_Characteristics_Define_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_SCSI_Characteristics_Define_DM [-T] image_name\n"
                    "    [-b] boot_program [-k] logical_block [-l] lun [-p] port_name\n"
                    "    [-s] scp_data_type [-d] scp_data\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_SCSI_Characteristics_Define_DM to define or change the\n"
                    "  location of a program to be loaded as a result of an FCP\n"
                    "  list-directed IPL, and the data to be passed to the loaded program,\n"
                    "  in a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The target image name whose LOADDEV is being set\n"
                    "    -b    The boot program number (which must be a value in the range\n"
                    "          0 to 30), or the keyword 'DELETE' to delete the existing\n"
                    "          boot program number. If null, the boot program number will\n"
                    "          be unchanged\n"
                    "    -k    The logical-block address of the boot record, or the keyword\n"
                    "          'DELETE' to delete the existing logical-block address. If\n"
                    "          null, the logical-block address will be unchanged\n"
                    "    -l    The logical unit number, or the keyword 'DELETE' to delete\n"
                    "          the existing logical unit number. If null, the logical unit\n"
                    "          number will be unchanged\n"
                    "    -p    The port name, or the keyword 'DELETE' to delete the existing\n"
                    "          port name. If null, the port name will be unchanged\n"
                    "    -s    The type of data specified in the SCP_data parameter, as\n"
                    "          follows:\n"
                    "            0: Unspecified\n"
                    "            1: DELETE – delete the SCP_data for the image\n"
                    "            2: EBCDIC – EBCDIC (codepage 924) data\n"
                    "            3: HEX – UTF-8 encoded hex data\n"
                    "    -d    The SCP data\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !bootProgram || !logicalBlock || !lun || !portName || (scpType < 0) || !scpData) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Defining location of program to be loaded... ");
    rc = smImage_SCSI_Characteristics_Define_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, bootProgram, logicalBlock, lun, portName, scpType, strlen(scpData), scpData, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_SCSI_Characteristics_Define_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_SCSI_Characteristics_Define_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageSCSICharacteristicsQueryDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageScsiCharacteristicsQueryDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_SCSI_Characteristics_Query_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_SCSI_Characteristics_Query_DM [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_SCSI_Characteristics_Query_DM to obtain the location of a program\n"
                    "  to be loaded as a result of an FCP list-directed IPL, and the data to be\n"
                    "  passed to the loaded program, from a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The target userid whose LOADDEV is being queried\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_SCSI_Characteristics_Query_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_SCSI_Characteristics_Query_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_SCSI_Characteristics_Query_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        char * bootProgram = output->bootProgramNumber;
        char * logicalBlock = output->br_LBA;
        char * lun = output->lun;
        char * portName = output->port;
        char * scpData = output->scpData;

        printf("Boot program number: %s\n"
            "Logical-block address of the boot record: %s\n"
            "Logical unit number: %s\n"
            "Port name: %s\n"
            "Type of data: %s\n", bootProgram, logicalBlock, lun, portName, scpData);
    }
    return rc;
}

int imageStatusQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    vmApiImageStatusQueryOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Status_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Status_Query [-T] image_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Status_Query to determine whether virtual images are\n"
                    "  active (logged on or logged on disconnected) or inactive.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image being queried\n"
                    "          You may enter '*' to get the list of all active servers\n ");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_Status_Query(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Status_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Status_Query", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out directory entry
        int imageCount = output->imageNameCount;
        if (imageCount > 0) {
            int i;
            for (i = 0; i < imageCount; i++) {
                printf("%s\n", output->imageNameList[i].imageName);
            }
        }
    }

    return rc;
}

int imageUnlockDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = "";
    vmApiImageUnlockDmOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Unlock_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Unlock_DM [-T] image_name [-v] virtual_address\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Unlock_DM to unlock a virtual image's directory entry\n"
                    "  or a specific device in a virtual image's directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to be unlocked\n"
                    "  The following options are optional:\n"
                    "    -v    The virtual address of the device being unlocked\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    if (strlen(address) == 0) {
        printf("Unlocking %s's directory entry... ", image);
    } else {
        printf("Unlocking %s's device %s... ", image, address);
    }
    rc = smImage_Unlock_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, address,  // Image name, device virtual address
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Unlock_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Unlock_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int imageVolumeAdd(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = "";
    char * volId = "";
    char * sysConfName = "";
    char * sysConfType = "";
    char * parmDiskOwner = "";
    char * parmDiskNumber = "";
    char * parmDiskPass = "";
    char * altSysConfName = "";
    char * altSysConfType = "";
    char * altParmDiskNumber = "";
    char * altParmDiskOwner = "";
    char * altParmDiskPass = "";
    vmApiImageVolumeAddOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:l:s:t:o:p:w:c:y:n:m:x:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 'l':
                volId = optarg;
                break;

            case 's':
                sysConfName = optarg;
                break;

            case 't':
                sysConfType = optarg;
                break;

            case 'o':
                parmDiskOwner = optarg;
                break;

            case 'p':
                parmDiskNumber = optarg;
                break;

            case 'w':
                parmDiskPass = optarg;
                break;

            case 'c':
                altSysConfName = optarg;
                break;

            case 'y':
                altSysConfType = optarg;
                break;

            case 'n':
                altParmDiskOwner = optarg;
                break;

            case 'm':
                altParmDiskNumber = optarg;
                break;

            case 'x':
                altParmDiskPass = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Add\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Add [-T] image_name [-v] virtual_address\n"
                    "    [-l] volid [-s] sys_conf_name [-t] sys_conf_type [-o] parm_disk_owner\n"
                    "    [-p] parm_disk_number [-w] parm_disk_password [-c] alt_sys_conf_name\n"
                    "    [-y] alt_sys_conf_type [-n] alt_parm_disk_owner [-m] alt_parm_disk_number\n"
                    "    [-x] alt_parm_disk_password\n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Add to add a DASD volume to be used by virtual images\n"
                    "  to the z/VM system configuration file.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to which a volume is being added\n"
                    "    -v    The virtual device number of the device\n"
                    "    -l    The DASD volume label\n"
                    "    -s    File name of system configuration file. The default is 'SYSTEM'.\n"
                    "    -t    File type of system configuration file. The default is 'CONFIG'.\n"
                    "    -o    Owner of the parm disk. The default is 'MAINT''."
                    "    -p    Number of the parm disk as defined in the VSMWORK1 directory\n"
                    "    -w    Multiwrite password for the parm disk. The default is ','.\n"
                    "    -c    File name of the second, or alternative, system configuration file\n"
                    "    -y    File type of the second, or alternative, system configuration file.\n"
                    "          The default is 'CONFIG'.\n"
                    "    -n    Owner of the second, or alternative, parm disk.\n"
                    "          The default is 'MAINT'.\n"
                    "    -m    Number of the second, or alternative, parm disk.\n"
                    "          The default is 'CF2'.\n"
                    "    -x    Multiwrite password for the alternate parm disk.\n"
                    "          The default is ','.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !address || !volId || !sysConfName || !sysConfType || !parmDiskOwner || !parmDiskNumber
            || !parmDiskPass || !altSysConfName || !altSysConfType || !altParmDiskOwner || !altParmDiskNumber
            || !altParmDiskPass) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Adding DASD volume to the z/VM system configuration... ");
    rc = smImage_Volume_Add(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, address, volId, sysConfName, sysConfType, parmDiskOwner, parmDiskNumber, parmDiskPass,
            altSysConfName, altSysConfType, altParmDiskOwner, altParmDiskNumber, altParmDiskPass, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Volume_Add", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Volume_Add", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }

    return rc;
}

int imageVolumeDelete(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * address = "";
    char * volId = "";
    char * sysConfName = "";
    char * sysConfType = "";
    char * parmDiskOwner = "";
    char * parmDiskNumber = "";
    char * parmDiskPass = "";
    char * altSysConfName = "";
    char * altSysConfType = "";
    char * altParmDiskNumber = "";
    char * altParmDiskOwner = "";
    char * altParmDiskPass = "";
    vmApiImageVolumeDeleteOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:v:l:s:t:o:p:w:c:y:n:m:x:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'v':
                address = optarg;
                break;

            case 'l':
                volId = optarg;
                break;

            case 's':
                sysConfName = optarg;
                break;

            case 't':
                sysConfType = optarg;
                break;

            case 'o':
                parmDiskOwner = optarg;
                break;

            case 'p':
                parmDiskNumber = optarg;
                break;

            case 'w':
                parmDiskPass = optarg;
                break;

            case 'c':
                altSysConfName = optarg;
                break;

            case 'y':
                altSysConfType = optarg;
                break;

            case 'n':
                altParmDiskOwner = optarg;
                break;

            case 'm':
                altParmDiskNumber = optarg;
                break;

            case 'x':
                altParmDiskPass = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Delete\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Delete [-T] image_name [-v] virtual_address\n"
                    "    [-l] volid [-s] sys_conf_name [-t] sys_conf_type [-o] parm_disk_owner\n"
                    "    [-p] parm_disk_number [-w] parm_disk_password [-c] alt_sys_conf_name\n"
                    "    [-y] alt_sys_conf_type [-n] alt_parm_disk_owner [-m] alt_parm_disk_number\n"
                    "    [-x] alt_parm_disk_password\n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Delete to delete a DASD volume definition from the z/VM\n"
                    "  system configuration file.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image being activated\n"
                    "    -v    The virtual device number of the device\n"
                    "    -l    The DASD volume label\n"
                    "    -s    File name of system configuration file. The default is 'SYSTEM'.\n"
                    "    -t    File type of system configuration file. The default is 'CONFIG'.\n"
                    "    -o    Owner of the parm disk. The default is 'MAINT''."
                    "    -p    Number of the parm disk as defined in the VSMWORK1 directory\n"
                    "    -w    Multiwrite password for the parm disk. The default is ','.\n"
                    "    -c    File name of the second, or alternative, system configuration file\n"
                    "    -y    File type of the second, or alternative, system configuration file.\n"
                    "          The default is 'CONFIG'.\n"
                    "    -n    Owner of the second, or alternative, parm disk.\n"
                    "          The default is 'MAINT'.\n"
                    "    -m    Number of the second, or alternative, parm disk.\n"
                    "          The default is 'CF2'.\n"
                    "    -x    Multiwrite password for the alternate parm disk.\n"
                    "          The default is ','.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !address || !volId || !sysConfName || !sysConfType || !parmDiskOwner || !parmDiskNumber
            || !parmDiskPass || !altSysConfName || !altSysConfType || !altParmDiskOwner || !altParmDiskNumber
            || !altParmDiskPass) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting DASD volume definition from the z/VM system configuration... ");
    rc = smImage_Volume_Delete(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, address, volId, sysConfName, sysConfType, parmDiskOwner, parmDiskNumber, parmDiskPass,
            altSysConfName, altSysConfType, altParmDiskOwner, altParmDiskNumber, altParmDiskPass, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Volume_Delete", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Volume_Delete", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }

    return rc;
}

int imageVolumeShare(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    // Parse the command-line arguments
    int option;
    int rc;
    char * image = NULL;
    int entryCount = 0;
    int argBytes = 0;
    int i;
    int arrayBytes = 0;
    int foundRequiredParm = 0;
    char ** entryArray;
    const char * optString = "-T:k:h?";
    vmApiImageVolumeShareOutput* output;

    // Count up the max number of arguments to create the array
    while ((option = getopt(argC, argV, optString)) != -1) {
        arrayBytes = arrayBytes + sizeof(*entryArray);
    }
    optind = 1;  // Reset optind so getopt can rescan arguments
    if (arrayBytes > 0) {
        entryArray = malloc(arrayBytes);
    }

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, optString)) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;
            case 'k':
                if (!optarg) {
                    FREE_MEMORY_CLEAR_POINTER(entryArray);
                    return INVALID_DATA;
                }
                entryArray[entryCount] = optarg;
                entryCount++;
                if (strstr(optarg, "img_vol_addr"))foundRequiredParm=1;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Share\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Share [-T] image_name\n"
                    "   [-k] 'img_vol_addr=value' \n"
                    "   [-k] 'share_enable=value' \n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Share to to indicate a full-pack minidisk is to be shared by\n"
                    "  the users of many real and virtual systems.\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual machine being created.\n"
                    "    -k    A quoted  'img_vol_addr=value' \n"
                    "          The real device number of the volume to be shared.\n"
                    "  The following options are optional:\n"
                    "    -k    A quoted  'share_enable=value' \n"
                    "          value: ON Turns on sharing of the specified full-pack minidisk.\n"
                    "          value: OFF Turns off sharing of the specified full-pack minidisk.\n"
                    "          If unspecified, the default is ON.\n");
                 FREE_MEMORY_CLEAR_POINTER(entryArray);
                 return 1;
                 break;

            case '?':  // Missing option data!
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                break;
     }

    if (!image || !entryCount || !foundRequiredParm) {
        printf("\nERROR: Missing required options\n");
        FREE_MEMORY_CLEAR_POINTER(entryArray);
        return 1;
    }

    printf("Indicating a full-pack minidisk is to be shared... ");
    rc = smImage_Volume_Share(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
         image, entryCount, entryArray, &output);
    FREE_MEMORY_CLEAR_POINTER(entryArray);

    if (rc) {
        printAndLogSmapiCallReturnCode("Event_Stream_Add", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Event_Stream_Add", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }

    return rc;
}

int imageVolumeSpaceDefineDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int function = 0;
    int startCylinder = -1;
    int regionSize = -1;
    int deviceType = 0;
    char * image = NULL;
    char * regionName = NULL;
    char * volumeId = NULL;
    char * groupName = NULL;
    vmApiImageVolumeSpaceDefineDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:g:v:s:z:p:y:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'f':
                function = atoi(optarg);
                break;

            case 'g':
                regionName = optarg;
                break;

            case 'v':
                volumeId = optarg;
                break;

            case 's':
                startCylinder = atoi(optarg);
                break;

            case 'z':
                regionSize = atoi(optarg);
                break;

            case 'p':
                groupName = optarg;
                break;

            case 'y':
                deviceType = atoi(optarg);
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Space_Define_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Space_Define_DM [-T] image_name [-f] function_type\n"
                    "    [-g] region_name [-v] vol_id [-s] start_cylinder [-z] size"
                    "    [-p] group_name [-y] device_type\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Space_Define_DM to define space on a DASD\n"
                    "  volume to be allocated by the directory manager for use by\n"
                    "  virtual images.\n\n"
                    "  The following options are required:\n"
                    "    -T    Target image or authorization entry name\n"
                    "    -f    Function type:\n"
                    "            1: Define region as specified. image_volid,\n"
                    "               region_name, start_cylinder, and size are\n"
                    "               required for this function\n"
                    "            2: Define region as specified and add to group.\n "
                    "               image_vol_id, region_name, start_cylinder, size,\n"
                    "               and group_name are required for this function\n"
                    "            3: Define region as full volume. vol_id and\n"
                    "               region_name are required for this function\n"
                    "            4: Define region as full volume and add to group.\n"
                    "               vol_id, region_name, and group_name are\n"
                    "               required for this function\n"
                    "            5: Add existing region to group. (This function also\n"
                    "               defines the group if it does not already exist.)\n"
                    "               region_name and Group are required for this function.\n"
                    "    -g    The region to be defined\n"
                    "    -v    The DASD volume label\n"
                    "    -s    The starting point of the region\n"
                    "    -z    The number of cylinders to be used by region\n"
                    "    -p    The name of the group to which the region is assigned\n"
                    "    -y    The device type designation:\n"
                    "            0: Unspecified\n"
                    "            1: 3390\n"
                    "            2: 9336\n"
                    "            3: 3380\n"
                    "            4: FB-512\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !function || !regionName) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    // Check function value to determining which parameters are required
    if (function == 1) {
        if (!volumeId || startCylinder == -1 || regionSize == -1) {
            printf("ERROR: Missing required options\n");
            return 1;
        }
    } else if (function == 2) {
        if (!volumeId || startCylinder == -1 || regionSize == -1 || !groupName) {
            printf("ERROR: Missing required options\n");
            return 1;
        }
    } else if (function == 3) {
        if (!volumeId) {
            printf("ERROR: Missing required options\n");
            return 1;
        }
    } else if (function == 4) {
        if (!volumeId || !groupName) {
            printf("ERROR: Missing required options\n");
            return 1;
        }
    } else if (function == 5) {
        if (!groupName) {
            printf("ERROR: Missing required options\n");
            return 1;
        }
    } else {
        printf("ERROR: function value is invalid\n");
        return 1;
    }

    // make sure that no NULL values are sent
    if (image == NULL) {
        image = "";
    }
    if (regionName == NULL) {
        regionName = "";
    }
    if (volumeId == NULL) {
        volumeId = "";
    }
    if (groupName == NULL) {
        groupName = "";
    }

    printf("Defining space on DASD volume to be allocated by directory manager... ");
    rc = smImage_Volume_Space_Define_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, function, regionName, volumeId, startCylinder, regionSize,
            groupName, deviceType, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Volume_Space_Define_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Volume_Space_Define_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }

    return rc;
}

int imageVolumeSpaceDefineExtendedDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    // Parse the command-line arguments
    int option;
    int rc;
    char * image = NULL;
    int entryCount = 0;
    int argBytes = 0;
    int i;
    const char * optString = "-T:k:h?";
    char ** entryArray;
    vmApiImageVolumeSpaceDefineExtendedDmOutput* output;

    // Count up the max number of arguments to create the array
    while ((option = getopt(argC, argV, optString)) != -1) {
         argBytes = argBytes + sizeof(*entryArray);
    }
    optind = 1;  // Reset optind so getopt can rescan arguments
    if (argBytes > 0) {
        entryArray = malloc(argBytes);
    }

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, optString)) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'k':
                if (!optarg) {
                    FREE_MEMORY_CLEAR_POINTER(entryArray);
                    return INVALID_DATA;
                }
                entryArray[entryCount] = optarg;
                entryCount++;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Space_Define_Extended_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Space_Define_Extended_DM [-T] image_name\n"
                    "    [-k] 'entry1' [-k] 'entry2' ...\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Space_Define_Extended_DM to define space on a DASD volume to\n"
                    "  be allocated by the directory manager for use by virtual images\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual machine being created.\n"
                    "    -k    Quoted 'keyword=value' items to describe the type of space to be added.\n"
                    "          refer to the System Management Application Programming manual for\n"
                    "          additional details.\n"
                    "          'function_type=1|2|3|4|5'\n"
                    "             1: Define region as specified. Additional parameters required for\n"
                    "                this function:\n"
                    "                image_vol_id=value, region_name=value, start_cylinder=value,\n"
                    "                v_size=value\n"
                    "             2: Define region as specified and add to group. Additional\n"
                    "                parameters required for this function:\n"
                    "                image_vol_id=value, region_name=value, start_cylinder=value,\n"
                    "                v_size=value, group_name=value\n"
                    "             3: Define region as full volume. Additional parameters required for\n"
                    "                this function:\n"
                    "                image_vol_id=value, region_name=value\n"
                    "             4: Define region as full volume and add to group. Additional\n"
                    "                parameters required for this function:\n"
                    "                image_vol_id=value, region_name=value, group_name=value\n"
                    "             5: Add existing region to group. (This function also defines the\n"
                    "                group if it does not already exist.) Additional parameters\n"
                    "                required for this function:\n"
                    "                region_name=value, group_name=value\n\n"
                    "          'region_name=value': (string,0-8,char42) The region to be defined.\n"
                    "          'image_vol_id=value': (string,0-6,char42) The DASD volume label.'\n"
                    "          'start_cylinder=value': (string,0-10,char10) The starting point of the\n"
                    "             region. If the device is not mounted and attached to the system,\n"
                    "             then this parameter is required along with the size=value and \n"
                    "             device_type=value parameters.\n"
                    "          'size=value': (string,0-10,char10) The number of cylinders to be used\n"
                    "             by region. If the device is not mounted and attached to the system,\n"
                    "             then this parameter is required along with the start_cylinder=value\n"
                    "             and device_type=value parameters.\n"
                    "          'group_name=value': (string,0-8,char42) The name of the group to which\n"
                    "             the region is assigned.\n"
                    "          'device_type=value': (string,0-1,char10) The device type designation.\n"
                    "             Valid values are:\n"
                    "               0: Unspecified\n "
                    "               1: 3390\n"
                    "               2: 9336\n"
                    "               3: 3380\n"
                    "               4: FB-512\n"
                    "          'alloc_method=value': (string,0-1,char10) The allocation method.\n"
                    "             Valid values are:\n"
                    "               0: Unspecified\n"
                    "               1: Specifies the linear scanning method, in which the first region\n"
                    "                  within a group is scanned for allocation until full, then the\n"
                    "                  second region, and so on until the last region is reached.\n"
                    "               2: Specifies the rotating scanning method, in which the first\n"
                    "                  region within a group is scanned for the first allocation, then\n"
                    "                  the second region for the second allocation, and so on with each\n"
                    "                  new allocation starting at the next region.\n");
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                break;

            case '?':  // Missing option data!
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                break;
        }

    if (!image || entryCount < 3) {
            printf("\nERROR: Missing required options\n");
            FREE_MEMORY_CLEAR_POINTER(entryArray);
            return 1;
    }

    printf("Defining space on DASD volume to be allocated by directory manager... ");
    rc = smImage_Volume_Space_Define_Extended_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Volume_Space_Define_Extended_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Volume_Space_Define_Extended_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }

    FREE_MEMORY_CLEAR_POINTER(entryArray);
    return rc;
}

int imageVolumeSpaceQueryDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int query = 0;
    int entry = 0;
    char * image = NULL;
    char * entryName = "";
    vmApiImageVolumeSpaceQueryDmOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:q:e:n:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'q':
                query = atoi(optarg);
                break;

            case 'e':
                entry = atoi(optarg);
                break;

            case 'n':
                entryName = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Space_Query_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Space_Query_DM [-T] image_name [-q] query_type \n"
                    "    [-e] entry_type [-n] entry_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Space_Query_DM to query how space on a DASD volume\n"
                    "  is allocated by the directory manager.\n\n"
                    "  The following options are required:\n"
                    "    -T    Target image or authorization entry name\n"
                    "    -q    Query type:\n"
                    "            1: Query volume definition\n"
                    "            2: Query amount of free space available\n"
                    "            3: Query amount of space used\n"
                    "    -e    Entry type:\n"
                    "            1: Query specified volume\n"
                    "            2: Query specified region\n"
                    "            3: Query specified group\n"
                    "  The following options are optional:\n"
                    "    -n    Entry name\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !query || !entry) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    // Handle return code and reason code
    rc = smImage_Volume_Space_Query_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, query, entry, entryName, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Volume_Space_Query_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Volume_Space_Query_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out image volumes
        int i, length;
        int recCount = output->recordCount;
        int p = 0;
        for (i = 0; i < recCount; i++) {
            length = output->recordList[i].imageRecordLength;
            printf("%.*s\n", length, output->recordList[0].imageRecord + p);
            p = p + length;
        }
    }

    return rc;
}

int imageVolumeSpaceQueryExtendedDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    // Parse the command-line arguments
    int option;
    int rc;
    char * image = NULL;
    int entryCount = 0;
    int argBytes = 0;
    int i;
    const char * optString = "-T:k:h?";
    char ** entryArray;
    vmApiVolumeSpaceQueryExtendedDmOutput* output;

    // Count up the max number of arguments to create the array
    while ((option = getopt(argC, argV, optString)) != -1) {
         argBytes = argBytes + sizeof(*entryArray);
    }
    optind = 1;  // Reset optind so getopt can rescan arguments
    if (argBytes > 0) {
        entryArray = malloc(argBytes);
    }

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, optString)) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'k':
                if (!optarg) {
                    FREE_MEMORY_CLEAR_POINTER(entryArray);
                    return INVALID_DATA;
                }
                entryArray[entryCount] = optarg;
                entryCount++;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Space_Query_Extended_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Space_Query_Extended_DM [-T] image_name\n"
                    "    [-k] 'entry1' [-k] 'entry2' ...\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Space_Query_Extended_DM to query how space on a DASD volume\n"
                    "  is allocated by the directory manager.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the virtual machine being created.\n"
                    "    -k    Quoted 'keyword=value' items to describe the type of space to be added.\n"
                    "  Refer to the System Management Application Programming manual for additional\n"
                    "  details."
                    "      'query_type=1|2|3':\n"
                    "        1: DEFINITION Query volume definition for the specified image\n"
                    "           device.\n"
                    "        2: FREE Query amount of free space available on the specified\n"
                    "           image device.\n"
                    "        3: USED Query amount of space used on the specified image device\n"
                    "           image_vol_id=value, region_name=value\n"
                    "      'entry_type=1|2|3':\n"
                    "        1: VOLUME - Query specified volume.\n"
                    "        2: REGION - Query specified region.\n"
                    "        3: GROUP - Query specified group.\n"
                    "  The following options are optional:\n"
                    "    'entry_names=value': string,0-255,char42 plus blank) Names of groups,\n"
                    "      regions or volumes to be queried, separated by blanks. An asterisk (*)\n"
                    "      specifies all areas of the requested type. If unspecified, * is the\n"
                    "      default.\n");
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                break;

            case '?':  // Missing option data!
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                FREE_MEMORY_CLEAR_POINTER(entryArray);
                return 1;
                break;
        }

    if (!image || entryCount < 2) {
        printf("\nERROR: Missing required options\n");
        FREE_MEMORY_CLEAR_POINTER(entryArray);
        return 1;
    }

    rc = smImage_Volume_Space_Query_Extended_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            image, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Volume_Space_Query_Extended_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Volume_Space_Query_Extended_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out image volume information
        entryCount = output->volumeSpaceCount;
        for (i = 0; i < entryCount; i++) {
            printf("%s\n", output->volumeSpaceList[i].vmapiString);
        }
    }
    FREE_MEMORY_CLEAR_POINTER(entryArray);
    return rc;
}


int imageVolumeSpaceRemoveDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    int functionType = 0;
    char * image = NULL;
    char * regionName = "";
    char * volId = "";
    char * groupName = "";
    vmApiImageVolumeSpaceRemoveDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:r:v:g:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'f':
                functionType = atoi(optarg);
                break;

            case 'r':
                regionName = optarg;
                break;

            case 'v':
                volId = optarg;
                break;

            case 'g':
                groupName = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Image_Volume_Space_Remove_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Image_Volume_Space_Remove_DM [-T] image_name [-f] function_type\n"
                    "    [-r] region_name [-v] image_volid [-g] group_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Image_Volume_Space_Remove_DM to remove the directory manager's\n"
                    "  space allocations from a DASD volume.\n\n"
                    "  The following options are required:\n"
                    "    -T    Target image or authorization entry name\n"
                    "    -f    Function type:\n"
                    "            1: Remove named region. RegionName is required for this function.\n"
                    "            2: Remove named region from group. region_name and group_name are\n"
                    "               required for this function.\n"
                    "            3: Remove named region from all groups. region_name is required\n"
                    "               for this function.\n"
                    "            4: Remove all regions from specific volume. image_volid is required\n"
                    "               for this function.\n"
                    "            5: Remove all regions from specific volume and group. image_volid\n"
                    "               and group_name are required for this function.\n"
                    "            6: Remove all regions from specific volume and all groups.\n"
                    "               image_volid is required for this function.\n"
                    "            7: Remove entire group. group_name is required for this function.\n"
                    "    -r    The region to be defined\n"
                    "    -v    The DASD volume label\n"
                    "    -g    The name of the group to which the region is assigned\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                return 1;
                break;
        }

    if (!image || !functionType) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smImage_Volume_Space_Remove_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
            image, functionType, regionName, volId, groupName, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Image_Volume_Space_Remove_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Image_Volume_Space_Remove_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }

    return rc;
}
