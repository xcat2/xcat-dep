/**
 * IBM (C) Copyright 2011,2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "cikada.h"

// The first 16 bytes in each track are a label declaring the cylinder and
// track indices.
#define TRACK_BEGINNING_OVERHEAD 16

char    keyBuffer[512] = {0};
char    dataBuffer[65536] = {0};
uint8_t keyCountRunCount;
uint8_t keyCountRunLength[256];
uint8_t keyCountRunValue[256];
uint8_t dataCountRunCount;
uint8_t dataCountRunLength[256];
uint16_t dataCountRunValue[256];

int main (int argumentCount, char* argumentValues[]) {
  if (argumentCount != 2) {
    fprintf(stderr, "Usage: %s DEVICE_NODE\n", argumentValues[0]);
    return 1;
  }
  RecordMetadata recordMetadata;
  int dasdDescriptor = open(argumentValues[1], O_RDONLY | O_DIRECT);
  if (dasdDescriptor == -1) {
    return 2;
  }
  int      returnCode = 0;
  int      exitCode   = 0;
  uint8_t  recordsInTrack;
  uint16_t cylinderIndex, trackIndex;
  uint32_t trackCount = 0;
  void*    trackBuffer;
  void*    trackBufferCursor;
  returnCode = posix_memalign(&trackBuffer, 4096, 65536);
  if (returnCode) {
    fprintf(stderr, "Error allocating buffer\n");
    return 3;
  }
  while ((returnCode = read(dasdDescriptor, trackBuffer, TRACK_SIZE) > 0)) {
    cylinderIndex = ((uint16_t*)trackBuffer)[0];
    trackIndex    = ((uint16_t*)trackBuffer)[1];
    trackCount++;
    // Re-initialize these values for each track read.
    keyCountRunCount  = 0;
    dataCountRunCount = 0;
    recordsInTrack    = 0;
    trackBufferCursor = (trackBuffer + TRACK_BEGINNING_OVERHEAD);
    while (TRUE) {
      recordMetadata = ((RecordMetadata*)trackBufferCursor)[0];
      trackBufferCursor = trackBufferCursor +
                          sizeof(recordMetadata) +
                          recordMetadata.keyCount +
                          recordMetadata.dataCount;
      if (recordMetadata.recordIndex == 0xFF) break;
      recordsInTrack = recordMetadata.recordIndex;
      if (keyCountRunCount &&
          recordMetadata.keyCount ==
            keyCountRunValue[keyCountRunCount - 1]) {
        keyCountRunLength[keyCountRunCount - 1]++;
      } else {
        keyCountRunLength[keyCountRunCount] = 1;
        keyCountRunValue[keyCountRunCount] = recordMetadata.keyCount;
        keyCountRunCount++;
      }
      if (dataCountRunCount &&
          recordMetadata.dataCount ==
            dataCountRunValue[dataCountRunCount - 1]) {
        dataCountRunLength[dataCountRunCount - 1]++;
      } else {
        dataCountRunLength[dataCountRunCount] = 1;
        dataCountRunValue[dataCountRunCount] = recordMetadata.dataCount;
        dataCountRunCount++;
      }
    }
    write (STDOUT_FILENO, &recordsInTrack, 1);
    for (int i = 0; i < keyCountRunCount;  i++) {
      write (STDOUT_FILENO, &keyCountRunLength[i], 1);
      write (STDOUT_FILENO, &keyCountRunValue[i],  1);
    }
    for (int i = 0; i < dataCountRunCount; i++) {
      write (STDOUT_FILENO, &dataCountRunLength[i], 1);
      write (STDOUT_FILENO, &dataCountRunValue[i],  2);
    }
    trackBufferCursor = (trackBuffer + TRACK_BEGINNING_OVERHEAD);
    while (TRUE) {
      recordMetadata = ((RecordMetadata*)trackBufferCursor)[0];
      if (recordMetadata.recordIndex == 0xFF) break;
      trackBufferCursor += sizeof(recordMetadata);
      write (STDOUT_FILENO, trackBufferCursor, recordMetadata.keyCount);
      trackBufferCursor += recordMetadata.keyCount;
      write (STDOUT_FILENO, trackBufferCursor, recordMetadata.dataCount);
      trackBufferCursor += recordMetadata.dataCount;

    }
  }
  if (returnCode < 0) exitCode = 4;
  returnCode = close(dasdDescriptor);
  if (returnCode < 0) exitCode = 5;
  free(trackBuffer);
  return exitCode;
}
