/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "smcliProfile.h"
#include "wrapperutils.h"

int profileCreateDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * profile = NULL;
    char * profileFile = NULL;
    vmApiProfileCreateDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:h?")) != -1)
        switch (option) {
            case 'T':
                profile = optarg;
                break;

            case 'f':
                profileFile = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Profile_Create_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Profile_Create_DM [-T] profile_name [-f] profile_file\n\n"
                    "DESCRIPTION\n"
                    "  Use Profile_Create_DM to create a profile directory entry to be included\n"
                    "  in the definition of a virtual image in the directory.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the profile to be created\n"
                    "    -f    The profile directory entry file\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                break;
        }

    if (!profile || !profileFile) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    // Open the user entry file
    FILE * fp = fopen(profileFile, "r");

    // Count the number of lines and set the record count to it
    int recordCount = 0;
    int c;
    while ((c = fgetc(fp)) != EOF) {
        if (c == '\n')
            recordCount++;
    }

    // Reset position to start of file
    rewind(fp);

    // Create image record
    vmApiProfileRecord record[recordCount];
    int i = 0, LINE_SIZE = 72;
    char line[recordCount][LINE_SIZE];
    char * ptr;
    while (fgets(line[i], LINE_SIZE, fp) != NULL) {
        // Replace newline with null terminator
        ptr = strstr(line[i], "\n");
        if (ptr != NULL)
            strncpy(ptr, "\0", 1);

        record[i].profileRecordLength = strlen(line[i]);
        record[i].recordData = line[i];
        i++;
    }

    // Close file
    fclose(fp);

    printf("Creating profile directory entry %s... ", profile);
    rc = smProfile_Create_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            profile, recordCount, (vmApiProfileRecord *) record,  // Image record
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Profile_Create_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Profile_Create_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int profileDeleteDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * profile = NULL;
    vmApiProfileDeleteDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                profile = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Profile_Delete_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Profile_Delete_DM [-t] profile_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Profile_Delete_DM to delete a profile directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the profile to be deleted\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                break;
        }

    if (!profile) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting profile directory entry %s... ", profile);
    rc = smProfile_Delete_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            profile, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Profile_Delete_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Profile_Delete_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int profileLockDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * profile = NULL;
    vmApiProfileLockDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                profile = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Profile_Lock_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Profile_Lock_DM [-T] profile_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Profile_Lock_DM to lock a profile directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the profile to be locked.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                break;
        }

    if (!profile) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Locking profile directory entry %s... ", profile);
    rc = smProfile_Lock_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            profile, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Profile_Lock_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Profile_Lock_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int profileQueryDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * profile = NULL;
    vmApiProfileQueryDmOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                profile = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Profile_Query_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Profile_Query_DM [-T] profile_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Profile_Query_DM to query a profile directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the profile being queried\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                break;
        }

    if (!profile) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smProfile_Query_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            profile,  // Profile name
            &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Profile_Query_DM", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Profile_Query_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out directory profile
        int i;
        int recCount = output->profileRecordCount;
        if (recCount > 0) {
            // Loop through profile records and print out profile entry
            for (i = 0; i < recCount; i++) {
                printf("%s\n", output->profileRecordList[i].recordData);
            }
        }
    }
    return rc;
}

int profileReplaceDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * profile = NULL;
    char * profileFile = NULL;
    vmApiProfileReplaceDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:f:h?")) != -1)
        switch (option) {
            case 'T':
                profile = optarg;
                break;

            case 'f':
                profileFile = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Profile_Replace_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Profile_Replace_DM [-T] profile_name [-f] profile_file\n\n"
                    "DESCRIPTION\n"
                    "  Use Profile_Replace_DM to replace the definition of a profile to be\n"
                    "  included in a virtual image in the directory.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the profile directory entry to be replaced\n"
                    "    -f    The profile directory entry file");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                break;
        }

    if (!profile || !profileFile) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    // Open the user entry file
    FILE * fp = fopen(profileFile, "r");

    // Count the number of lines and set the record count to it
    int recordCount = 0;
    int c;
    while ((c = fgetc(fp)) != EOF) {
        if (c == '\n')
            recordCount++;
    }

    // Reset position to start of file
    rewind(fp);

    // Create image record
    vmApiProfileRecord record[recordCount];
    int i = 0, LINE_SIZE = 72;
    char line[recordCount][LINE_SIZE];
    char * ptr;
    while (fgets(line[i], LINE_SIZE, fp) != NULL) {
        // Replace newline with null terminator
        ptr = strstr(line[i], "\n");
        if (ptr != NULL)
            strncpy(ptr, "\0", 1);

        record[i].profileRecordLength = strlen(line[i]);
        record[i].recordData = line[i];
        i++;
    }

    // Close file
    fclose(fp);

    printf("Replacing definition of %s... ", profile);
    rc = smProfile_Replace_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            profile, recordCount, (vmApiProfileRecord *) record,  // Image record
            &output);


    if (rc) {
        printAndLogSmapiCallReturnCode("Profile_Replace_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Profile_Replace_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int profileUnlockDM(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * profile = NULL;
    vmApiProfileUnlockDmOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "-T:h?")) != -1)
        switch (option) {
            case 'T':
                profile = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Profile_Unlock_DM\n\n"
                    "SYNOPSIS\n"
                    "  smcli Profile_Unlock_DM [-T] profile_name\n\n"
                    "DESCRIPTION\n"
                    "  Use Profile_Unlock_DM to unlock a profile directory entry.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the profile to be unlocked.\n");
                return 1;
                break;

            case '?':  // Missing option data!
                return 1;
                  break;

            case 1:  // API name type data(other non option element key data)
                break;

            default:
                break;
        }

    if (!profile) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("UnLocking profile directory entry %s... ", profile);
    rc = smProfile_Unlock_DM(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            profile, &output);


    if (rc) {
        printAndLogSmapiCallReturnCode("Profile_Unlock_DM", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Profile_Unlock_DM", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}
