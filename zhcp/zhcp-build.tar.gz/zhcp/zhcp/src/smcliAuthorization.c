/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "smcliAuthorization.h"
#include "wrapperutils.h"

int authorizationListAdd(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * forId = "";
    char * functionId = "";
    vmApiAuthorizationListAddOutput* output;

    // Parse the command-line arguments
    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:i:f:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'i':
                forId = optarg;
                break;

            case 'f':
                functionId = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Authorization_List_Add\n\n"
                    "SYNOPSIS\n"
                    "  smcli Authorization_List_Add [-T] image_name [-i] for_id [-f] function_id\n\n"
                    "DESCRIPTION\n"
                    "  Use Authorization_List_Add to add an entry to the authorization file.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name\n"
                    "    -i    This is the virtual image or list of virtual images which will be\n"
                    "          authorized to perform the designated function(s)\n"
                    "    -f    The function or list of functions that is authorized to perform\n");
                return 1;
                break;

            default:
                break;
        }

    if (!image || !forId || !functionId) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Adding an entry to the authorization file for %s... ", image);
    rc = smAuthorization_List_Add(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
             image, forId, functionId, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Authorization_List_Add", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Authorization_List_Add", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int authorizationListQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * forId = "";
    char * functionId = "";
    vmApiAuthorizationListQueryOutput* output;

    // Parse the command-line arguments
    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:i:f:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'i':
                forId = optarg;
                break;

            case 'f':
                functionId = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Authorization_List_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli Authorization_List_Query [-T] image_name [-i] for_id [-f] function_id\n\n"
                    "DESCRIPTION\n"
                    "  Use Authorization_List_Query to query the entries in the authorization file.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name\n"
                    "  The following options are optional:\n"
                    "    -i    The userid or list of userids in the 'Requesting User(s)' field of the\n"
                    "          authorization file record(s) being queried\n"
                    "    -f    The function or list of functions that target_identifier is authorized\n"
                    "          to perform for for_id\n");
                return 1;
                break;

            default:
                break;
        }

    if (!image) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    rc = smAuthorization_List_Query(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
             image, forId, functionId, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Authorization_List_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Authorization_List_Query", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        // Print out image volumes
        int i, length;
        int recCount = output->authorizationRecordCount;
        for (i = 0; i < recCount; i++) {
            char* reqUserId = output->authorizationRecordList[i].requestingUserid;
            char* forUserId = output->authorizationRecordList[i].forUserid;
            char* functionName = output->authorizationRecordList[i].functionName;
            printf("Entry:\n"
                "  Requesting user ID: %s\n"
                "  For user ID: %s\n"
                "  Function name: %s\n", reqUserId, forUserId, functionName);
        }
    }
    return rc;
}

int authorizationListRemove(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * image = NULL;
    char * forId = NULL;
    char * functionId = NULL;
    vmApiAuthorizationListRemoveOutput* output;

     // Parse the command-line arguments
    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:i:f:h?")) != -1)
        switch (option) {
            case 'T':
                image = optarg;
                break;

            case 'i':
                forId = optarg;
                break;

            case 'f':
                functionId = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  Authorization_List_Remove\n\n"
                    "SYNOPSIS\n"
                    "  smcli Authorization_List_Remove [-T] image_name [-i] for_id [-f] function_id\n\n"
                    "DESCRIPTION\n"
                    "  Use Authorization_List_Remove to remove an entry from the authorization file.\n\n"
                    "  The following options are required:\n"
                    "    -T    The userid or image name\n"
                    "    -i    The userid or list of userids whose authorization to perform the\n"
                    "          designated function(s) is to be removed\n"
                    "    -f    The function or list of functions for which target_identifier's\n"
                    "          authorization to perform for for_id will be removed\n");
                return 1;
                break;

            default:
                break;
        }

    if (!image || !forId || !functionId) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Removing %s from the authorization file... ", forId);
    rc = smAuthorization_List_Remove(vmapiContextP, "", 0, "",  // Authorizing user, password length, password.
             image, forId, functionId, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("Authorization_List_Remove", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("Authorization_List_Remove", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}
