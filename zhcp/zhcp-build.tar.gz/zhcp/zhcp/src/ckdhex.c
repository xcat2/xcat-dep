/**
 * IBM (C) Copyright 2011,2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "cikada.h"

char keyBuffer[512]    = {0};
char dataBuffer[65536] = {0};

int main (int argumentCount, char* argumentValues[]) {
  int fileDescriptor, returnCode, exitCode, startTrack, endTrack;
  if (argumentCount == 2) {
    startTrack = 0;
    endTrack   = INT_MAX;
  } else if (argumentCount == 4) {
    startTrack = atoi(argumentValues[2]);
    endTrack   = atoi(argumentValues[3]);
  } else {
    fprintf(stderr,
            "Usage: %s DEVICE_NODE\n       %s DEVICE_NODE START_TRK END_TRK\n",
            argumentValues[0],
            argumentValues[0]);
    return 1;
  }
  void* trackBuffer;
  void* trackBufferCursor;
  uint16_t cylinderIndex, trackIndex;
  RecordMetadata recordMetadata;
  fileDescriptor = open(argumentValues[1], O_RDONLY | O_DIRECT);
  if (fileDescriptor == -1) {
    fprintf (stderr, "Error opening file.\n");
    return 2;
  }
  returnCode = posix_memalign(&trackBuffer, 4096, 65536);
  if (returnCode) {
    fprintf(stderr, "Error allocating buffer\n");
    return 3;
  }
  while ((returnCode = read(fileDescriptor, trackBuffer, TRACK_SIZE))) {
    cylinderIndex = ((uint16_t*)trackBuffer)[0];
    trackIndex    = ((uint16_t*)trackBuffer)[1];
    if (trackIndex < startTrack) continue;
    if (15 * cylinderIndex + trackIndex > endTrack) break;
    if ( trackIndex == 0 ) printf("Cylinder: 0x%04x\n", cylinderIndex);
    printf("  Track:  0x%04x\n", trackIndex);
    trackBufferCursor = (trackBuffer + TRACK_BEGINNING_OVERHEAD);
    while (TRUE) {
      recordMetadata = ((RecordMetadata*)trackBufferCursor)[0];
      trackBufferCursor += sizeof(recordMetadata);
      memcpy(keyBuffer, trackBufferCursor, recordMetadata.keyCount);
      trackBufferCursor += recordMetadata.keyCount;
      memcpy(dataBuffer, trackBufferCursor, recordMetadata.dataCount);
      trackBufferCursor += recordMetadata.dataCount;
      if (recordMetadata.recordIndex == 0xFF) {
        break;
      } else {
        printf("    Record Index: 0x%02x   ", recordMetadata.recordIndex);
        printf(    "Key Count: 0x%02x   ",    recordMetadata.keyCount);
        printf(    "Data Count: 0x%02x\n",  recordMetadata.dataCount);
        printf("      KEY:  ");
        for (int i = 0; i < recordMetadata.keyCount; i++) {
          printf("%02x ", keyBuffer[i]);
        }
        printf("\n      DATA: ");
        for (int i = 0; i < recordMetadata.dataCount; i++) {
          printf("%02x ", dataBuffer[i]);
        }
        printf("\n");
      }
    }
  }
  if (returnCode < 0) {
    fprintf(stderr, "Error opening file\n");
    exitCode = 4;
  }
  returnCode = close(fileDescriptor);
  if (returnCode < 0) {
    fprintf(stderr, "Error closing file\n");
    exitCode = 5;
  }
  free(trackBuffer);
  return exitCode;
}
