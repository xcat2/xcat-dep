/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "smcliProcess.h"
#include "wrapperutils.h"

int processABENDDump(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc = 0;
    printf("Not done yet.\n");
    return rc;
}
