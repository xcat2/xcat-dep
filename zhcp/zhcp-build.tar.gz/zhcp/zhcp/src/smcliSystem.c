/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#include "smcliSystem.h"
#include "wrapperutils.h"

int systemConfigSyntaxCheck(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int maxEntryCount = 5;
    int minNeeded = 5;
    int entryCount = 0;
    int option;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    vmApiSystemConfigSyntaxCheckOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf("ERROR: Too many -k values entered\n");
                    return INVALID_DATA;
                }

                break;

            case 'h':
                printf("NAME\n"
                    "  System_Config_Syntax_Check\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_Config_Syntax_Check [-T] targetIdentifier\n"
                    "    [-k] entry1 [-k] entry2...\n\n"
                    "DESCRIPTION\n"
                    "  Use System_Config_Syntax_Check to check the syntax of a system configuration\n"
                    "  file located on a system parm disk.\n\n"
                    "  The following options are required:\n"
                    "    -T    This must match an entry in the authorization file that also contains\n"
                    "          the authenticated_userid and the function_name \n"
                    "          (System_Config_Syntax_Check).\n"
                    "    -k    A keyword=value item to be created in the directory.\n"
                    "          They may be specified in any order. Possible keywords are:\n"
                    "            system_config_type: File name of the system configuration file.\n"
                    "                                The default is set by the\n"
                    "                                System_Config_File_Name = statement in the\n"
                    "                                DMSSICNF COPY file.\n\n"
                    "            system_config_type: File type of the system configuration file.\n"
                    "                                The default is set by the\n"
                    "                                System_Config_File_Type = statement in the\n"
                    "                                DMSSICNF COPY file.\n\n"
                    "            parm_disk_owner: Owner of the parm disk. The default is set by\n"
                    "                             the Parm_Disk_Owner = statement in the DMSSICNF\n"
                    "                             COPY file.\n"
                    "            parm_disk_number: Number of the parm disk as defined in the\n"
                    "                              VSMWORK1 directory.The default is set by the\n"
                    "                              Parm_Disk_Number = statement in the \n"
                    "                              DMSSICNF COPY file.\n\n"
                    "            parm_disk_password: Multiwrite password for the parm disk. The\n"
                    "                                default is set by the Parm_Disk_Password = \n"
                    "                                statement in the DMSSICNF COPY file.\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier ||  entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Checking the syntax of system configuration... ");
    rc = smSystem_Config_Syntax_Check(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_Config_Syntax_Check", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code and Error Buffer if it was sent
        printAndLogSmapiReturnCodeReasonCodeDescriptionAndErrorBuffer("System_Config_Syntax_Check", rc, output->common.returnCode,
            output->common.reasonCode, output->errorDataLength, output->errorData, vmapiContextP);
    }
    return rc;
}

int systemDiskAccessibility(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int maxEntryCount = 1;
    int minNeeded = 1;
    int entryCount = 0;
    int option;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    vmApiSystemDiskAccessibilityOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf("ERROR: Too many -k values entered.\n");
                    return INVALID_DATA;
                }

                break;

            case 'h':
                printf("NAME\n"
                    "  System_Disk_Accessibility\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_Disk_Accessibility [-T] targetIdentifier [-k] 'dev_num=xxxx'\n\n"
                    "DESCRIPTION\n"
                    " Use System_Disk_Accessibility to verify that the specified device is available\n"
                    " to be attached. If RC=0/RS=0 is received, then the device is available.\n\n"
                    "  The following options are required:\n"
                    "    -T    This must match an entry in the authorization file that also contains\n"
                    "          the authenticated_userid and the function_name\n"
                    "          (System_Disk_Accessibility).\n"
                    "    -k    A keyword=value item to be created in the directory. Possible\n"
                    "          keywords are:\n"
                    "            dev_num: The disk device number. This is a required input\n"
                    "                     parameter. They may be specified in any order.\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier || entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Verifying that %s is available to be attached... ", entryArray[0]);
    rc = smSystem_Disk_Accessibility(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_Disk_Accessibility", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_Disk_Accessibility", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}


int systemDiskAdd(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int maxEntryCount = 1;
    int minNeeded = 1;
    int entryCount = 0;
    int option;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    vmApiSystemDiskAddOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf("ERROR: Too many -k values entered\n");
                    return INVALID_DATA;
                }

                break;

            case 'h':
                printf("NAME\n"
                    "  System_Disk_Add\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_Disk_Add [-T] targetIdentifier\n"
                    "    [-k] entry1 [-k] entry2...\n\n"
                    "DESCRIPTION\n"
                    "  Use System_Disk_Add to dynamically add an ECKD disk to a running z/VM system\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to which a disk is being added.\n"
                    "    -k    A keyword=value item to be created in the directory.\n"
                    "          They may be specified in any order. Possible keywords are:\n"
                    "              dev_num - The disk device number.\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier ||  entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Adding ECKD disk to z/VM system... ");
    rc = smSystem_Disk_Add(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_Disk_Add", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_Disk_Add", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int systemDiskQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int i;
    int maxEntryCount = 1;
    int minNeeded = 1;
    int entryCount = 0;
    int option;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    char *token;
    char *buffer;  // char * whose value is preserved between successive related calls to strtok_r.
    char blank[1] = " ";
    char dev_id[4+1];
    char dev_type[7+1];
    char dev_status[8+1];
    char dev_volser[6+1];
    vmApiSystemDiskQueryOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount +1) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf("ERROR: Too many -k values entered.\n");
                    return INVALID_DATA;
                }
                break;

            case 'h':
                printf("NAME\n"
                    "  System_Disk_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli Use System_Disk_Query [-T] targetIdentifier\n"
                    "    [-k] entry1 [-k] entry2... \n\n"
                    "DESCRIPTION\n"
                    " Use System_Disk_Query to query a real ECKD disk or all real ECKD disks.\n\n"
                    "  The following options are required:\n"
                    "    -T    This must match an entry in the authorization file that also contains\n"
                    "          the authenticated_userid and the function_name (System_Disk_Query).\n"
                    "    -k    A keyword=value item to be created in the directory.\n"
                    "          They may be specified in any order. Possible keywords are:\n"
                    "            dev_num: The disk device number.\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier ||  entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    rc = smSystem_Disk_Query(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_Disk_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_Disk_Query", output->common.returnCode,
             output->common.reasonCode, vmapiContextP);
    } else {
        for (i =0; i < output->diskInfoArrayCount; i ++) {
            // Get dev_id
            token = strtok_r(output->diskIinfoStructure[i].vmapiString, blank, &buffer);
            if (token != NULL) {
                strcpy(dev_id, token);
            } else {
                printf("ERROR: Device ID is NULL\n");
                break;
            }
            // Get dev_type
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(dev_type, token);
            } else {
                printf("ERROR: Device type is NULL\n");
                break;
            }
            // Get dev_status
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(dev_status, token);
            } else {
                printf("ERROR: Device status is NULL\n");
                break;
            }
            // Get dev_volser
            token = strtok_r(NULL, "\0", &buffer);
            if (token != NULL) {
                strcpy(dev_volser, token);
            } else {
                strcpy(dev_volser, "");
            }
            printf("Device ID: %s\n"
                   "  Device type: %s\n"
                   "  Device status: %s\n"
                   "  Device volume serial number: %s\n", dev_id, dev_type, dev_status, dev_volser);
        }
    }
    return rc;
}


int systemFCPFreeQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int i;
    int maxEntryCount = 1;
    int minNeeded = 1;
    int entryCount = 0;
    int option;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    char *token;
    char *buffer;  // char * whose value is preserved between successive related calls to strtok_r.
    char semicolon[1] = ";";
    char fcp_dev[4+1];
    char wwpn[16+1];
    char lun[16+1];
    char uuid[64+1];
    char vendor[8+1];
    char prod[4+1];
    char model[4+1];
    char serial[8+1];
    char code[4+1];
    char blk_size[10+1];
    char diskblks[10+1];
    char lun_size[20+1];
    vmApiSystemFCPFreeQueryOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf("ERROR: Too many -k values entered.\n");
                    return INVALID_DATA;
                }

                break;

            case 'h':
                printf("NAME\n"
                    "  System_FCP_Free_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_FCP_Free_Query [-T] targetIdentifier\n"
                    "    [-k] entry1 [-k] entry2 ...\n\n"
                    "DESCRIPTION\n"
                    " Use System_FCP_Query to query free FCP disk information.\n\n"
                    "  The following options are required:\n"
                    "    -T    This must match an entry in the authorization file that also\n"
                    "          contains the authenticated_userid and the function_name\n"
                    "          (System_FCP_Free_Query).\n"
                    "    -k    A keyword=value item to be created in the directory.\n"
                    "          They may be specified in any order. Possible keywords are:\n"
                    "            fcp_dev: The FCP device number. This is a required parameter.\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier ||  entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    rc = smSystem_FCP_Free_Query(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_FCP_Free_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_FCP_Free_Query", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    } else {
        for (i =0; i < output->fcpArrayCount; i ++) {
            // Get fcp_dev
            token = strtok_r(output->fcpStructure[i].vmapiString, semicolon, &buffer);
            if (token != NULL) {
                strcpy(fcp_dev, token);
            } else {
                printf("ERROR: FCP device number is NULL\n");
                break;
            }

            // Get wwpn
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(wwpn, token);
            } else {
                printf("ERROR: World wide port number is NULL\n");
                break;
            }

            // Get lun
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(lun, token);
            } else {
                printf("ERROR: Logical unit number is NULL\n");
                break;
            }

            // Get uuid
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(uuid, token);
            } else {
                printf("ERROR: Universally unique number is NULL\n");
                break;
            }

            // Get vendor
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(vendor, token);
            } else {
                printf("ERROR: Vendor name is NULL\n");
                break;
            }

            // Get prod
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(prod, token);
            } else {
                printf("ERROR: Product number is NULL\n");
                break;
            }

            // Get model
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(model, token);
            } else {
                printf("ERROR: Model number is NULL\n");
                break;
            }
            // Get serial
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(serial, token);
            } else {
                printf("ERROR: Serial number is NULL\n");
                break;
            }

            // Get code
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(code, token);
            } else {
                printf("ERROR: Device code is NULL\n");
                break;
            }

            // Get blk_size
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(blk_size, token);
            } else {
                printf("ERROR: Block size is NULL\n");
                break;
            }

            // Get diskblks
            token = strtok_r(NULL, semicolon, &buffer);
            if (token != NULL) {
                strcpy(diskblks, token);
            } else {
                printf("ERROR: Number of blocks residing on the logical unit is NULL\n");
                break;
            }

            // Get lun_size
            token = strtok_r(NULL, "\0", &buffer);
            if (token != NULL) {
                strcpy(lun_size, token);
            } else {
                printf("ERROR: Number of bytes residing on the logical unit is NULL\n");
                break;
            }
            printf("FCP device number: %s\n"
                   "  World wide port number: %s\n"
                   "  Logical unit number: %s\n"
                   "  Universally unique number in printed hex: %s\n"
                   "  Vendor name: %s\n"
                   "  Product number: %s\n"
                   "  Model number: %s\n"
                   "  Serial number: %s\n"
                   "  Device code: %s\n"
                   "  Block size, in bytes: %s\n"
                   "  Number of blocks residing on the logical unit: %s\n"
                   "  Number of bytes residing on the logical unit: %s\n",
                   fcp_dev, wwpn, lun, uuid, vendor, prod, model, serial, code, blk_size, diskblks, lun_size);
        }
    }

    return rc;
}


int systemPerformanceThresholdDisable(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * targetIdentifier = NULL;
    char * eventType = NULL;
    vmApiSystemPerformanceThresholdDisableOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:v:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'v':
                eventType = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  System_Performance_Threshold_Disable\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_Performance_Threshold_Disable [-T] target_identifier [-v] dev_num\n\n"
                    "DESCRIPTION\n"
                    " Use System_Performance_Threshold_Disable to disable thresholds for asynchronous\n"
                    " event production.\n\n"
                    "  The following options are required:\n"
                    "    -T    Used strictly for authorization  i.e. the authenticated user must\n"
                    "          have authorization to perform this function for this target.\n"
                    "    -v    One of the following, followed by a null (ASCIIZ) terminator:\n"
                    "            System_CPU\n"
                    "            System_Virtual_IO\n"
                    "            System_Paging\n"
                    "            System_DASD_IO\n"
                    "            User_CPU userid\n"
                    "            User_IO userid\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier || !eventType) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Disabling thresholds for asynchronous event production for %s... ", eventType);
    rc = smSystem_Performance_Threshold_Disable(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            targetIdentifier, eventType, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_Performance_Threshold_Disable", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_Performance_Threshold_Disable", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}


int systemPerformanceThresholdEnable(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int option;
    char * targetIdentifier = NULL;
    char * eventType = NULL;
    vmApiSystemPerformanceThresholdEnableOutput* output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:v:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'v':
                eventType = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  System_Performance_Threshold_Enable\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_Performance_Threshold_Enable [-T] targetIdentifier [-v] eventType\n\n"
                    "DESCRIPTION\n"
                    "  Use System_Performance_Threshold_Enable to enable thresholds for asynchronous\n"
                    "  event production.\n\n"
                    "  The following options are required:\n"
                    "    -T    Used strictly for authorization  i.e. the authenticated user must\n"
                    "          have authorization to perform this function for this target.\n"
                    "    -v    One of the following, followed by a null (ASCIIZ) terminator:\n"
                    "            System_CPU = percentage\n"
                    "            System_Virtual_IO = rate/sec\n"
                    "            System_Paging = rate/sec\n"
                    "            System_DASD_IO = rate/sec\n"
                    "            User_CPU = userid percentage \n"
                    "            User_IO = userid rate/sec\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier || !eventType) {
        printf("ERROR: Missing required options\n");
        return 1;
    }

    printf("Enabling thresholds for asynchronous event production for %s... ", eventType);
    rc = smSystem_Performance_Threshold_Enable(vmapiContextP, "", 0, "",  // Authorizing user, password length, password
            targetIdentifier, eventType, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_Performance_Threshold_Enable", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_Performance_Threshold_Enable", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int systemSCSIDiskAdd(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int maxEntryCount = 4;
    int minNeeded = 1;
    int entryCount = 0;
    int option;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    vmApiSystemSCSIDiskAddOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf(" Error Too many -k values entered.\n");
                    return INVALID_DATA;
                }

                break;

            case 'h':
                printf("NAME\n"
                    "  System_SCSI_Disk_Add\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_SCSI_Disk_Add [-T] targetIdentifier\n"
                    "    [-k] entry1 [-k] entry2 ...\n\n"
                    "DESCRIPTION\n"
                    "  Use System_SCSI_Disk_Add to dynamically add a SCSI disk to a running z/VM\n"
                    "  system.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to which a disk is being added.\n"
                    "    -k    A keyword=value item to be created in the directory.\n"
                    "          They may be specified in any order. Possible keywords are:\n"
                    "            dev_num: The SCSI disk device number.\n"
                    "            dev_path_array: An array of device path structures. Each\n"
                    "                            structure has the following fields\n"
                    "                            (each field is separated by a blank and the\n"
                    "                            structures are separated by semicolons)\n"
                    "              fcp_dev_num: The FCP device number\n"
                    "              fcp_wwpn:  The world wide port number\n"
                    "              fcp_lun: The logical unit number\n"
                    "    NOTE: The following are only used on ZVM 6.2 and above\n"
                    "            option: One of the following:\n"
                    "              1 - Add a new SCSI disk. This is the default if unspecified.\n"
                    "              2 - Add new paths to an existing SCSI disk.\n"
                    "              3 - Delete paths from an existing SCSI disk.\n\n"
                    "            persist: This can be one of the following values:\n"
                    "              NO - The SCSI device is updated on the active system, but is\n"
                    "                   not updated in the permanent configuration for the system.\n"
                    "              YES - The SCSI device is updated on the active system and also\n"
                    "                    in the permanent configuration for the system.\n"
                    "              If not specified, the default is NO.\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier ||  entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Adding a real SCSI disk to z/VM system... ");
    rc = smSystem_SCSI_Disk_Add(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_SCSI_Disk_Add", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_SCSI_Disk_Add", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int systemSCSIDiskDelete(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int maxEntryCount = 2;
    int minNeeded = 1;
    int entryCount = 0;
    int option;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    vmApiSystemSCSIDiskDeleteOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount +1) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf(" Error Too many -k values entered.\n");
                    return INVALID_DATA;
                }

                break;

            case 'h':
                printf("NAME\n"
                    "  System_SCSI_Disk_Delete\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_SCSI_Disk_Delete [-T] targetIdentifier\n"
                    "    [-k] entry1 [-k] entry2 ...\n\n"
                    "DESCRIPTION\n"
                    "  Use System_SCSI_Disk_Delete to delete a real SCSI disk.\n\n"
                    "  The following options are required:\n"
                    "    -T    The name of the image to which a disk is being added.\n"
                    "    -k    A keyword=value item to be created in the directory.\n"
                    "          They may be specified in any order. Possible keywords are:\n"
                    "            dev_num: The SCSI disk device number.\n"
                    "            persist: This can be one of the following values:\n"
                    "              NO - The SCSI device is deleted on the active\n"
                    "                   system, but is not deleted in the permanent\n"
                    "                   configuration for the system.\n"
                    "              YES - The SCSI device is deleted from the active\n"
                    "                    system and also from the permanent\n"
                    "                    configuration for the system.\n"
                    "          If not specified, the default is NO.\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }

    if (!targetIdentifier ||  entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    printf("Deleting a real SCSI disk... ");
    rc = smSystem_SCSI_Disk_Delete(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);


    if (rc) {
        printAndLogSmapiCallReturnCode("System_SCSI_Disk_Delete", rc, vmapiContextP);
    } else {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_SCSI_Disk_Delete", output->common.returnCode,
            output->common.reasonCode, vmapiContextP);
    }
    return rc;
}

int systemSCSIDiskQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int i;
    int k;
    int offset;
    int maxEntryCount = 1;
    int minNeeded = 1;
    int entryCount = 0;
    int option;
    int fcpStructureSize;
    int numFcpStructures;
    int fcpDevIdIndex = 0;
    int fcpDevWwpnIndex = 0;
    int fcpDevLunIndex = 0;
    char * targetIdentifier = NULL;
    char * entryArray[maxEntryCount];
    char * token;
    char * buffer;
    char blank[1] = " ";
    char dev_id[4+1];
    char dev_type[3+1];
    char dev_attr[4+1];
    char dev_size[8+1];
    char fcp_dev_id[4+1];
    char fcp_dev_wwpn[16+1];
    char fcp_dev_lun[16+1];
    char arrayFcpStructure[1024];
    vmApiSystemSCSIDiskQueryOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:k:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'k':
                if (!optarg) {
                    return INVALID_DATA;
                }
                if (entryCount < maxEntryCount) {
                    entryArray[entryCount] = optarg;
                    entryCount++;
                } else {
                    printf(" Error Too many -k values entered.\n");
                    return INVALID_DATA;
                }

                break;

            case 'h':
                printf("NAME\n"
                    "  System_SCSI_Disk_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_SCSI_Disk_Query [-T] targetIdentifier [-k] entry.\n\n"
                    "DESCRIPTION\n"
                    " Use System_SCSI_Disk_Query to query a real SCSI disk or all real SCSI disks.\n\n"
                    "  The following options are required:\n"
                    "    -T    This must match an entry in the authorization file that also contains\n"
                    "          the authenticated_userid and the function_name\n"
                    "          (System_SCSI_Disk_Query).\n"
                    "    -k    A keyword=value item to be created in the directory.\n"
                    "          They may be specified in any order. Possible keywords are:\n"
                    "            dev_num: The device number or 'ALL'\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }


    if (!targetIdentifier ||  entryCount < minNeeded)  {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    rc = smSystem_SCSI_Disk_Query(vmapiContextP, "", 0, "", targetIdentifier, entryCount, entryArray, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_SCSI_Disk_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_SCSI_Disk_Query", output->common.returnCode,
             output->common.reasonCode, vmapiContextP);
    } else {
        for (i =0; i < output->scsiInfoArrayCount; i ++) {
            // Get dev_id
            token = strtok_r(output->scsiInfoStructure[i].vmapiString, blank, &buffer);
            if (token != NULL) {
                strcpy(dev_id, token);
            } else {
                printf("ERROR: Device ID is NULL\n");
                break;
            }
            // Get dev_type
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(dev_type, token);
            } else {
                printf("ERROR: Device type is NULL\n");
                break;
            }
            // Get dev_attr
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(dev_attr, token);
            } else {
                printf("ERROR: Device attribute is NULL\n");
                break;
            }
            // Get dev_size
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(dev_size, token);
            } else {
                printf("ERROR: Device size is NULL\n");
                break;
            }

            printf("Device ID: %s \n"
                   "  Device type: %s\n"
                   "  Device attribute: %s\n"
                   "  Device size, in blocks: %s\n",
                   dev_id, dev_type, dev_attr, dev_size);

            // Get fcp_structure
            token = strtok_r(NULL, "\0", &buffer);
            if (token != NULL) {
                strcpy(arrayFcpStructure, token);
            } else {
                printf("ERROR: FCP structure is NULL\n");
                break;
            }

            fcpStructureSize = strlen(arrayFcpStructure);
            numFcpStructures = fcpStructureSize / 36;
            offset =0;
            for (k =0; k < numFcpStructures; k++) {
                strncpy(fcp_dev_id, arrayFcpStructure + (offset), 4);
                strncpy(fcp_dev_wwpn, arrayFcpStructure + (offset + 4), 16);
                strncpy(fcp_dev_lun,  arrayFcpStructure +(offset + 20), 16);
                printf("  FCP device number: %s \n"
                       "  World wide port number: %s \n"
                       "  Logical unit number: %s \n",
                       fcp_dev_id, fcp_dev_wwpn, fcp_dev_lun);
                if (offset > 36) {
                    offset = offset + 36;
                }
            }
        }
    }
    return rc;
}

int systemWWPNQuery(int argC, char* argV[], struct _vmApiInternalContext* vmapiContextP) {
    int rc;
    int i;
    int option;
    int devStatus;
    char * targetIdentifier = NULL;
    char * token;
    char * buffer;
    char blank[1] = " ";
    char fcp_dev_id[4+1];
    char npiv_wwpn[16+1];
    char chpid[2+1];
    char perm_wwpn[16+1];
    char dev_status[1+1];
    char * status;
    vmApiSystemWWPNQueryOutput * output;

    // Options that have arguments are followed by a : character
    while ((option = getopt(argC, argV, "T:h?")) != -1)
        switch (option) {
            case 'T':
                targetIdentifier = optarg;
                break;

            case 'h':
                printf("NAME\n"
                    "  System_WWPN_Query\n\n"
                    "SYNOPSIS\n"
                    "  smcli System_WWPN_Query [-T] targetIdentifier\n\n"
                    "DESCRIPTION\n"
                    " Use System_WWPN_Query to query all FCPs on a z/VM system and return a list of\n"
                    " WWPNs.\n\n"
                    "  The following options are required:\n"
                    "    -T    This must match an entry in the authorization file that also contains\n"
                    "          the authenticated_userid and the function_name (System_WWPN_Query).\n\n");
                return 1;
                break;

            default:
                return 1;
                break;
        }


    if (!targetIdentifier) {
        printf("\nERROR: Missing required options\n");
        return 1;
    }

    rc = smSystem_WWPN_Query(vmapiContextP, "", 0, "", targetIdentifier, &output);

    if (rc) {
        printAndLogSmapiCallReturnCode("System_WWPN_Query", rc, vmapiContextP);
    } else if (output->common.returnCode || output->common.reasonCode) {
        // Handle SMAPI return code and reason code
        printAndLogSmapiReturnCodeReasonCodeDescription("System_WWPN_Query", output->common.returnCode,
             output->common.reasonCode, vmapiContextP);
    } else {
        for (i =0; i < output->wwpnArrayCount; i ++) {
            // Get fcp_dev_id
            token = strtok_r(output->wwpnStructure[i].vmapiString, blank, &buffer);
            if (token != NULL) {
                strcpy(fcp_dev_id, token);
            } else {
                printf("ERROR: FCP device number is NULL\n");
                break;
            }

            // Get npiv_wwpn
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(npiv_wwpn, token);
            } else {
                printf("ERROR: NPIV world wide port number is NULL\n");
                break;
            }

            // Get chpid
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(chpid, token);
            } else {
                printf("ERROR: Channel path ID is NULL\n");
                break;
            }

            // Get perm_wwpn
            token = strtok_r(NULL, blank, &buffer);
            if (token != NULL) {
                strcpy(perm_wwpn, token);
            } else {
                printf("ERROR: Physical world wide port number is NULL\n");
                break;
            }

            // Get dev_status
            token = strtok_r(NULL, "\0", &buffer);
            if (token != NULL) {
                strcpy(dev_status, token);
            } else {
                printf("ERROR: FCP device status is NULL\n");
                break;
            }
            devStatus = atoi(dev_status);
            switch (devStatus) {
                case 1:
                    status = "Active";
                    break;
                case 2:
                    status = "Free";
                    break;
                case 3:
                    status = "Offline";
                    break;
                default:
                	status = "Unknown";
                    break;
            }

            printf("FCP device number: %s\n"
                   "  Status: %s\n"
                   "  NPIV world wide port number: %s\n"
                   "  Channel path ID: %s\n"
                   "  Physical world wide port number: %s\n",
                   fcp_dev_id, status, npiv_wwpn, chpid, perm_wwpn);
        }
    }
    return rc;
}
