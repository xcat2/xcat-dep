/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#ifndef VMAPISYSTEM_H
#define VMAPISYSTEM_H
#include <stddef.h>
#include "smPublic.h"
#include "smapiTableParser.h"

#ifdef __cplusplus
extern "C" {
#endif


/* System_Config_Syntax_Check */
typedef struct _vmApiSystemConfigSyntaxCheckOutput {
    commonOutputFields common;
    int errorDataLength;
    char * errorData;
} vmApiSystemConfigSyntaxCheckOutput;

/* Parser table for System_Config_Syntax_Check */
static tableLayout System_Config_Syntax_Check_Layout = {
    { APITYPE_BASE_STRUCT_LEN,  4, 4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemConfigSyntaxCheckOutput) },
    { APITYPE_INT4,             4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemConfigSyntaxCheckOutput,  common.requestId) },
    { APITYPE_RC_INT4,          4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemConfigSyntaxCheckOutput, common.returnCode) },
    { APITYPE_RS_INT4,          4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemConfigSyntaxCheckOutput, common.reasonCode) },
    { APITYPE_ERROR_BUFF_LEN,   4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemConfigSyntaxCheckOutput, errorDataLength) },
    { APITYPE_ERROR_BUFF_PTR,   4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemConfigSyntaxCheckOutput, errorData) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}};

int smSystem_Config_Syntax_Check(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char* targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemConfigSyntaxCheckOutput** outData);

/* System_Disk_Accessibility */
typedef struct _vmApiSystemDiskAccessibilityOutput {
    commonOutputFields common;
} vmApiSystemDiskAccessibilityOutput;

/* Parser table for System_Disk_Accessibility */
static  tableLayout System_Disk_Accessibility_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemDiskAccessibilityOutput) },
    { APITYPE_INT4,            4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskAccessibilityOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskAccessibilityOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskAccessibilityOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_Disk_Accessibility(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char* targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemDiskAccessibilityOutput** outData);

/* System_Disk_Add */
typedef struct _vmApiSystemDiskAddOutput {
    commonOutputFields common;
} vmApiSystemDiskAddOutput;

/* Parser table for System_Disk_Add */
static tableLayout System_Disk_Add_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemDiskAddOutput) },
    { APITYPE_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskAddOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskAddOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskAddOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}};

int smSystem_Disk_Add(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char* targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemDiskAddOutput** outData);

/* System_Disk_Query */
typedef struct _vmApiSystemDiskQueryOutput {
    commonOutputFields common;
    int diskInfoArrayCount;
    vmApiCStringInfo* diskIinfoStructure;
} vmApiSystemDiskQueryOutput;

/* Parser table for System_Disk_Query */
static  tableLayout System_Disk_Query_Layout = {
    { APITYPE_BASE_STRUCT_LEN,    4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemDiskQueryOutput) },
    { APITYPE_INT4,               4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskQueryOutput, common.requestId) },
    { APITYPE_RC_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskQueryOutput, common.returnCode) },
    { APITYPE_RS_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskQueryOutput, common.reasonCode) },
    { APITYPE_C_STR_ARRAY_PTR,    4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskQueryOutput, diskIinfoStructure) },
    { APITYPE_C_STR_ARRAY_COUNT,  4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemDiskQueryOutput, diskInfoArrayCount) },
    { APITYPE_C_STR_STRUCT_LEN,   4, 4,  STRUCT_INDX_1, NEST_LEVEL_1, sizeof(vmApiCStringInfo) },
    { APITYPE_C_STR_PTR,          4, 4,  STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiCStringInfo, vmapiString) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_Disk_Query(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemDiskQueryOutput ** outData);

/* System_FCP_Free_Query */
typedef struct _vmApiSystemFCPFreeQueryOutput {
    commonOutputFields common;
    int fcpArrayCount;
    vmApiCStringInfo* fcpStructure;
} vmApiSystemFCPFreeQueryOutput;

/* Parser table for  System_FCP_Free_Query */
static  tableLayout System_FCP_Free_Query_Layout = {
    { APITYPE_BASE_STRUCT_LEN,    4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemFCPFreeQueryOutput) },
    { APITYPE_INT4,               4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemFCPFreeQueryOutput, common.requestId) },
    { APITYPE_RC_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemFCPFreeQueryOutput, common.returnCode) },
    { APITYPE_RS_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemFCPFreeQueryOutput, common.reasonCode) },
    { APITYPE_C_STR_ARRAY_PTR,    4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemFCPFreeQueryOutput, fcpStructure) },
    { APITYPE_C_STR_ARRAY_COUNT,  4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemFCPFreeQueryOutput, fcpArrayCount) },
    { APITYPE_C_STR_STRUCT_LEN,   4, 4,  STRUCT_INDX_1, NEST_LEVEL_1, sizeof(vmApiCStringInfo) },
    { APITYPE_C_STR_PTR,          4, 4,  STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiCStringInfo, vmapiString) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_FCP_Free_Query(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemFCPFreeQueryOutput ** outData);

/* System_Performance_Threshold_Disable */
typedef struct _vmApiSystemPerformanceThresholdDisableOutput {
    commonOutputFields common;
} vmApiSystemPerformanceThresholdDisableOutput;

/* Parser table for System_Performance_Threshold_Disable */
static tableLayout System_Performance_Threshold_Disable_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemPerformanceThresholdDisableOutput) },
    { APITYPE_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemPerformanceThresholdDisableOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemPerformanceThresholdDisableOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemPerformanceThresholdDisableOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_Performance_Threshold_Disable(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength,
        char * password, char* targetIdentifier, char * eventType, vmApiSystemPerformanceThresholdDisableOutput** outData);


/* System_Performance_Threshold_Enable */
typedef struct _vmApiSystemPerformanceThresholdEnableOutput {
    commonOutputFields common;
} vmApiSystemPerformanceThresholdEnableOutput;

/* Parser table for System_Performance_Threshold_Enable */
static tableLayout System_Performance_Threshold_Enable_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemPerformanceThresholdEnableOutput) },
    { APITYPE_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemPerformanceThresholdEnableOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemPerformanceThresholdEnableOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemPerformanceThresholdEnableOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_Performance_Threshold_Enable(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength,
        char * password, char* targetIdentifier, char * eventType, vmApiSystemPerformanceThresholdEnableOutput** outData);

/* System_SCSI_Disk_Add */
typedef struct _vmApiSystemSCSIDiskAddOutput {
    commonOutputFields common;
} vmApiSystemSCSIDiskAddOutput;

/* Parser table for System_SCSI_Disk_Add */
static tableLayout System_SCSI_Disk_Add_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemSCSIDiskAddOutput) },
    { APITYPE_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskAddOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskAddOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskAddOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_SCSI_Disk_Add(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char* targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemSCSIDiskAddOutput** outData);

/* System_SCSI_Disk_Delete */
typedef struct _vmApiSystemSCSIDiskDeleteOutput {
    commonOutputFields common;
} vmApiSystemSCSIDiskDeleteOutput;

/* Parser table for System_SCSI_Disk_Delete */
static tableLayout System_SCSI_Disk_Delete_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemSCSIDiskDeleteOutput) },
    { APITYPE_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskDeleteOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskDeleteOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskDeleteOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_Disk_Delete(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char* targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemSCSIDiskDeleteOutput** outData);

/* System_SCSI_Disk_Query */
typedef struct _vmApiSystemSCSIDiskQueryOutput {
    commonOutputFields common;
    int scsiInfoArrayCount;
    int fcpArrayCount;
    vmApiCStringInfo* scsiInfoStructure;
    vmApiCStringInfo* fcpStructure;
} vmApiSystemSCSIDiskQueryOutput;

/* Parser table for  System_SCSI_Disk_Query */
static  tableLayout System_SCSI_Disk_Query_Layout = {
    { APITYPE_BASE_STRUCT_LEN,    4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemSCSIDiskQueryOutput) },
    { APITYPE_INT4,               4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskQueryOutput, common.requestId) },
    { APITYPE_RC_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskQueryOutput, common.returnCode) },
    { APITYPE_RS_INT4,            4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskQueryOutput, common.reasonCode) },
    { APITYPE_C_STR_ARRAY_PTR,    4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskQueryOutput, scsiInfoStructure) },
    { APITYPE_C_STR_ARRAY_COUNT,  4, 4,  STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemSCSIDiskQueryOutput, scsiInfoArrayCount) },
    { APITYPE_C_STR_STRUCT_LEN,   4, 4,  STRUCT_INDX_1, NEST_LEVEL_1, sizeof(vmApiCStringInfo) },
    { APITYPE_C_STR_PTR,          4, 4,  STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiCStringInfo, vmapiString) },
    { APITYPE_C_STR_ARRAY_PTR,    4, 4,  STRUCT_INDX_2, NEST_LEVEL_2, offsetof(vmApiSystemSCSIDiskQueryOutput, fcpStructure) },
    { APITYPE_C_STR_ARRAY_COUNT,  4, 4,  STRUCT_INDX_2, NEST_LEVEL_2, offsetof(vmApiSystemSCSIDiskQueryOutput, fcpArrayCount) },
    { APITYPE_C_STR_STRUCT_LEN,   4, 4,  STRUCT_INDX_2, NEST_LEVEL_2, sizeof(vmApiCStringInfo) },
    { APITYPE_C_STR_PTR,          4, 4,  STRUCT_INDX_2, NEST_LEVEL_2, offsetof(vmApiCStringInfo, vmapiString) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smSystem_SCSI_Disk_Query(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiSystemSCSIDiskQueryOutput ** outData);

/* System_WWPN_Query */
typedef struct _vmApiSystemWWPNQueryOutput {
    commonOutputFields common;
    int wwpnArrayCount;
    vmApiCStringInfo* wwpnStructure;
} vmApiSystemWWPNQueryOutput;

/* Parser table for  System_WWPN_Query */
static  tableLayout System_WWPN_Query_Layout = {
    { APITYPE_BASE_STRUCT_LEN,    4, 4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiSystemWWPNQueryOutput) },
    { APITYPE_INT4,               4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemWWPNQueryOutput, common.requestId) },
    { APITYPE_RC_INT4,            4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemWWPNQueryOutput, common.returnCode) },
    { APITYPE_RS_INT4,            4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemWWPNQueryOutput, common.reasonCode) },
    { APITYPE_C_STR_ARRAY_PTR,    4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemWWPNQueryOutput, wwpnStructure) },
    { APITYPE_C_STR_ARRAY_COUNT,  4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiSystemWWPNQueryOutput, wwpnArrayCount) },
    { APITYPE_C_STR_STRUCT_LEN,   4, 4, STRUCT_INDX_1, NEST_LEVEL_1, sizeof(vmApiCStringInfo) },
    { APITYPE_C_STR_PTR,          4, 4, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiCStringInfo, vmapiString) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0}
};

int smSystem_WWPN_Query(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, vmApiSystemWWPNQueryOutput ** outData);

#ifdef __cplusplus
}
#endif

#endif  // VMAPISYSTEM_H
