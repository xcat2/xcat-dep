/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#ifndef VMAPIPROCESS_H_
#define VMAPIPROCESS_H_
#include "smPublic.h"
#include "smapiTableParser.h"
#include <stddef.h>

#endif  /* VMAPIPROCESS_H_ */
