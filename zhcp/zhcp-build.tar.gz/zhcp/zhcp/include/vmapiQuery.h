/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#ifndef _VMAPI_QUERY_H
#define _VMAPI_QUERY_H
#include "smPublic.h"
#include "smapiTableParser.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Query_ABEND_Dump */
typedef struct _vmApiAbendDumpInfo {
    char abend_dump_loc;
    char * abend_dump_id;
    char * abend_dump_date;
    char * abend_dump_dist;
} vmApiAbendDumpInfo;

typedef struct _vmApiQueryAbendDumpOutput {
    commonOutputFields common;
    int dumpStrCount;
    vmApiAbendDumpInfo *abendDumpStructure;
} vmApiQueryAbendDumpOutput;

/* Parser table for Query_ABEND_Dump */
static tableLayout Query_ABEND_Dump_Layout = {
    { APITYPE_BASE_STRUCT_LEN,     4,  4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiQueryAbendDumpOutput) },
    { APITYPE_INT4,                4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAbendDumpOutput, common.requestId) },
    { APITYPE_RC_INT4,             4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAbendDumpOutput, common.returnCode) },
    { APITYPE_RS_INT4,             4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAbendDumpOutput, common.reasonCode) },
    { APITYPE_ARRAY_STRUCT_COUNT,  4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAbendDumpOutput, dumpStrCount) },
    { APITYPE_STRUCT_LEN,          4,  4, STRUCT_INDX_1, NEST_LEVEL_1, sizeof(vmApiAbendDumpInfo) },
    { APITYPE_INT1,                1,  1, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiAbendDumpInfo, abend_dump_loc) },
    { APITYPE_STRING_LEN,          8,  8, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiAbendDumpInfo, abend_dump_id) },
    { APITYPE_STRING_LEN,         10, 10, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiAbendDumpInfo, abend_dump_date) },
    { APITYPE_STRING_LEN,          8,  8, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiAbendDumpInfo, abend_dump_dist) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smQuery_ABEND_Dump(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char* targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiQueryAbendDumpOutput** outData);

/* Query_All_DM */
typedef struct _vmApiDirectoryEntryRecord {
    int directoryEntryRecordLength;
    char * directoryEntryRecord;
} vmApiDirectoryEntryRecord;


typedef struct _vmApiQueryAllDmOutput {
    commonOutputFields common;
} vmApiQueryAllDmOutput;

/* Parser table for Query_All_DM */
static tableLayout Query_All_DM_Layout = {
    { APITYPE_BASE_STRUCT_LEN,     4,  4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiQueryAllDmOutput) },
    { APITYPE_INT4,                4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAllDmOutput, common.requestId) },
    { APITYPE_RC_INT4,             4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAllDmOutput, common.returnCode) },
    { APITYPE_RS_INT4,             4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAllDmOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smQuery_All_DM(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char* targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiQueryAllDmOutput** outData);


/* Query_API_Functional_Level */
typedef struct _vmApiQueryApiFunctionalLevelOutput {
    commonOutputFields common;
} vmApiQueryApiFunctionalLevelOutput;

/* Parser table for Query_API_Functional_Level */
static tableLayout Query_API_Functional_Level_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiQueryApiFunctionalLevelOutput) },
    { APITYPE_INT4,            4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryApiFunctionalLevelOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryApiFunctionalLevelOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryApiFunctionalLevelOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smQuery_API_Functional_Level(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, vmApiQueryApiFunctionalLevelOutput ** outData);

/* Query_Asychronous_Operation_DM */
typedef struct _vmApiQueryAsynchronousOperationDmOutput {
    commonOutputFields common;
} vmApiQueryAsynchronousOperationDmOutput;

/* Parser table for Query_Asychronous_Operation_DM */
static tableLayout Query_Asynchronous_Operation_DM_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiQueryAsynchronousOperationDmOutput) },
    { APITYPE_INT4,            4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAsynchronousOperationDmOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAsynchronousOperationDmOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryAsynchronousOperationDmOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smQuery_Asychronous_Operation_DM(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, int operationId, vmApiQueryAsynchronousOperationDmOutput ** outData);

/* Query_Directory_Manager_Level_DM */
typedef struct _vmApiQueryDirectoryManagerLevelDm {
    commonOutputFields common;
    char * directoryManagerLevel;
    int directoryManagerLevelLength;
} vmApiQueryDirectoryManagerLevelDmOutput;

/* Parser table for Query_Directory_Manager_Level_DM */
static tableLayout Query_Directory_Manager_Level_DM_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4,   4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiQueryDirectoryManagerLevelDmOutput) },
    { APITYPE_INT4,            4,   4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryDirectoryManagerLevelDmOutput, common.requestId) },
    { APITYPE_INT4,            4,   4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryDirectoryManagerLevelDmOutput, common.returnCode) },
    { APITYPE_INT4,            4,   4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryDirectoryManagerLevelDmOutput, common.reasonCode) },
    { APITYPE_CHARBUF_LEN,     1, 100, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryDirectoryManagerLevelDmOutput, directoryManagerLevel) },
    { APITYPE_CHARBUF_COUNT,   1, 100, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiQueryDirectoryManagerLevelDmOutput, directoryManagerLevelLength) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smQuery_Directory_Manager_Level_DM(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength,
        char * password, char * targetIdentifier, vmApiQueryDirectoryManagerLevelDmOutput ** outData);

#ifdef __cplusplus
}
#endif

#endif
