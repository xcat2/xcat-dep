/**
 * IBM (C) Copyright 2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#ifndef VMAPIMETADATA_H_
#define VMAPIMETADATA_H_
#include "smPublic.h"
#include "smapiTableParser.h"
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Metadata_Delete */
typedef struct _vmApiMetadataDeleteOutput {
    commonOutputFields common;
} vmApiMetadataDeleteOutput;

/* Parser table for Metadata_Delete */
static tableLayout Metadata_Delete_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiMetadataDeleteOutput) },
    { APITYPE_INT4,            4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataDeleteOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataDeleteOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataDeleteOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smMetadata_Delete(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, char * keywordlist, vmApiMetadataDeleteOutput ** outData);

/* Metadata_Get */
typedef struct _vmApiMetadataEntry {
    char * metadataEntryName;
    char * metadata;
    int metadataLength;
} vmApiMetadataEntry;

typedef struct _vmApiMetadataGetOutput {
    commonOutputFields common;
    int metadataEntryCount;
    vmApiMetadataEntry * metadataEntryList;
} vmApiMetadataGetOutput;

/* Parser table for Metadata_Get */
static tableLayout Metadata_Get_Layout = {
    { APITYPE_BASE_STRUCT_LEN,     4,  4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiMetadataGetOutput) },
    { APITYPE_INT4,                4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataGetOutput, common.requestId) },
    { APITYPE_RC_INT4,             4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataGetOutput, common.returnCode) },
    { APITYPE_RS_INT4,             4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataGetOutput, common.reasonCode) },
    { APITYPE_ARRAY_LEN,           4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataGetOutput, metadataEntryList) },
    { APITYPE_ARRAY_STRUCT_COUNT,  4,  4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataGetOutput, metadataEntryCount) },
    { APITYPE_NOBUFFER_STRUCT_LEN, 4,  4, STRUCT_INDX_1, NEST_LEVEL_1, sizeof(vmApiMetadataEntry) },
    { APITYPE_STRING_LEN,          0, 80, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiMetadataEntry, metadataEntryName) },
    { APITYPE_CHARBUF_LEN,         0, 80, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiMetadataEntry, metadata) },
    { APITYPE_CHARBUF_COUNT,       0,  4, STRUCT_INDX_1, NEST_LEVEL_1, offsetof(vmApiMetadataEntry, metadataLength) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smMetadataGet(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, char * keywordlist, vmApiMetadataGetOutput ** outData);

/* Metadata_Set */
typedef struct _vmApiMetadataSetOutput {
    commonOutputFields common;
} vmApiMetadataSetOutput;

/* Parser table for Metadata_Set */
static tableLayout Metadata_Set_Layout = {
    { APITYPE_BASE_STRUCT_LEN, 4, 4, STRUCT_INDX_0, NEST_LEVEL_0, sizeof(vmApiMetadataSetOutput) },
    { APITYPE_INT4,            4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataSetOutput, common.requestId) },
    { APITYPE_RC_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataSetOutput, common.returnCode) },
    { APITYPE_RS_INT4,         4, 4, STRUCT_INDX_0, NEST_LEVEL_0, offsetof(vmApiMetadataSetOutput, common.reasonCode) },
    { APITYPE_END_OF_TABLE, 0, 0, 0, 0 }
};

int smMetadata_Set(struct _vmApiInternalContext* vmapiContextP, char * userid, int passwordLength, char * password,
        char * targetIdentifier, int keyValueCount, char ** keyValueArray, vmApiMetadataSetOutput ** outData);

#ifdef __cplusplus
}
#endif

#endif /* VMAPIMETADATA_H_ */
