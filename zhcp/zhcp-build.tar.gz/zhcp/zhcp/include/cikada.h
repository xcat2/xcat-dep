/**
 * IBM (C) Copyright 2011,2013 Eclipse Public License
 * http://www.eclipse.org/org/documents/epl-v10.html
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define TRUE                    1
#define PAGE_SIZE            4096
#define TRACK_SIZE          65536
#define TRACKS_PER_CYLINDER    15
// The first 16 bytes in each track are a label declaring the cylinder and
// track indices.
#define TRACK_BEGINNING_OVERHEAD 16

typedef struct RecordMetadata {
  uint16_t cylinderIndex;
  uint16_t trackIndex;
  uint8_t  recordIndex;
  uint8_t  keyCount;
  uint16_t dataCount;
} RecordMetadata;

int main (int argumentCount, char* argumentValues[]);
