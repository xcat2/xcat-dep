#define IDI_MYICON 10

#define IDM_TRAYMENU 20
#define IDM_MAINMENU 21

#define IDM_ABOUT 30
#define IDM_LOG 31
#define IDM_EXIT 32

#define IDM_SAVEAS 40
#define IDM_CLOSE 41
#define IDM_SETUP 42

#define IDE_EDIT 50
#define IDE_PASSEDIT 51
#define IDE_PINEDIT 52

